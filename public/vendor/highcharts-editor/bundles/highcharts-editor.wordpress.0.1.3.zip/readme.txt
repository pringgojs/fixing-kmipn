=== Plugin Name ===
Tags: comments, spam
License: MIT
License URI: https://opensource.org/licenses/MIT

Highcharts Editor - Add charting capabilities to your Wordpress installation

== Description ==

Highcharts Editor - Add charting capabilities to your Wordpress installation

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. You will now have a Highcharts icon on the post editor toolbar

== Screenshots ==

![screenshot](customize.png)
![screenshot](wp.png)