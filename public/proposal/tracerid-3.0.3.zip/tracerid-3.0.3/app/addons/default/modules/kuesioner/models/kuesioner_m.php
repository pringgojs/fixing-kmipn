<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model Kuesioner_m
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Models
 */
class Kuesioner_m extends MY_Model {
	
	/**
	 * Mengambil data kuesioner
	 *
	 * Fungsi ini akan mengambil data kuesioner berdasarkan limit data dan start page tertentu
	 * @param array $pagination_config
	 * @return array
	*/
	public function get_kuesioner($pagination_config = NULL)
	{
		$this->db->select('*');
		
		$start = ($this->uri->segment($pagination_config['uri_segment'])) ? $this->uri->segment($pagination_config['uri_segment']) : 0;
		$this->db->limit($pagination_config['per_page'], $start);
		
		$query = $this->db->get('default_kuesioner_kuesioner');
		$result = $query->result_array();
		
        return $result;
	}
	
	/**
	 * Mengambil data kuesioner berdasarkan id
	 *
	 * @param int $id
	 * @return array
	*/
	public function get_kuesioner_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner');
		$result = $query->row_array();
		
		return $result;
	}
	
	/**
	 * Mengambil jumlah data kuesioner
	 *
	 * @return int
	*/
	public function count_all_kuesioner()
	{
		return $this->db->count_all('kuesioner_kuesioner');
	}
	
	/**
	 * Menghapus data kuesioner
	 *
	 * @param int $id id kuesioner
	 * @return void
	*/
	public function delete_kuesioner_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('default_kuesioner_kuesioner');
	}
	
	/**
	 * Menambah data kuesioner
	 *
	 * @param array $values
	 * @return void
	*/
	public function insert_kuesioner($values)
	{
		$values['entries'] = 0;
		$values['active_status'] = 0;
		$values['pages'] = 0;
		$values['created_on'] = date("Y-m-d H:i:s");
		$values['created_by'] = $this->current_user->id;
		
		return $this->db->insert('default_kuesioner_kuesioner', $values);
	}
	
	/**
	 * Mengubah data kuesioner berdasarkan id
	 *
	 * @param array $values
	 * @param int $row_id id kuesioner
	 * @return void
	*/
	public function update_kuesioner($values, $row_id)
	{
		$values['updated_on'] = date("Y-m-d H:i:s");
		
		$this->db->where('id', $row_id);
		return $this->db->update('default_kuesioner_kuesioner', $values); 
	}

	/**
	 * Mengubah status kuesioner tertentu
	 *
	 * @param int $id id kuesioner
	 * @param string $status
	 * @return void
	*/
	public function activation($id, $status){
		if($status == 1){
			$values['active_status'] = 0;
		}elseif($status == 0){
			$values['active_status'] = 1;	
		}
		$values['updated_on'] = date("Y-m-d H:i:s");

		$this->db->where('id', $id);
		return $this->db->update('default_kuesioner_kuesioner', $values); 
	}

	/**
	 * Mengambil data kolom pages di tabel kuesioner
	 *
	 * @param int $id id kuesioner
	 * @return array
	*/
	public function get_pages($id){
		$this->db->select('pages');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner');
		$result = $query->row_array();
		
		return $result;
	}

	/**
	 * Mengambil data kuesioner berdasarkan id tertentu
	 *
	 * @param int $id id kuesioner
	 * @return obj
	*/
	public function get_records($id){
		$this->select('*');
		$this->where('id',$id);
		$result = $this->db->get('kuesioner_kuesioner')->result();
		return $result;
	}

	/**
	 * Mengambil id tertinggi
	 *
	 * @return obj
	*/
	public function get_max_id(){
		$this->db->select_max('id');
		$query = $this->db->get('default_kuesioner_kuesioner');
		return $query->result();
	}

	/**
	 * Mengambil deskripsi grup dari user tertentu
	 *
	 * @return string
	*/
	public function get_user_info(){
		$this->db->select('description');
		$this->db->where('id',$this->session->userdata('group_id'));
		$role = $this->db->get('groups')->row('description');

		return $role;
	}

	/**
	 * Mengambil data grup
	 *
	 * @return array
	*/
	public function get_all_groups(){
		$this->db->select('*');
		return $this->db->get('groups')->result_array();
	}

	/**
	 * Mengambil data responden
	 *
	 * @param obj $value data kuesioner
	 * @return array
	*/
	public function get_responden($value){
		$this->db->select('users.id');

		if($value->conditional_logic != '' && $value->conditional_logic != null){
			$conlog = json_decode($value->conditional_logic);
			// 
			$i = 0;
			if(isset($conlog->options) && isset($conlog->value)){
				$conlog_option = $conlog->options;
				$conlog_value = $conlog->value;
				foreach ($conlog_option as $key => $value) {
					if($conlog->value[$i] != ''){
						if($conlog->isnot[$i] == 'is'){
						$operator = '=';
						}else{
							$operator = '!=';
						}
						// Uncomment this condition if neccesary
						// if($value == 'email' || $value == 'username' || $value == 'display_name' || $value == 'academic_nim' || $value == 'street_1' || $value == 'street_2' || ){

						// }else{
							$this->db->where($value.$operator,$conlog->value[$i]);
						// }
						
					}
					$i++;
				}
			}
		}

		$this->db->from('users');
		$this->db->join('profiles','users.id = profiles.user_id');


		return $this->db->get()->result_array();
	}

	/**
	 * Mengecek data responden yang memiliki akses supervisi
	 *
	 * @return boolean
	*/
	function cek_allow(){
		$this->db->select("*");
		$this->db->where('user_id',$this->session->userdata('id'));
		$all = $this->db->get('profiles')->row_array();
		if($all['supervision_access'] != ''){
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Mengambil data supervision_access dari user tertentu
	 *
	 * @return string
	*/
	function cek_supervision(){
		$this->db->select("*");
		$this->db->where('user_id',$this->session->userdata('id'));
		$all = $this->db->get('profiles')->row_array();
		return $all['supervision_access'];
	}

	/**
	 * Menambahkan data style kuesioner
	 *
	 * @param array $value field=>value 
	 * @return void
	*/
	function insert_style($value){
		return $this->db->insert('default_style_kuesioner', $value);
	}

	/**
	 * Memperbaharui data style kuesioner
	 *
	 * @param array $value field=>value 
	 * @param int $id id kuesioner 
	 * @return void
	*/
	function update_style($value, $id){
		$this->db->where('id',$id);
		return $this->db->update('default_style_kuesioner', $value);
	}

	/**
	 * Menghitung jumlah data style dari kuesioner tertentu
	 *
	 * @param int $id id kuesioner 
	 * @return int
	*/
	function is_style_exist($id){
		$this->db->from('default_style_kuesioner');
		$this->db->where('id',$id);
		return $this->db->count_all_results();
	}

	/**
	 * Mengambil data style dari kuesioner tertentu
	 *
	 * @param int $id id kuesioner 
	 * @return array
	*/
	function get_style($id){
		$this->db->select('*');
		$this->db->where('id',$id);
		return $this->db->get('default_style_kuesioner')->row_array();
	}

	/**
	 * Mengambil data user tertentu
	 *
	 * @param int $id user_id 
	 * @return array
	*/
	function get_user_by_id($id){
		$this->db->where('user_id',$id);
		return $this->db->get('profiles')->row_array();
	}
}