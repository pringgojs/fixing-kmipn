<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Admin_kuesioner
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Admin_kuesioner extends Admin_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner';

    public function __construct()
    {
        parent::__construct();

		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'access_kuesioner_backend')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Load everything we need
		// -------------------------------------

        $this->lang->load('kuesioner');		
		$this->load->model('kuesioner_m');
		$this->load->model('organization/units_m');
		$this->load->model('kuesioner_answer_m');
		$this->load->model('kuesioner_page_m');
		$this->load->model('kuesioner_section_m');
		$this->load->model('kuesioner_field_m');
    }

    /**
	 * Menampilkan semua kuesioner
     *
     * @return	void
     */
    public function index()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'access_kuesioner_backend') and ! group_has_role('kuesioner', 'view_all_kuesioner') AND ! group_has_role('kuesioner', 'view_own_kuesioner')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Pagination
		// -------------------------------------

		$pagination_config['base_url'] = base_url(). 'admin/kuesioner/kuesioner/index';
		$pagination_config['uri_segment'] = 5;
		$pagination_config['total_rows'] = $this->kuesioner_m->count_all_kuesioner();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;
		
        // -------------------------------------
		// Get entries
		// -------------------------------------
		$input = array();
		$temp = null;
		$alls = $this->kuesioner_m->get_kuesioner($pagination_config);
		$i = 0;

		$additional = '';
		if($this->session->userdata('group') == 'surveyor'){
			$users = $this->kuesioner_m->get_user_by_id($this->session->userdata('id'));
			$sa = $users['supervision_access'];
		}else{
			$sa = '';
		}

		foreach ($alls as $all) {
			$input[$i]['id'] = $all['id'];
			$input[$i]['title'] = $all['title'];
			$input[$i]['deskripsi'] = $all['deskripsi'];
			$input[$i]['entries'] = $this->kuesioner_answer_m->get_entries_by_id($all['id'], $all['conditional_logic'], $sa);
			$input[$i]['active_status'] = $all['active_status'];
			$input[$i]['pages'] = $all['pages'];
			$input[$i]['conditional_logic'] = $all['conditional_logic'];
			$input[$i]['created_on'] = $all['created_on'];
			$input[$i]['created_by'] = $all['created_by'];
			$input[$i]['updated_on'] = $all['updated_on'];
			$input[$i]['updated_by'] = $all['updated_by'];
			$input[$i]['ordering_count'] = $all['ordering_count'];
			$i++;
		}
        $data['kuesioner']['entries'] = $input;
		$data['kuesioner']['total'] = count($data['kuesioner']['entries']);
		$data['kuesioner']['pagination'] = $this->pagination->create_links();

		$temp = $this->kuesioner_m->cek_allow();
		$data['kuesioner']['allow'] = $temp;
		// -------------------------------------
        // Build the page. See views/admin/index.php
        // for the view code.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner:plural'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:plural'))
			->build('admin/kuesioner_index', $data);
    }
	
	/**
     * Menambah kuesioner baru
     *
     * Fungsi ini akan menampilkan form tambah kuesioner dan mengeksekusi fungsi _update_kuisoner untuk menambahkan data kuesioner baru ke database.
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'create_kuesioner')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner('new')){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner:submit_success'));				
				redirect('admin/kuesioner/kuesioner/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'admin/kuesioner/kuesioner/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner:new'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:plural'), '/admin/kuesioner/kuesioner/index')
			->set_breadcrumb(lang('kuesioner:kuesioner:new'))
			->build('admin/kuesioner_form', $data);
    }
	
	/**
     * Mengedit kuesioner
     *
     * Fungsi ini akan menampilkan form edit kuesioner yang akan terisi oleh data kuesioner berdasarkan $id yang diterima dan menampilkan list halaman dari kuesioner tersebut.
     * @param  int $id id kuesioner
     * @return	void
     */
    public function edit($id = 0)
    {
    	//dump($this->input->post());
        // -------------------------------------
		// Check permission
		// -------------------------------------
		$pagination_config['base_url'] = base_url(). 'admin/kuesioner/kuesioner/index';
		$pagination_config['uri_segment'] = 5;
		$pagination_config['total_rows'] = $this->kuesioner_m->count_all_kuesioner();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;

		
		if(! group_has_role('kuesioner', 'edit_all_kuesioner') AND ! group_has_role('kuesioner', 'edit_own_kuesioner')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'edit_all_kuesioner')){
			$entry = $this->kuesioner_m->get_kuesioner_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner('edit', $id)){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner:submit_success'));				
				redirect('admin/kuesioner/kuesioner/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner:submit_failure');
			}
		}
		
		$data['fields'] = $this->kuesioner_m->get_kuesioner_by_id($id);

        $data['records'] = $this->kuesioner_m->get_records($id);

        $data['all_fakultas'] = $this->units_m->get_units_by_type('Fakultas');
		$data['all_prodi'] = $this->units_m->get_units_by_type('Program-Studi');

		$temp = array();
        foreach ($data['records'] as $dt){
            $temp = json_decode($dt->pages, true);
        }
        
       	$temp_page = array();

        if($temp == null || $temp == ""){
        	$query = $this->kuesioner_page_m->get_all_page_by_id($id);
        	foreach ($query as $q){
                array_push($temp_page,$q);
            }
        }else{
        	
	        for($i=0;$i<$temp["jumlah"][0];$i++){
	            $temp_urutan = $temp["urutan"][$i];
	            $query = $this->kuesioner_page_m->get_page_by_order($temp["urutan"][$i],$id);

	            foreach ($query as $q){
	                array_push($temp_page,$q);
	            }
	        }
	        $query = $this->kuesioner_page_m->get_all_page_by_id($id);
	        foreach ($query as $q){
                if(!(in_array($q, $temp_page))){
                	array_push($temp_page,$q);
                }
            }
        }
		
		$data['pages'] = $temp_page;
		$data['total'] = count($data['pages']);
		$data['mode'] = 'edit';
		$data['return'] = 'admin/kuesioner/kuesioner/index';
		$data['entry_id'] = $id;
		$data['pagination'] = $this->pagination->create_links();

		$data['groups'] = $this->kuesioner_m->get_all_groups();
		//dump($groups);
		$all_fields = array();
		$profile_fields = $this->kuesioner_field_m->get_user_field();

		array_push($all_fields, '');
		array_push($all_fields, 'email');
		array_push($all_fields, 'username');
		array_push($all_fields, 'group_id');
		foreach ($profile_fields as $key => $value) {
			if($value != 'id' && $value != 'created' && $value != 'updated' && $value != 'created_by' && $value != 'ordering_count' && $value != 'user_id' && $value != 'updated_on' && $value != 'supervision_access'){
				array_push($all_fields, $value);	
			}
		}
		$data['allfields'] = $all_fields;
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner:edit'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:list'), '/admin/kuesioner/kuesioner/index')
			->set_breadcrumb($data['fields']['title'], 'admin/kuesioner/kuesioner/edit/'.$id)
			->build('admin/kuesioner_form_edit', $data);
    }
	
	/**
     * Menghapus kuesioner
     * 
     * Fungsi ini akan menghapus data pada tabel kuesioner berdasarkan $id yang diterima
     * @param int $id id kuesioner
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'delete_all_kuesioner') AND ! group_has_role('kuesioner', 'delete_own_kuesioner')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'delete_all_kuesioner')){
			$entry = $this->kuesioner_m->get_kuesioner_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->kuesioner_m->delete_kuesioner_by_id($id);
        $this->session->set_flashdata('error', lang('kuesioner:kuesioner:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('admin/kuesioner/kuesioner/index');
    }
	
	/**
     * Mengaktifkan/nonaktifkan kuesioner
     * 
     * Fungsi ini akan mengaktifkan atau menonaktifkan kuesioner sesuai dengan $id dan $status yang diterima. Jika kuesioner aktif maka akan muncul di frontend.
     * @param int $id id kuesioner
     * @param int $status status kuesioner, 1 = aktif dan 1 = tidak aktif
     * @return  void
     */
    public function activation(){
    	$id = $this->uri->segment(5);
    	$status = $this->uri->segment(6);
    	if(! group_has_role('kuesioner', 'activate_kuesioner') AND ! group_has_role('kuesioner', 'activate_kuesioner')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}	
		$this->kuesioner_m->activation($id,$status);
		redirect('admin/kuesioner/kuesioner/index');
    }

	/**
     * Insert atau update data kuesioner di database
     *
     * Fungsi ini meneruskan proses perubahan data ke database
     * @param   string $method method untuk update data didatabase ('new' or 'edit'). Method ini dikirim dari fungsi create dan edit.
	 * @param   int $row_id id kuesioner (jika method = edit).
     * @return	boolean
     */
	private function _update_kuesioner($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('title', lang('kuesioner:title'), 'required');
		$this->form_validation->set_rules('deskripsi', lang('kuesioner:deskripsi'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->kuesioner_m->insert_kuesioner($values);
				
			}
			else
			{
				$ins = array();
				$ins['title'] = $this->input->post('title');
				$ins['deskripsi'] = $this->input->post('deskripsi');
				$ins['conditional_logic'] = $this->input->post('conditional_logic');

				if($this->input->post('pages') == ""){
					$pages = $this->kuesioner_m->get_pages($row_id);
					$ins['pages'] = $pages['pages'];
				}else{
					$ins['pages'] = $this->input->post('pages');
				}
				$result = $this->kuesioner_m->update_kuesioner($ins, $row_id);
			}
		}
		
		return $result;
	}

	/**
     * Duplikat kuesioner
     *
     * Fungsi ini akan menduplikat kuesioner berdasarkan $id_kuesoner yang diterima.
     * @param   int $id_kuesioner id kuesioner
     * @return	void
     */	
   	public function clone_kuesioner($id_kuesioner){

   		$temp_new_page = array();
   		$temp_new_section = array();
   		$temp_old_section = array();
   		$temp_new_field = array();
   		$temp_old_field = array();

		$kuesioner = $this->kuesioner_m->get_kuesioner_by_id($id_kuesioner);
   		$all_pages_obj = json_decode($kuesioner['pages']);
   		$all_pages = $all_pages_obj->urutan;

   		//assign data for new kuesioner
   		$new_kuesioner = array();
   		$new_kuesioner['title'] = "Clone of ".$kuesioner['title'];
   		$new_kuesioner['deskripsi'] = $kuesioner['deskripsi'];
   		
   		//insert new kuesioner
   		$this->kuesioner_m->insert_kuesioner($new_kuesioner);
   		$new_kuesioner_id = $this->db->insert_id();

   		//initialize variable for new page
   		$new_page = array();
   		$page_sequence = array();
   		$page_sequence['urutan'] = array();
   		$page_sequence['jumlah'] = array();
   		foreach ($all_pages as $pages => $id_page) {
   			$page = $this->kuesioner_page_m->get_kuesioner_page_by_id($id_page);
   			$all_sections_obj = json_decode($page['sections']);
   			$all_sections = $all_sections_obj->urutan;

   			//assign data for new page
   			$new_page['title'] = $page['title'];
   			$new_page['kuesioner_id'] = $new_kuesioner_id;
   			$new_page['deskripsi'] = $page['deskripsi'];

   			//insert new page
	   		$this->kuesioner_page_m->insert_kuesioner_page($new_page);
	   		$new_page_id = $this->db->insert_id();

	   		//adding new page id to temporary variable for conditional logic
			array_push($temp_new_page, $new_page_id);

   			//initialize variable for new section
   			$new_section = array();
   			$section_sequence = array();
			$section_sequence['urutan'] = array();
			$section_sequence['jumlah'] = array();
   			foreach ($all_sections as $sections => $id_section) {
   				$section = $this->kuesioner_section_m->get_kuesioner_section_by_id($id_section);
   				$all_fields_obj = json_decode($section['fields']);
   				$all_fields = $all_fields_obj->urutan;

   				//assign data for new page
	   			$new_section['title'] = $section['title'];
	   			$new_section['deskripsi'] = $section['deskripsi'];
	   			$new_section['kuesioner_id'] = $new_kuesioner_id;
	   			$new_section['page_id'] = $new_page_id;
	   			$new_section['section_options'] = $section['section_options'];

	   			//insert new section
		   		$this->kuesioner_section_m->insert_kuesioner_section($new_section);
		   		$new_section_id = $this->db->insert_id();

		   		//adding new page id to temporary variable for conditional logic
				array_push($temp_new_section, $new_section_id);
				array_push($temp_old_section, $id_section);

   				//initialize variable for new field
   				$new_field = array();
   				$field_sequence = array();
   				$field_sequence['urutan'] = array();
   				$field_sequence['type'] = array();
   				$field_sequence['jumlah'] = array();
   				foreach ($all_fields as $fields => $id_html) {
   					$field = $this->kuesioner_field_m->get_kuesioner_field_by_condition($id_kuesioner,$id_page,$id_section,$id_html);

   					//assign data for new field
   					$new_field['id_html'] = $field['id_html'];
   					$new_field['kuesioner_id'] = $new_kuesioner_id;
   					$new_field['page_id'] = $new_page_id;
   					$new_field['section_id'] = $new_section_id;
   					$new_field['type'] = $field['type'];
   					$new_field['options'] = $field['options'];
   					$new_field['required'] = $field['required'];

   					$this->kuesioner_field_m->insert_kuesioner_field($new_field);

   					array_push($temp_old_field, $field['id']);
   					array_push($temp_new_field, $this->db->insert_id());

   					array_push($field_sequence['urutan'], $field['id_html']);
   					array_push($field_sequence['type'], $field['type']);
	
   				}
   				array_push($field_sequence['jumlah'], sizeof($field_sequence['urutan']));

   				//update last inserted section
   				$update_section['fields'] = json_encode($field_sequence);
   				$this->kuesioner_section_m->update_kuesioner_section($update_section,$new_section_id);

   				array_push($section_sequence['urutan'], $new_section_id);
   			}
   			array_push($section_sequence['jumlah'], sizeof($section_sequence['urutan']));
   			
   			//update last inserted page
			$update_page['sections'] = json_encode($section_sequence);
			$this->kuesioner_page_m->update_kuesioner_page($update_page,$new_page_id);

   			array_push($page_sequence['urutan'], $new_page_id);
   		}
   		
   		array_push($page_sequence['jumlah'], sizeof($page_sequence['urutan']));

   		//updating last inserted kuesioner
		$update_kuesioner['pages'] = json_encode($page_sequence);
		$this->kuesioner_m->update_kuesioner($update_kuesioner,$new_kuesioner_id);

		/*****ADDING THE CONDITIONAL LOGIC*****/
		// 1. For Kuesioner Page
		$cek_status_page = $this->update_page_conditional_logic($all_pages, $temp_new_page);	

		$all_sections = $this->kuesioner_section_m->get_kuesioner_section_by_kuesioner_id($id_kuesioner);
		$all_fields = $this->kuesioner_field_m->get_kuesioner_field_by_kuesioner_id($id_kuesioner);
		
		// 2. For Kuesioner Section	
		$this->update_section_conditional_logic($all_pages, $all_sections, $temp_new_page, $temp_new_section, $temp_old_section);

		// 3. For Kuesioner Field
		$this->update_field_conditional_logic($all_pages, $all_sections, $all_fields, $temp_new_page, $temp_new_section, $temp_new_field, $temp_old_field);
		
		redirect('admin/kuesioner/kuesioner/index');

    }

    /**
     * Memperbaharui page hasil cloning
     *
     * Fungsi ini akan menambahkan data page hasil cloning dari kuesioner_pages master
     * @param   array $all_pages semua page yang ada pada kuesioner_pages master
     * @param   array $temp_new_page temporary id dari kuesioner_pages yang baru (data cloning)
     * @return	void
     */
    public function update_page_conditional_logic($all_pages, $temp_new_page){
    	foreach ($all_pages as $pages => $id_page) {
			$new_page_con_logic = array();
			$new_page_con_logic['options'] = array();
			$new_page_con_logic['op_labels'] = array();
			$new_page_con_logic['isnot'] = array();
			$new_page_con_logic['value'] = array();
			$new_page_con_logic['val_labels'] = array();
			$new_page_con_logic['show'] = array();
			$new_page_con_logic['any'] = array();

   			$page = $this->kuesioner_page_m->get_kuesioner_page_by_id($id_page);

   			if($page['conditional_logic'] != ''){ 
   				$page_cl_obj = json_decode($page['conditional_logic']);
	   			$page_condition = $page_cl_obj->options;
	   			if($page_condition != ''){
	   				foreach ($page_condition as $pc => $page_value) {
	   					list($p_id,$s_id,$id_h)=explode("_",$page_value);
	   					$page_in_condtional = $this->kuesioner_page_m->get_kuesioner_page_by_id($p_id);
	   					$page_in_condtional_cl_obj = json_decode($page_in_condtional['sections']);
	   					$page_in_condtional_val = $page_in_condtional_cl_obj->urutan;

	   					$key_page = array_search((string)$p_id, $all_pages);
	   					
	   					$inserted_page = $this->kuesioner_page_m->get_kuesioner_page_by_id($temp_new_page[$key_page]);

	   					$key_section = array_search((string)$s_id, $page_in_condtional_val);
	   					
	   					$array_order_section = json_decode($inserted_page['sections']);
	   					$inserted_section_obj = $array_order_section->urutan;
	   					$inserted_section = $inserted_section_obj[$key_section];
		   				
		   				$new_opt = $temp_new_page[$key_page]."_".$inserted_section."_".$id_h;
		   				array_push($new_page_con_logic['options'], $new_opt);
		   			}
		   			$new_page_con_logic['op_labels'] = $page_cl_obj->op_labels;
		   			$new_page_con_logic['isnot'] = $page_cl_obj->isnot;
		   			$new_page_con_logic['value'] = $page_cl_obj->value;
		   			$new_page_con_logic['val_labels'] = $page_cl_obj->val_labels;
		   			$new_page_con_logic['show'] = $page_cl_obj->show;
		   			$new_page_con_logic['any'] = $page_cl_obj->any;

		   			$new_ins_page_conlog = json_encode($new_page_con_logic);
	   			}else{
	   				$new_ins_page_conlog = '';
	   			}

	   			$update_page_conlog['conditional_logic'] = $new_ins_page_conlog;
				$id = array_search($id_page, $all_pages);
				$this->kuesioner_page_m->update_kuesioner_page($update_page_conlog,$temp_new_page[$id]);

   			}
   		}
    }

    /**
     * Menambahkan section hasil cloning
     *
     * Fungsi ini akan menambahkan data section hasil cloning dari kuesioner_sections master
     * @param   array $all_pages semua section yang ada pada kuesioner_pages master
     * @param   array $all_sections semua section yang ada pada kuesioner_sections master
     * @param   array $temp_new_page temporary id dari page yang baru (data cloning)
     * @param   array $temp_new_section temporary id section yang baru (data cloning)
     * @param   array $temp_old_section temporary id section yang ada pada kuesioner_sections master
     * @return	void
     */
    public function update_section_conditional_logic($all_pages, $all_sections, $temp_new_page, $temp_new_section, $temp_old_section){
    	foreach ($all_sections as $section) {
			$new_section_con_logic = array();
			$new_section_con_logic['options'] = array();
			$new_section_con_logic['isnot'] = array();
			$new_section_con_logic['value'] = array();
			$new_section_con_logic['show'] = array();
			$new_section_con_logic['any'] = array();

   			if($section['conditional_logic'] != ''){ 
   				$section_cl_obj = json_decode($section['conditional_logic']);
	   			$section_condition = $section_cl_obj->options;
	   			if($section_condition != ''){
	   				foreach ($section_condition as $sc => $section_value) {
	   					list($p_id,$s_id,$id_h)=explode("_",$section_value);

	   					$page_in_condtional = $this->kuesioner_page_m->get_kuesioner_page_by_id($p_id);
	   					$page_in_condtional_cl_obj = json_decode($page_in_condtional['sections']);
	   					$page_in_condtional_val = $page_in_condtional_cl_obj->urutan;

	   					$key_page = array_search((string)$p_id, $all_pages);
	   					
	   					$inserted_page = $this->kuesioner_page_m->get_kuesioner_page_by_id($temp_new_page[$key_page]);

	   					$key_section = array_search((string)$s_id, $page_in_condtional_val);
	   					
	   					$array_order_section = json_decode($inserted_page['sections']);

	   					$inserted_section_obj = $array_order_section->urutan;
	   					$inserted_section = $inserted_section_obj[$key_section];
		   				
		   				$new_opt = $temp_new_page[$key_page]."_".$inserted_section."_".$id_h;
		   				array_push($new_section_con_logic['options'], $new_opt);
		   			}
		   			$new_section_con_logic['isnot'] = $section_cl_obj->isnot;
		   			$new_section_con_logic['value'] = $section_cl_obj->value;
		   			$new_section_con_logic['show'] = $section_cl_obj->show;
		   			$new_section_con_logic['any'] = $section_cl_obj->any;

		   			$new_ins_section_conlog = json_encode($new_section_con_logic);
	   			}else{
	   				$new_ins_section_conlog = '';
	   			}

	   			$update_section_conlog['conditional_logic'] = $new_ins_section_conlog;
	   			$id = array_search($section['id'], $temp_old_section);
				$this->kuesioner_section_m->update_kuesioner_section($update_section_conlog,$temp_new_section[$id]);
   			}
   		}
    }

    /**
     * Menambahkan field hasil cloning
     *
     * Fungsi ini akan menambahkan data field hasil cloning dari kuesioner_sections master
     * @param   array $all_pages semua page yang ada pada kuesioner_pages master
     * @param   array $all_sections semua section yang ada pada kuesioner_section master
     * @param   array $all_fields semua field yang ada pada kuesioner_fields master
     * @param   array $temp_new_page temporary id dari page yang baru (data cloning)
     * @param   array $temp_new_section temporary id section yang baru (data cloning)
     * @param   array $temp_new_field temporary id field yang baru (data cloning)
     * @param   array $temp_old_field temporary id field yang ada pada kuesioner_fields master
     * @return	void
     */
    public function update_field_conditional_logic($all_pages, $all_sections, $all_fields, $temp_new_page, $temp_new_section, $temp_new_field, $temp_old_field){
    	foreach ($all_fields as $field) {
	   		$new_field_con_logic = array();
			$new_field_con_logic['options'] = array();
			$new_field_con_logic['values'] = array();
			$new_field_con_logic['isnot'] = array();
			$new_field_con_logic['show'] = array();
			$new_field_con_logic['any'] = array();
			if($field['conditional_logic'] != ''){ 
				$field_cl_obj = json_decode($field['conditional_logic']);
	   			$field_condition = $field_cl_obj->options;
	   			if($field_condition != ''){
	   				foreach ($field_condition as $fc => $field_value) {
	   					list($p_id,$s_id,$id_h)=explode("_",$field_value);
	   					$page_in_condtional = $this->kuesioner_page_m->get_kuesioner_page_by_id($p_id);
	   					$page_in_condtional_cl_obj = json_decode($page_in_condtional['sections']);
	   					$page_in_condtional_val = $page_in_condtional_cl_obj->urutan;
	   					$key_page = array_search((string)$p_id, $all_pages);
	   					$inserted_page = $this->kuesioner_page_m->get_kuesioner_page_by_id($temp_new_page[$key_page]);
	   					$key_section = array_search((string)$s_id, $page_in_condtional_val);
	   					$array_order_section = json_decode($inserted_page['sections']);
	   					$inserted_section_obj = $array_order_section->urutan;
	   					$inserted_section = $inserted_section_obj[$key_section];
		   				$new_opt = $temp_new_page[$key_page]."_".$inserted_section."_".$id_h;
		   				array_push($new_field_con_logic['options'], $new_opt);
		   			}
		   			$new_field_con_logic['values'] = $field_cl_obj->values;
		   			$new_field_con_logic['isnot'] = $field_cl_obj->isnot;
		   			$new_field_con_logic['show'] = $field_cl_obj->show;
		   			$new_field_con_logic['any'] = $field_cl_obj->any;
		   			$new_ins_field_conlog = json_encode($new_field_con_logic);
	   			}else{
	   				$new_ins_field_conlog = '';
	   			}
	   			$update_field_conlog['conditional_logic'] = $new_ins_field_conlog;
	   			$id = array_search($field['id'], $temp_old_field);
				$this->kuesioner_field_m->update_kuesioner_field($update_field_conlog,$temp_new_field[$id]);
			}
		}
    }

	/**
     * Mendownload kuesioner
     *
     * Fungsi ini untuk mendownload kuesioner
     * @param   int $id id kuesioner
     * @return	void
     */    
    public function download_kuesioner($id){
		$this->load->library('Pdf');
		$html2pdf = new HTML2PDF('P','A4','fr');
		// $pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		// $pdf->SetTitle('Pdf Example');
		// $pdf->SetHeaderMargin(30);
		// $pdf->SetTopMargin(20);
		// $pdf->setFooterMargin(20);
		// $pdf->SetAutoPageBreak(true);
		// $pdf->SetAuthor('Author');
		//$pdf->SetDisplayMode('real', 'default');
		
		// $pdf->AddPage(); 

		$kuesioner = $this->kuesioner_m->get_kuesioner_by_id($id);

		$all_pages = json_decode($kuesioner['pages']);
		$urutan_page = $all_pages->urutan;

		$html = '';
		$html .= "<h1>".$kuesioner['title']."</h1>";
		foreach ($urutan_page as $key => $page) {
			$html .= '<hr>';
			$detail_page = $this->kuesioner_page_m->get_kuesioner_page_by_id($page);
			$html .= '<h2>'.$detail_page['title'].'</h2>';
			// $pdf->Write(5,$detail_page['title']);
			$page_cl = json_decode($detail_page['conditional_logic'],true);
			//dump($cl);
            if ($page_cl['options'][0] != null) {
                $html .= "<b>Isi jika : </b>";//$cl["any"][0]."\n";
                for($i=0;$i<count($page_cl["options"]);$i++){
                    list($p_id,$s_id,$id_h)=explode("_",$page_cl["options"][$i]);
                    $halaman = $this->kuesioner_page_m->get_kuesioner_page_by_id($p_id);
                    $sesi = $this->kuesioner_section_m->get_kuesioner_section_by_id($s_id);
                    $field = $this->kuesioner_field_m->get_kuesioner_field_by_condition($id,$p_id,$s_id,$id_h);
                    $field_judul = json_decode($field['options']);
                    //$td = $td."Halaman ".$p_id." Sesi ".$s_id." Pertanyaan ".$id_h.": ".$cl["op_labels"][$i]." ".$cl["isnot"][$i]." ".$cl["val_labels"][$i]."\n";
                	
                	$html .= "<br>".$halaman['title']." Sesi ".$sesi['title']." Pertanyaan ".$field_judul->title[0]." adalah ".$page_cl['value'][$i] ;
                	// $pdf->Write(5, $halaman['title']." Sesi ".$sesi['title']." Pertanyaan ".$field_judul->title[0]." adalah ".$page_cl['value'][$i]);
                }
                //echo nl2br($td);
            }

            $all_section = json_decode($detail_page['sections']);
            $urutan_section = $all_section->urutan;
            foreach ($urutan_section as $key => $section) {

            	$detail_section = $this->kuesioner_section_m->get_kuesioner_section_by_id($section);

            	$html .= '<h3>'.$detail_section['title'].'</h3>';
            	// $pdf->Write(5,$detail_section['title']);
				$section_cl = json_decode($detail_section['conditional_logic'],true);
				//dump($cl);
	            if ($section_cl['options'][0] != null) {
	                $html .= "<b>Isi jika : </b>";//$cl["any"][0]."\n";
	                // $pdf->Write(5, "Isi jika :");
	                for($i=0;$i<count($section_cl["options"]);$i++){
	                    list($p_id,$s_id,$id_h)=explode("_",$section_cl["options"][$i]);
	                    $halaman = $this->kuesioner_page_m->get_kuesioner_page_by_id($p_id);
	                    $sesi = $this->kuesioner_section_m->get_kuesioner_section_by_id($s_id);
	                    $field = $this->kuesioner_field_m->get_kuesioner_field_by_condition($id,$p_id,$s_id,$id_h);
	                    $field_judul = json_decode($field['options']);
	                    //$td = $td."Halaman ".$p_id." Sesi ".$s_id." Pertanyaan ".$id_h.": ".$cl["op_labels"][$i]." ".$cl["isnot"][$i]." ".$cl["val_labels"][$i]."\n";
	                	$html .= "<br>".$halaman['title']." Sesi ".$sesi['title']." Pertanyaan ".$field_judul->title[0]." adalah ".$section_cl['value'][$i] ;
	                	// $pdf->Write(5,$halaman['title']." Sesi ".$sesi['title']." Pertanyaan ".$field_judul->title[0]." adalah ".$section_cl['value'][$i]);
	                }
	            }

	            $all_field = json_decode($detail_section['fields']);
	            $urutan_field = $all_field->urutan;
	            foreach ($urutan_field as $key => $field) {
	            	
	            	$detail_field = $this->kuesioner_field_m->get_kuesioner_field_by_condition($id, $page, $section, $field);
	            	//dump($detail_field);
	            	$field_option = json_decode($detail_field['options']);
	            	//dump($field_option);
	            	$html .= '<h5>'.$field_option->title[0].'</h5>';
	            	// $pdf->Write(5, $field_option->title[0]."       ");
	            	if($detail_field['type'] == 'single' || $detail_field['type'] == 'readonly' || $detail_field['type'] == 'date' || $detail_field['type'] == 'number' ){
	            		//$pdf->SetXY(15, 15);
	            		//$pdf->TextField('firstname', 50, 5);
						//$pdf->Ln(6);
	            		$html .= "<input type='text'>";
	            	}elseif ($detail_field['type'] == 'radio') {
	            		foreach ($field_option->val as $val) {
	            			$html .= "<input type='radio' name='".$field_option->title[0]."'>".$val."&nbsp;"; 
	            		}
	            	}elseif ($detail_field['type'] == 'dropdown' || $detail_field['type'] == 'checkbox') {
	            		$i = 0;
	            		if($detail_field['type'] == 'dropdown'){
	            			if(count($field_option->val) > 2 ){
	            				$html .= '(Pilih Salah Satu)<br>';
	            			}
	            		}else{
	            			if(count($field_option->val) > 2 ){
	            				$html .= '(Pilih Salah Satu)<br>';
	            			}
	            			$html .= '(Pilihan boleh lebih dari satu)<br>';
	            		}
	            		
	            		foreach ($field_option->val as $val) {
	            			if($val != ''){
								$html .= "<input type='checkbox' name='".$field_option->title[0]."' value='".$val."'>".$field_option->lab[$i]."<br>"; 
	            			}
	            			$i++;
	            		}
	            	}elseif ($detail_field['type'] == 'grid') {
	            		$html .= "<table class='question_grid'><tr>";
						$html .= "<td style='width: 500px'></td>";
							if(($field_option->end_sc[0] - $field_option->str_sc[0])==1){
								$html .= "<td style='width:10px'>".$field_option->str_lb[0]."</td>";
								$html .= "<td style='width:10px'>".$field_option->end_lb[0]."</td>";
							}else if (($field_option->end_sc[0] - $field_option->str_sc[0])==2){
								$html .= "<td style='width:10px'>".$field_option->str_lb[0]."</td>";
								$html .= "<td style='width:10px'>".$field_option->mid_lb[0]."</td>";
								$html .= "<td style='width:10px'>".$field_option->end_lb[0]."</td>";
							}else{
								$html .= "<td colspan=5>".$field_option->str_lb[0]."";
								$html .= "".$field_option->mid_lb[0]."";
								$html .= "".$field_option->end_lb[0]."</td>";
							}
						$html .= "</tr><tr>";
						$html .= "<td style='width: 500px'></td>";
							for($i=$field_option->str_sc[0];$i<=$field_option->end_sc[0];$i++){
								$html .= "<td class='grid_number'>".$i."</td>";
							}
						$html .= "</tr>";
						for($j=0;$j<count($field_option->row_qst);$j++){
						$html .= "<tr class='grid_row' id='grid_row_".$j."'>";
						$html .= "<td style='width: 500px' class='question'>".$field_option->row_qst[$j]."</td>";

							$temp_i = (int)(($field_option->end_sc[0]-$field_option->str_sc[0]+1)/2);
							for($i=$field_option->str_sc[0];$i<=$field_option->end_sc[0];$i++){
								$html .= "<td style='width:50px'><input type='radio' class='grid_radio grids' name='grid_radio_".$page."_".$section."_".$field."_".$j."' value=".$i."></td>";
							}
						$html .= "</tr>";
						}
						$html .= "</table>";
	            	} 
	            }
            }
		}

	    $html2pdf->WriteHTML($html);
	    $html2pdf->Output('Handouts of Kuesioner - '.$kuesioner['title'].'.pdf','D');
    }

    /**
     * Mengubah tampilan kuesioner
     *
     * Fungsi ini akan menampilkan form edit tampilan kuesioner dan menyimpan hasil perubahan ke database
     * @param   int $id id kuesioner
     * @return	void
     */
    public function edit_style(){
    	$id = $this->uri->segment(5);
    	$data['mode'] = 'new';
		$data['return'] = 'admin/kuesioner/kuesioner/index';

		$this->db->where('id',$id);
		$data['kuesioner'] = $this->db->get('kuesioner_kuesioner')->row_array();

		$this->db->where('id',$id);
		$data['style'] = $this->db->get('style_kuesioner')->row_array();
		if($_POST){
			$check = $this->kuesioner_m->is_style_exist($id);
			$value = array();
			if($check != 0){
				$value['style'] = $this->input->post('hasil');
				$this->kuesioner_m->update_style($value, $id);
			}else{
				$value['id'] = $id ;
				$value['style'] = $this->input->post('hasil');
				$this->kuesioner_m->insert_style($value);
			}
			redirect('admin/kuesioner/kuesioner/index');
		}
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner:new'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:plural'), '/admin/kuesioner/kuesioner/index')
			->set_breadcrumb(lang('kuesioner:kuesioner:style'))
			->build('admin/edit_style', $data);
    }
	// --------------------------------------------------------------------------

}