<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model Kuesioner_answer_m
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Models
 */
class Kuesioner_answer_m extends MY_Model {
	
	/**
	 * Mengambil data jawaban kuesioner
	 *
	 * Fungsi ini akan mengambil data jawaban kuesioner berdasarkan limit data dan halaman tertentu serta data filtering yang diperoleh dari form method GET
	 * @param array $pagination_config
	 * @return array
	*/
	public function get_kuesioner_answer($pagination_config = NULL)
	{
		$have_fill = array();
		if(isset($pagination_config['status']) && $pagination_config['status'] == 'not_fill'){
			$this->db->select('user_id');
			$this->db->where('kuesioner_id',$pagination_config['id_kuesioner']);
			$have_fill = $this->db->get('kuesioner_kuesioner_answer')->result_array();

			$user_fill = array();
			foreach ($have_fill as $key => $value) {
				array_push($user_fill, $value['user_id']);
			}

			$this->db->select('*');
			$this->db->where('name','alumni');
			$id_group = $this->db->get('default_groups')->row_array();

			//$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi, default_kuesioner_kuesioner_answer.status AS status, default_kuesioner_kuesioner_answer.answers AS answers, default_kuesioner_kuesioner_answer.created_on AS created_on, default_kuesioner_kuesioner_answer.updated_on AS updated_on');
			$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi');
			// $this->db->from('default_profiles');
			$this->db->where_not_in('default_profiles.user_id', $user_fill);
			$this->db->where('default_profiles.academic_nim !=', '');

			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
			// $result = $this->db->get('default_profiles');
			// $this->db->join('default_kuesioner_kuesioner_answer','default_users.id = default_kuesioner_kuesioner_answer.user_id','left outer');
			// $this->db->where('default_kuesioner_kuesioner_answer.status',NULL);

		}

		// if((isset($pagination_config['download']) && $pagination_config['download'] == 'unduh' ) || (isset($pagination_config['status']) && ($pagination_config['status'] == 'finish' || $pagination_config['status'] == 'ongoing' || $pagination_config['status'] == 'all'))){
		if((isset($pagination_config['status']) && ($pagination_config['status'] == 'finish' || $pagination_config['status'] == 'ongoing' || $pagination_config['status'] == 'all'))){
			$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi, default_kuesioner_kuesioner_answer.status AS status, default_kuesioner_kuesioner_answer.answers AS answers, default_kuesioner_kuesioner_answer.created_on AS created_on, default_kuesioner_kuesioner_answer.updated_on AS updated_on, default_kuesioner_kuesioner_answer.user_id AS user_id ');
			$this->db->from('default_kuesioner_kuesioner_answer');
			if(isset($pagination_config['status']) && $pagination_config['status'] == 'not_fill'){
				$this->db->join('default_profiles','default_kuesioner_kuesioner_answer.user_id = default_profiles.user_id', 'left outer');
				// $this->db->where('default_kuesioner_kuesioner_answer.status','');
			}else{
				$this->db->join('default_profiles','default_kuesioner_kuesioner_answer.user_id = default_profiles.user_id');
			}

			$this->db->where('default_kuesioner_kuesioner_answer.kuesioner_id',$pagination_config['id_kuesioner']);
			
			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['status']) && $pagination_config['status'] != 'all'){
				$this->db->where('default_kuesioner_kuesioner_answer.status',$pagination_config['status']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
		}elseif((isset($pagination_config['download']) && $pagination_config['download'] == 'unduh' )){
			$this->db->select('default_profiles.user_id AS user_id, default_profiles.academic_ipk AS academic_ipk, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi, (SELECT answers FROM `default_kuesioner_kuesioner_answer` WHERE user_id = `default_profiles`.`user_id` AND `default_kuesioner_kuesioner_answer`.kuesioner_id = '.(int) $this->uri->segment(5).') AS answers ');
			$this->db->from('default_profiles');
			$this->db->join('default_kuesioner_kuesioner_answer','default_kuesioner_kuesioner_answer.user_id = default_profiles.user_id', 'left outer');
			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
		}else{
			$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi');
			$this->db->from('default_profiles');
			$this->db->join('default_kuesioner_kuesioner_answer','default_kuesioner_kuesioner_answer.user_id = default_profiles.user_id', 'left outer');
			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
		}

		$this->db->where('default_groups.name','alumni');
		$this->db->join('default_users','default_profiles.user_id = default_users.id');
		$this->db->join('default_groups','default_users.group_id = default_groups.id');

		if(!isset($pagination_config['download']) || $pagination_config['download'] != 'unduh' ){
			$start = ($this->uri->segment($pagination_config['uri_segment'])) ? $this->uri->segment($pagination_config['uri_segment']) : 0;
			$this->db->limit($pagination_config['per_page'], $start);
		}

		if(isset($pagination_config['order_by'])){
			if(isset($pagination_config['status']) && $pagination_config['status'] == 'not_fill'){
				if($pagination_config['order_by'] == 'academic_nim'){
					$this->db->order_by("academic_nim", "asc"); 
				}
			}else{
				if($pagination_config['order_by'] == 'academic_nim'){
					$this->db->order_by("academic_nim", "asc"); 
				}elseif($pagination_config['order_by'] == 'created_on_old_to_new'){
					$this->db->order_by("default_kuesioner_kuesioner_answer.created_on", "asc"); 
				}elseif($pagination_config['order_by'] == 'created_on_new_to_old'){
					$this->db->order_by("default_kuesioner_kuesioner_answer.created_on", "desc");
				}elseif($pagination_config['order_by'] == 'updated_on_old_to_new'){
					$this->db->order_by("default_kuesioner_kuesioner_answer.updated_on", "asc");
				}elseif($pagination_config['order_by'] == 'updated_on_new_to_old'){
					$this->db->order_by("default_kuesioner_kuesioner_answer.updated_on", "desc"); 
				}
			}
		}

		$result = $this->db->get();
        return $result->result_array();
	}
	
	/**
     * Mengambil data jawaban kuesioner berdasarkan id tertentu
     *
     * @param int $id
     * @return obj
    */
	public function get_kuesioner_answer_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_answer');
		$result = $query->row_array();
		
		return $result;
	}
	
	/**
     * Menghitung jumlah data di tabel kuesioner_answer
     *
     * @return int
    */
	public function count_all_kuesioner_answer()
	{
		return $this->db->count_all('kuesioner_kuesioner_answer');
	}

	/**
     * Menghitung jumlah data di tabel kuesioner_answer berdasarkan id
     *
     * @param array $pagination_config kondisi pagination dan kondisi filtering tertentu
     * @return int
    */
	public function count_all_kuesioner_answer_by_kuesioner_id($pagination_config = NULL)
	{
		if(isset($pagination_config['status']) && $pagination_config['status'] == 'not_fill'){
			$this->db->select('user_id');
			$this->db->where('kuesioner_id',$pagination_config['id_kuesioner']);
			$have_fill = $this->db->get('kuesioner_kuesioner_answer')->result_array();

			$user_fill = array();
			foreach ($have_fill as $key => $value) {
				array_push($user_fill, $value['user_id']);
			}

			$this->db->select('*');
			$this->db->where('name','alumni');
			$id_group = $this->db->get('default_groups')->row_array();

			//$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi, default_kuesioner_kuesioner_answer.status AS status, default_kuesioner_kuesioner_answer.answers AS answers, default_kuesioner_kuesioner_answer.created_on AS created_on, default_kuesioner_kuesioner_answer.updated_on AS updated_on');
			$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi');
			$this->db->from('default_profiles');
			$this->db->where_not_in('user_id', $user_fill);
			$this->db->where('default_profiles.academic_nim !=', '');

			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
			// $this->db->join('default_kuesioner_kuesioner_answer','default_users.id = default_kuesioner_kuesioner_answer.user_id','left outer');
			// $this->db->where('default_kuesioner_kuesioner_answer.status',NULL);

		}elseif(isset($pagination_config['status']) && ($pagination_config['status'] == 'finish' || $pagination_config['status'] == 'ongoing')){
			$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi, default_kuesioner_kuesioner_answer.status AS status, default_kuesioner_kuesioner_answer.answers AS answers');
			$this->db->from('default_kuesioner_kuesioner_answer');
			$this->db->join('default_profiles','default_kuesioner_kuesioner_answer.user_id = default_profiles.user_id');
			$this->db->where('default_kuesioner_kuesioner_answer.kuesioner_id',$pagination_config['id_kuesioner']);
			
			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['status']) && ($pagination_config['status'] != 'all')){
				$this->db->where('default_kuesioner_kuesioner_answer.status',$pagination_config['status']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
		}else{
			$this->db->from('default_profiles');
			if(isset($pagination_config['academic_nim'])){
				$this->db->like('default_profiles.academic_nim',$pagination_config['academic_nim']);
			}

			if(isset($pagination_config['name'])){
				$this->db->like('default_profiles.display_name',$pagination_config['name']);
			}

			if(isset($pagination_config['academic_faculty'])){
				$this->db->where('default_profiles.academic_faculty',$pagination_config['academic_faculty']);
			}
			
			if(isset($pagination_config['academic_program'])){
				$this->db->where('default_profiles.academic_program',$pagination_config['academic_program']);
			}

			if(isset($pagination_config['academic_year'])){
				$this->db->where('default_profiles.academic_year',$pagination_config['academic_year']);
			}

			if(isset($pagination_config['additional']) && $pagination_config['additional'] != ''){
				$this->db->where($pagination_config['additional']);
			}

			if(isset($pagination_config['rules']) && $pagination_config['rules'] != ''){
				$this->db->where($pagination_config['rules']);
			}
		}
		$this->db->where('default_groups.name','alumni');
		$this->db->join('default_users','default_profiles.user_id = default_users.id');
		$this->db->join('default_groups','default_users.group_id = default_groups.id');
		return $this->db->count_all_results();
	}
	
	/**
     * Menghapus data jawaban berdasarkan id
     *
     * @param int $id
     * @return void
    */
	public function delete_kuesioner_answer_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('default_kuesioner_kuesioner_answer');
	}
	
	/**
     * Menambahkan data jawaban
     *
     * @param array $values field=>'value'
     * @return void
    */
	public function insert_kuesioner_answer($values)
	{
		$values['created'] = date("Y-m-d H:i:s");
		$values['created_by'] = $this->current_user->id;
		
		return $this->db->insert('default_kuesioner_kuesioner_answer', $values);
	}
	
	/**
     * Memperbaharui data jawaban
     *
     * @param array $values field=>'value'
     * @param int $row_id id
     * @return void
    */
	public function update_kuesioner_answer($values, $row_id)
	{
		$values['updated'] = date("Y-m-d H:i:s");
		
		$this->db->where('id', $row_id);
		return $this->db->update('default_kuesioner_kuesioner_answer', $values); 
	}

	/**
     * Menghitung responden yang mengisi jawaban kuesioner
     *
     * @param int $id id kuesioner
     * @param array $rules conditional_logic
     * @param array $additionals hak supervisi
     * @return int
    */
	public function get_entries_by_id($id, $rules, $additionals){
		if($rules != ''){
			$i = 0;
			$rule = json_decode($rules);
			if(isset($rule->options) && isset($rule->value)){
				if(is_array($rule->options)){
					foreach ($rule->options as $key => $value) {
						if($rule->options[$i] != '' && $rule->value[$i] != ''){
							if($rule->isnot[$i] == 'is'){
								$this->db->where($rule->options[$i].'=', $rule->value[$i]);
							}else{
								$this->db->where($rule->options[$i].'!=',$rule->value[$i]);
							}
						}
						$i++;
					}
				}
			}
		}

		if($additionals != ''){
			$i = 0;
			$additional = json_decode($additionals);
			if(isset($additional->options) && isset($additional->value)){
				if(is_array($additional->options)){
					foreach ($additional->options as $key => $value) {
						if($additional->options[$i] != '' && $additional->value[$i] != ''){
							if($additional->isnot[$i] == 'is'){
								$this->db->where($additional->options[$i].'=', $additional->value[$i]);
							}else{
								$this->db->where($additional->options[$i].'!=',$additional->value[$i]);
							}
						}
						$i++;
					}
				}
			}
		}
		$this->db->like('kuesioner_id',$id);
		$this->db->where('default_groups.name','alumni');
		$this->db->from('default_profiles');
		$this->db->join('default_users','default_profiles.user_id = default_users.id');
		$this->db->join('default_groups','default_users.group_id = default_groups.id');
		$this->db->join('default_kuesioner_kuesioner_answer','default_kuesioner_kuesioner_answer.user_id = default_profiles.user_id');
		$count = $this->db->count_all_results();
		return $count;
	}

	/**
     * Menghitung responden yang mengisi jawaban kuesioner berdasarkan status
     *
     * @param array $rules conditional_logic
     * @param array $additionals hak supervisi
     * @param int $id id kuesioner
     * @param string $status status pengisian
     * @return int
    */
	public function get_count_by_rules($rules, $additionals, $id, $status){
		if($rules != ''){
			$rule = json_decode($rules);
		}

		if($status != 'not_fill'){
			$i = 0;
			if($rules != ''){
				if(isset($rule->options) && isset($rule->value)){
					if(is_array($rule->options)){
						foreach ($rule->options as $key => $value) {
							if($rule->options[$i] != '' && $rule->value[$i] != ''){
								if($rule->isnot[$i] == 'is'){
									$this->db->where($rule->options[$i].'=', $rule->value[$i]);
								}else{
									$this->db->where($rule->options[$i].'!=',$rule->value[$i]);
								}
							}
							$i++;
						}
					}
				}
			}
			if($additionals != ''){
				$this->db->where($additionals);
			}
			$this->db->where('kuesioner_id',$id);
			$this->db->where('status',$status);
			$this->db->where('default_groups.name','alumni');
			$this->db->from('kuesioner_kuesioner_answer');
			$this->db->join('users','kuesioner_kuesioner_answer.user_id = users.id');
			$this->db->join('profiles','users.id = profiles.user_id');
			$this->db->join('groups','users.group_id = groups.id');
		}else{
			// $this->db->select('user_id');
			// $this->db->where('kuesioner_id',$id);
			// $have_fill = $this->db->get('kuesioner_kuesioner_answer')->result_array();

			// $user_fill = array();
			// foreach ($have_fill as $key => $value) {
			// 	array_push($user_fill, $value['user_id']);
			// }

			// $this->db->select('*');
			// $this->db->where('name','alumni');
			// $id_group = $this->db->get('default_groups')->row_array();

			$i = 0;
			if($rules != ''){
				if(isset($rule->options) && isset($rule->value)){
					if(is_array($rule->options)){
						foreach ($rule->options as $key => $value) {
							if($rule->options[$i] != '' && $rule->value[$i] != ''){
								if($rule->isnot[$i] == 'is'){
									$this->db->where($rule->options[$i].'=', $rule->value[$i]);
								}else{
									$this->db->where($rule->options[$i].'!=',$rule->value[$i]);
								}
							}
							$i++;
						}
					}
				}
			}
			if($additionals != ''){
				$this->db->where($additionals);
			}
			
			//$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi, default_kuesioner_kuesioner_answer.status AS status, default_kuesioner_kuesioner_answer.answers AS answers, default_kuesioner_kuesioner_answer.created_on AS created_on, default_kuesioner_kuesioner_answer.updated_on AS updated_on');
			$this->db->select('default_profiles.academic_nim AS nim, default_profiles.display_name AS name, default_profiles.academic_year AS angkatan, default_profiles.academic_faculty AS fakultas, default_profiles.academic_program AS prodi');
			$this->db->from('profiles');
			$this->db->join('users','users.id = profiles.user_id');
			$this->db->join('groups','users.group_id = groups.id');
			$this->db->where('default_groups.name','alumni');
			// $this->db->where_not_in('user_id', $user_fill);
			// $this->db->where('default_profiles.academic_nim !=', '');
		}
		return $this->db->count_all_results();
	}

	/**
     * Mengambil data kolom tertentu di tabel profiles
     *
     * @param string $field field yang ingin ditampilkan
     * @param int $id user_id
     * @return array
    */
	public function get_readonly_value($field, $id){
		$this->db->select($field);
		$this->db->where('user_id',$id);
		return $this->db->get('profiles')->row_array();
	}
}