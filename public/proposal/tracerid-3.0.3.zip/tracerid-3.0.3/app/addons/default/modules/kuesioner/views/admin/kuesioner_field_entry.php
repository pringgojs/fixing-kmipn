<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner_field:view'); ?></h1>
	
	<div class="btn-group content-toolbar">
		
		<a href="<?php echo site_url('admin/kuesioner/kuesioner_field/index'); ?>" class="btn btn-sm btn-yellow">
			<i class="icon-arrow-left"></i>
			<?php echo lang('kuesioner:back') ?>
		</a>

		<?php if(group_has_role('kuesioner', 'edit_all_kuesioner_field')){ ?>
			<a href="<?php echo site_url('admin/kuesioner/kuesioner_field/edit/'.$kuesioner_field['id']); ?>" class="btn btn-sm btn-yellow">
				<i class="icon-edit"></i>
				<?php echo lang('global:edit') ?>
			</a>
		<?php }elseif(group_has_role('kuesioner', 'edit_own_kuesioner_field')){ ?>
			<?php if($kuesioner_field->created_by_user_id == $this->current_user->id){ ?>
				<a href="<?php echo site_url('admin/kuesioner/kuesioner_field/edit/'.$kuesioner_field->id); ?>" class="btn btn-sm btn-yellow">
					<i class="icon-edit"></i>
					<?php echo lang('global:edit') ?>
				</a>
			<?php } ?>
		<?php } ?>

		<?php if(group_has_role('kuesioner', 'delete_all_kuesioner_field')){ ?>
			<a href="<?php echo site_url('admin/kuesioner/kuesioner_field/delete/'.$kuesioner_field['id']); ?>" class="confirm btn btn-sm btn-danger">
				<i class="icon-trash"></i>
				<?php echo lang('global:delete') ?>
			</a>
		<?php }elseif(group_has_role('kuesioner', 'delete_own_kuesioner_field')){ ?>
			<?php if($kuesioner_field->created_by_user_id == $this->current_user->id){ ?>
				<a href="<?php echo site_url('admin/kuesioner/kuesioner_field/delete/'.$kuesioner_field['id']); ?>" class="confirm btn btn-sm btn-danger">
					<i class="icon-trash"></i>
					<?php echo lang('global:delete') ?>
				</a>
			<?php } ?>
		<?php } ?>
		
	</div>
</div>

<div>
	<div class="row">
		<div class="entry-label col-sm-2">ID</div>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['id']; ?></div>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:id_html'); ?></div>
		<?php if(isset($kuesioner_field['id_html'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['id_html']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:kuesioner_id'); ?></div>
		<?php if(isset($kuesioner_field['kuesioner_id'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['kuesioner_id']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:page_id'); ?></div>
		<?php if(isset($kuesioner_field['page_id'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['page_id']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:section_id'); ?></div>
		<?php if(isset($kuesioner_field['section_id'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['section_id']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:type'); ?></div>
		<?php if(isset($kuesioner_field['type'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['type']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:options'); ?></div>
		<?php if(isset($kuesioner_field['options'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['options']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:required'); ?></div>
		<?php if(isset($kuesioner_field['required'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['required']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:conditional_logic'); ?></div>
		<?php if(isset($kuesioner_field['conditional_logic'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_field['conditional_logic']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:created'); ?></div>
		<?php if(isset($kuesioner_field['created'])){ ?>
		<div class="entry-value col-sm-8"><?php echo format_date($kuesioner_field['created'], 'd-m-Y G:i'); ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:updated'); ?></div>
		<?php if(isset($kuesioner_field['updated'])){ ?>
		<div class="entry-value col-sm-8"><?php echo format_date($kuesioner_field['updated'], 'd-m-Y G:i'); ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:created_by'); ?></div>
		<div class="entry-value col-sm-8"><?php echo user_displayname($kuesioner_field['created_by'], true); ?></div>
	</div>
</div>