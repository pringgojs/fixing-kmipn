<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Kuesioner Module
 *
 * Modul Kuesioner
 *
 */
class Kuesioner_kuesioner_page extends Public_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner_page';
	
    public function __construct()
    {
        parent::__construct();

        // -------------------------------------
		// Load everything we need
		// -------------------------------------

		$this->lang->load('buttons');
        $this->lang->load('kuesioner');
		
		$this->load->model('kuesioner_page_m');
    }

    /**
	 * List all kuesioner_page
     *
     * @return	void
     */
    public function index()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner_page') AND ! group_has_role('kuesioner', 'view_own_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
        // -------------------------------------
		// Pagination
		// -------------------------------------

		$pagination_config['base_url'] = base_url(). 'kuesioner/kuesioner_page/index';
		$pagination_config['uri_segment'] = 4;
		$pagination_config['total_rows'] = $this->kuesioner_page_m->count_all_kuesioner_page();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;
		
        // -------------------------------------
		// Get entries
		// -------------------------------------
		
        $data['kuesioner_page']['entries'] = $this->kuesioner_page_m->get_kuesioner_page($pagination_config);
		$data['kuesioner_page']['total'] = count($data['kuesioner_page']['entries']);
		$data['kuesioner_page']['pagination'] = $this->pagination->create_links();

		// -------------------------------------
		// Build the page. 
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_page:plural'))
			->set_breadcrumb('Home', '/')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:plural'))
			->build('kuesioner_page_index', $data);
    }
	
	/**
     * Display one kuesioner_page
     *
     * @return  void
     */
    public function view($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner_page') AND ! group_has_role('kuesioner', 'view_own_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Get our entry.
		// -------------------------------------
		
        $data['kuesioner_page'] = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);
		
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'view_all_kuesioner_page')){
			if($data['kuesioner_page']->created_by != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}

		// -------------------------------------
		// Build the page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_page:view'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:plural'), '/kuesioner/kuesioner_page/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:view'))
			->build('kuesioner_page_entry', $data);
    }
	
	/**
     * Create a new kuesioner_page entry
     *
     * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'create_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_page('new')){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_page:submit_success'));				
				redirect('kuesioner/kuesioner_page/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_page:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'kuesioner/kuesioner_page/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_page:new'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:plural'), '/kuesioner/kuesioner_page/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:new'))
			->build('kuesioner_page_form', $data);
    }
	
	/**
     * Edit a kuesioner_page entry
     *
     * We're passing the
     * id of the entry, which will allow entry_form to
     * repopulate the data from the database.
	 * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @param   int [$id] The id of the kuesioner_page to the be deleted.
     * @return	void
     */
    public function edit($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_page') AND ! group_has_role('kuesioner', 'edit_own_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_page')){
			$entry = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_page('edit', $id)){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_page:submit_success'));				
				redirect('kuesioner/kuesioner_page/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_page:submit_failure');
			}
		}
		
		$data['fields'] = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);
		$data['mode'] = 'edit';
		$data['return'] = 'kuesioner/kuesioner_page/view/'.$id;
		$data['entry_id'] = $id;
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
        $this->template->title(lang('kuesioner:kuesioner_page:edit'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:plural'), '/kuesioner/kuesioner_page/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:view'), '/kuesioner/kuesioner_page/view/'.$id)
			->set_breadcrumb(lang('kuesioner:kuesioner_page:edit'))
			->build('kuesioner_page_form', $data);
    }
	
	/**
     * Delete a kuesioner_page entry
     * 
     * @param   int [$id] The id of kuesioner_page to be deleted
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_page') AND ! group_has_role('kuesioner', 'delete_own_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_page')){
			$entry = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->kuesioner_page_m->delete_kuesioner_page_by_id($id);
		$this->session->set_flashdata('error', lang('kuesioner:kuesioner_page:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('kuesioner/kuesioner_page/index');
    }
	
	/**
     * Insert or update kuesioner_page entry in database
     *
     * @param   string [$method] The method of database update ('new' or 'edit').
	 * @param   int [$row_id] The entry id (if in edit mode).
     * @return	boolean
     */
	private function _update_kuesioner_page($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('field_name', lang('kuesioner:kuesioner_page:field_name'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->kuesioner_page_m->insert_kuesioner_page($values);
			}
			else
			{
				$result = $this->kuesioner_page_m->update_kuesioner_page($values, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}