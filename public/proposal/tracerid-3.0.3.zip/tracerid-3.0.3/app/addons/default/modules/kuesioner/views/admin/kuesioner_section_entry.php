<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner_section:view'); ?></h1>
	
	<div class="btn-group content-toolbar">
		
		<a href="<?php echo site_url('admin/kuesioner/kuesioner_section/index'); ?>" class="btn btn-sm btn-yellow">
			<i class="icon-arrow-left"></i>
			<?php echo lang('kuesioner:back') ?>
		</a>

		<?php if(group_has_role('kuesioner', 'edit_all_kuesioner_section')){ ?>
			<a href="<?php echo site_url('admin/kuesioner/kuesioner_section/edit/'.$kuesioner_section['id']); ?>" class="btn btn-sm btn-yellow">
				<i class="icon-edit"></i>
				<?php echo lang('global:edit') ?>
			</a>
		<?php }elseif(group_has_role('kuesioner', 'edit_own_kuesioner_section')){ ?>
			<?php if($kuesioner_section->created_by_user_id == $this->current_user->id){ ?>
				<a href="<?php echo site_url('admin/kuesioner/kuesioner_section/edit/'.$kuesioner_section->id); ?>" class="btn btn-sm btn-yellow">
					<i class="icon-edit"></i>
					<?php echo lang('global:edit') ?>
				</a>
			<?php } ?>
		<?php } ?>

		<?php if(group_has_role('kuesioner', 'delete_all_kuesioner_section')){ ?>
			<a href="<?php echo site_url('admin/kuesioner/kuesioner_section/delete/'.$kuesioner_section['id']); ?>" class="confirm btn btn-sm btn-danger">
				<i class="icon-trash"></i>
				<?php echo lang('global:delete') ?>
			</a>
		<?php }elseif(group_has_role('kuesioner', 'delete_own_kuesioner_section')){ ?>
			<?php if($kuesioner_section->created_by_user_id == $this->current_user->id){ ?>
				<a href="<?php echo site_url('admin/kuesioner/kuesioner_section/delete/'.$kuesioner_section['id']); ?>" class="confirm btn btn-sm btn-danger">
					<i class="icon-trash"></i>
					<?php echo lang('global:delete') ?>
				</a>
			<?php } ?>
		<?php } ?>
		
	</div>
</div>

<div>
	<div class="row">
		<div class="entry-label col-sm-2">ID</div>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['id']; ?></div>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:title'); ?></div>
		<?php if(isset($kuesioner_section['title'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['title']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:deskripsi'); ?></div>
		<?php if(isset($kuesioner_section['deskripsi'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['deskripsi']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:kuesioner_id'); ?></div>
		<?php if(isset($kuesioner_section['kuesioner_id'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['kuesioner_id']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:page_id'); ?></div>
		<?php if(isset($kuesioner_section['page_id'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['page_id']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:section_options'); ?></div>
		<?php if(isset($kuesioner_section['section_options'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['section_options']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:fields'); ?></div>
		<?php if(isset($kuesioner_section['fields'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['fields']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:conditional_logic'); ?></div>
		<?php if(isset($kuesioner_section['conditional_logic'])){ ?>
		<div class="entry-value col-sm-8"><?php echo $kuesioner_section['conditional_logic']; ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:created'); ?></div>
		<?php if(isset($kuesioner_section['created'])){ ?>
		<div class="entry-value col-sm-8"><?php echo format_date($kuesioner_section['created'], 'd-m-Y G:i'); ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:updated'); ?></div>
		<?php if(isset($kuesioner_section['updated'])){ ?>
		<div class="entry-value col-sm-8"><?php echo format_date($kuesioner_section['updated'], 'd-m-Y G:i'); ?></div>
		<?php }else{ ?>
		<div class="entry-value col-sm-8">-</div>
		<?php } ?>
	</div>

	<div class="row">
		<div class="entry-label col-sm-2"><?php echo lang('kuesioner:created_by'); ?></div>
		<div class="entry-value col-sm-8"><?php echo user_displayname($kuesioner_section['created_by'], true); ?></div>
	</div>
</div>