<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model Kuesioner_page_m
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Models
 */
class Kuesioner_page_m extends MY_Model {
	
	/**
	 * Mengambil semua data halaman kuesioner
	 *
	 * Fungsi ini akan mengambil semua data halaman kuesioner berdasarkan limit data dan start page tertentu
	 * @param array $pagination_config
	 * @return array
	*/
	public function get_kuesioner_page($pagination_config = NULL)
	{
		$this->db->select('*');
		
		$start = ($this->uri->segment($pagination_config['uri_segment'])) ? $this->uri->segment($pagination_config['uri_segment']) : 0;
		$this->db->limit($pagination_config['per_page'], $start);
		
		$query = $this->db->get('default_kuesioner_kuesioner_page');
		$result = $query->result_array();
		
        return $result;
	}
	
	/**
	 * Mengambil data halaman kuesioner berdasarkan id
	 *
	 * @param int $id
	 * @return array
	*/
	public function get_kuesioner_page_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_page');
		$result = $query->row_array();
		
		return $result;
	}
	
	/**
	 * Mengambil jumlah data halaman kuesioner
	 *
	 * @return int
	*/
	public function count_all_kuesioner_page()
	{
		return $this->db->count_all('kuesioner_kuesioner_page');
	}
	
	/**
	 * Menghapus data halaman kuesioner tertentu
	 *
	 * @param int $id
	 * @return void
	*/
	public function delete_kuesioner_page_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('default_kuesioner_kuesioner_page');
	}
	
	/**
	 * Menambah data halaman kuesioner
	 *
	 * @param array $values field=>value
	 * @return void
	*/
	public function insert_kuesioner_page($values)
	{
		$values['created_on'] = date("Y-m-d H:i:s");
		$values['created_by'] = $this->current_user->id;
		
		return $this->db->insert('default_kuesioner_kuesioner_page', $values);
	}
	
	/**
	 * Mengubah data halaman kuesioner berdasarkan id
	 *
	 * @param array $values field=>value
	 * @param int $row_id id
	 * @return void
	*/
	public function update_kuesioner_page($values, $row_id)
	{
		$values['updated_on'] = date("Y-m-d H:i:s");
		
		$this->db->where('id', $row_id);
		return $this->db->update('default_kuesioner_kuesioner_page', $values); 
	}
	
	/**
	 * Mengambil semua data halaman berdasarkan kuesioner tertentu
	 *
	 * @param int $id kuesioner_id
	 * @return obj
	*/
	public function get_all_page_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('kuesioner_id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_page');
		//$result = $query->result_array();
		return $query->result();
	}

	/**
	 * Mengambil data section berdasarkan halaman tertentu
	 *
	 * @param int $id page_id
	 * @return array
	*/
	public function get_sections($id){
		$this->db->select('sections');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_page');
		$result = $query->row_array();
		
		return $result;
	}

	/**
	 * Mengambil data halaman berdasarkan id dan kuesioner tertentu
	 *
	 * @param int $order page_id
	 * @param int $kuesioner_id
	 * @return obj
	*/
	public function get_page_by_order($order, $kuesioner_id){
		$this->db->where('id',$order);
        $this->db->where('kuesioner_id',$kuesioner_id);
        $query = $this->db->get('default_kuesioner_kuesioner_page')->result();

        return $query;
	}

	/**
	 * Mengambil data halaman berdasarkan id
	 *
	 * @param int $id
	 * @return obj
	*/
	public function get_records($id){
		$this->select('*');
		$this->where('id',$id);
		$result = $this->db->get('kuesioner_kuesioner_page')->result();
		return $result;
	}

	/**
	 * Mengambil data section berdasarkan kondisi tertentu
	 *
	 * @param int $id_kuesioner 
	 * @param string $page_restrict_query 
	 * @return obj
	*/
	public function get_all_section_by_condition($id_kuesioner, $page_restrict_query){
		return $this->db->query("SELECT default_kuesioner_kuesioner_page.title AS page_id, default_kuesioner_kuesioner_page.title AS page_title, default_kuesioner_kuesioner_section.title AS section_title, default_kuesioner_kuesioner_field.id, id_html, default_kuesioner_kuesioner_field.kuesioner_id, default_kuesioner_kuesioner_field.section_id, default_kuesioner_kuesioner_field.page_id, type, options 
			FROM `default_kuesioner_kuesioner_field` INNER JOIN `default_kuesioner_kuesioner_page` INNER JOIN `default_kuesioner_kuesioner_section` ON  default_kuesioner_kuesioner_field.page_id=default_kuesioner_kuesioner_page.id AND default_kuesioner_kuesioner_field.section_id=default_kuesioner_kuesioner_section.id 
			WHERE default_kuesioner_kuesioner_field.kuesioner_id=$id_kuesioner $page_restrict_query AND (`type`='readonly' OR `type`='dropdown' OR `type`='radio' OR `type`='checkbox') ORDER BY default_kuesioner_kuesioner_field.page_id, default_kuesioner_kuesioner_field.section_id, default_kuesioner_kuesioner_field.id_html")->result();
	}

}