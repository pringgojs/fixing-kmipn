<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Kuesioner extends Module
{
    public $version = '1.1';

    public function info()
    {
        $info = array();
		$info['name'] = array(
			'en' => 'Kuesioner',
			'id' => 'Kuesioner',
		);
		$info['description'] = array(
			'en' => 'Modul Kuesioner',
			'id' => 'Modul Kuesioner',
		);
		$info['frontend'] = true;
		$info['backend'] = true;
		$info['menu'] = 'Kuesioner';
		$info['roles'] = array(
			'active_kuesioner','access_kuesioner_backend', 'view_all_kuesioner', 'view_own_kuesioner', 'edit_all_kuesioner', 'edit_own_kuesioner', 'delete_all_kuesioner', 'delete_own_kuesioner', 'create_kuesioner', 'activate_kuesioner', 'clone_all_kuesioner','download_all_kuesioner','view_entries', 'edit_style', 'download_entries',
			'access_kuesioner_section_backend', 'view_all_kuesioner_section', 'view_own_kuesioner_section', 'edit_all_kuesioner_section', 'edit_own_kuesioner_section', 'delete_all_kuesioner_section', 'delete_own_kuesioner_section', 'create_kuesioner_section',
			'access_kuesioner_page_backend', 'view_all_kuesioner_page', 'view_own_kuesioner_page', 'edit_all_kuesioner_page', 'edit_own_kuesioner_page', 'delete_all_kuesioner_page', 'delete_own_kuesioner_page', 'create_kuesioner_page',
			'access_kuesioner_field_backend', 'view_all_kuesioner_field', 'view_own_kuesioner_field', 'edit_all_kuesioner_field', 'edit_own_kuesioner_field', 'delete_all_kuesioner_field', 'delete_own_kuesioner_field', 'create_kuesioner_field',
			'access_kuesioner_answer_backend', 'view_all_kuesioner_answer', 'view_own_kuesioner_answer', 'edit_all_kuesioner_answer', 'edit_own_kuesioner_answer', 'delete_all_kuesioner_answer', 'delete_own_kuesioner_answer', 'create_kuesioner_answer',
		);
		
		if(group_has_role('kuesioner', 'access_kuesioner_backend')){
			$info['sections']['kuesioner']['name'] = 'kuesioner:kuesioner:plural';
			$info['sections']['kuesioner']['uri'] = 'admin/kuesioner/kuesioner/index';
			
			if(group_has_role('kuesioner', 'create_kuesioner')){
				$info['sections']['kuesioner']['shortcuts']['create'] = array(
					'name' => 'kuesioner:kuesioner:new',
					'uri' => 'admin/kuesioner/kuesioner/create',
					'class' => 'add'
				);
			}
		}
		/*
		if(group_has_role('kuesioner', 'access_kuesioner_section_backend')){
			$info['sections']['kuesioner_section']['name'] = 'kuesioner:kuesioner_section:plural';
			$info['sections']['kuesioner_section']['uri'] = 'admin/kuesioner/kuesioner_section/index';
			
			if(group_has_role('kuesioner', 'create_kuesioner_section')){
				$info['sections']['kuesioner_section']['shortcuts']['create'] = array(
					'name' => 'kuesioner:kuesioner_section:new',
					'uri' => 'admin/kuesioner/kuesioner_section/create',
					'class' => 'add'
				);
			}
		}
		
		if(group_has_role('kuesioner', 'access_kuesioner_page_backend')){
			$info['sections']['kuesioner_page']['name'] = 'kuesioner:kuesioner_page:plural';
			$info['sections']['kuesioner_page']['uri'] = 'admin/kuesioner/kuesioner_page/index';
			
			if(group_has_role('kuesioner', 'create_kuesioner_page')){
				$info['sections']['kuesioner_page']['shortcuts']['create'] = array(
					'name' => 'kuesioner:kuesioner_page:new',
					'uri' => 'admin/kuesioner/kuesioner_page/create',
					'class' => 'add'
				);
			}
		}
		
		if(group_has_role('kuesioner', 'access_kuesioner_field_backend')){
			$info['sections']['kuesioner_field']['name'] = 'kuesioner:kuesioner_field:plural';
			$info['sections']['kuesioner_field']['uri'] = 'admin/kuesioner/kuesioner_field/index';
			
			if(group_has_role('kuesioner', 'create_kuesioner_field')){
				$info['sections']['kuesioner_field']['shortcuts']['create'] = array(
					'name' => 'kuesioner:kuesioner_field:new',
					'uri' => 'admin/kuesioner/kuesioner_field/create',
					'class' => 'add'
				);
			}
		}
		
		if(group_has_role('kuesioner', 'access_kuesioner_answer_backend')){
			$info['sections']['kuesioner_answer']['name'] = 'kuesioner:kuesioner_answer:plural';
			$info['sections']['kuesioner_answer']['uri'] = 'admin/kuesioner/kuesioner_answer/index';
			
			if(group_has_role('kuesioner', 'create_kuesioner_answer')){
				$info['sections']['kuesioner_answer']['shortcuts']['create'] = array(
					'name' => 'kuesioner:kuesioner_answer:new',
					'uri' => 'admin/kuesioner/kuesioner_answer/create',
					'class' => 'add'
				);
			}
		}
		*/
		return $info;
    }
	
	/**
	 * Admin menu
	 *
	 * If a module has an admin_menu function, then
	 * we simply run that and allow it to manipulate the
	 * menu array
	 */
	public function admin_menu(&$menu_items, &$menu_order){
		
	}

    /**
     * Install
     *
     * This function will set up our streams
	 *
     */
    public function install()
    {
        $this->load->dbforge();

		// kuesioner
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'title' => array(
				'type' => 'VARCHAR',
				'constraint' => 128,
			),
			'deskripsi' => array(
				'type' => 'VARCHAR',
				'constraint' => 255,
				'null' => TRUE,
			),
			'entries' => array(
				'type' => 'INT',
				'constraint' => 1,
				'null' => TRUE,
			),
			'active_status' => array(
				'type' => 'TINYINT',
				'constraint' => 1,
				'null' => FALSE,
			),
			'pages' => array(
				'type' => 'TINYTEXT',
				'null' => TRUE,
			),
			'created_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'created_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'updated_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'updated_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'ordering_count' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('kuesioner_kuesioner', TRUE);
		$this->db->query("CREATE INDEX kuesioner_index ON default_kuesioner_kuesioner(created_by)");


		// kuesioner_section
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'title' => array(
				'type' => 'VARCHAR',
				'constraint' => 128,
			),
			'deskripsi' => array(
				'type' => 'VARCHAR',
				'constraint' => 255,
				'null' => TRUE,
			),
			'kuesioner_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'page_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'section_options' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'fields' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'conditional_logic' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'created_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'created_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'updated_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'updated_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'ordering_count' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('kuesioner_kuesioner_section', TRUE);
		$this->db->query("CREATE INDEX kuesioner_section_index ON default_kuesioner_kuesioner_section(created_by)");


		// kuesioner_page
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'title' => array(
				'type' => 'VARCHAR',
				'constraint' => 255,
				'null' => FALSE,
			),
			'kuesioner_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'deskripsi' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'sections' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'conditional_logic' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'created_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'created_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'updated_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'updated_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'ordering_count' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('kuesioner_kuesioner_page', TRUE);
		$this->db->query("CREATE INDEX kuesioner_page_index ON default_kuesioner_kuesioner_page(created_by)");


		// kuesioner_field
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'id_html' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'kuesioner_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'page_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'section_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'type' => array(
				'type' => 'VARCHAR',
				'constraint' => 32,
				'null' => FALSE,
			),
			'options' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'required' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => TRUE,
			),
			'conditional_logic' => array(
				'type' => 'TEXT',
				'null' => TRUE,
			),
			'created_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'created_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'updated_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'updated_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'ordering_count' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('kuesioner_kuesioner_field', TRUE);
		$this->db->query("CREATE INDEX kuesioner_field_index ON default_kuesioner_kuesioner_field(created_by)");


		// kuesioner_answer
		$fields = array(
			'kuesioner_id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'null' => FALSE,
			),
			'user_id' => array(
				'type' => 'BIGINT',
				'constraint' => 20,
				'null' => FALSE,
			),
			'username' => array(
				'type' => 'VARCHAR',
				'constraint' => 30,
				'null' => FALSE,
			),
			'answers' => array(
				'type' => 'TEXT',
				'null' => FALSE,
			),
			'status' => array(
				'type' => 'VARCHAR',
				'constraint' => 11,
				'null' => FALSE,
			),
			'created_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'created_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'updated_on' => array(
				'type' => 'DATETIME',
				'null' => TRUE,
			),
			'updated_by' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
			'ordering_count' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'null' => TRUE,
			),
		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('kuesioner_id', TRUE);
		$this->dbforge->add_key('user_id', TRUE);
		$this->dbforge->create_table('kuesioner_kuesioner_answer', TRUE);
		$this->db->query("CREATE INDEX kuesioner_answer_index ON default_kuesioner_kuesioner_answer(created_by)");

		return true;
    }

    /**
     * Uninstall
     *
     * Uninstall our module - this should tear down
     * all information associated with it.
     */
    public function uninstall()
    {
		$this->load->dbforge();
        $this->dbforge->drop_table('kuesioner_kuesioner');
        $this->dbforge->drop_table('kuesioner_kuesioner_section');
        $this->dbforge->drop_table('kuesioner_kuesioner_page');
        $this->dbforge->drop_table('kuesioner_kuesioner_field');
        $this->dbforge->drop_table('kuesioner_kuesioner_answer');
        return true;
    }

    public function upgrade($old_version)
    {
    	switch ($old_version) {
			case '1.0':
				$fields = array(
					'conditional_logic' => array(
						'type' => 'text',
						'null' => TRUE,
					),
				);
			$this->dbforge->add_column('kuesioner_kuesioner', $fields);
			default:
				// code...
				break;
		}
        return true;
    }

    public function help()
    {
        // Return a string containing help info
        // You could include a file and return it here.
        return "No documentation has been added for this module.<br />Contact the module developer for assistance.";
    }

}