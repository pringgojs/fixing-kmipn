<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$route['kuesioner/admin/kuesioner(:any)'] = 'admin_kuesioner$1';
$route['kuesioner/admin/kuesioner_section(:any)'] = 'admin_kuesioner_section$1';
$route['kuesioner/admin/kuesioner_page(:any)'] = 'admin_kuesioner_page$1';
$route['kuesioner/admin/kuesioner_field(:any)'] = 'admin_kuesioner_field$1';
$route['kuesioner/admin/kuesioner_answer(:any)'] = 'admin_kuesioner_answer$1';
$route['kuesioner/kuesioner(:any)'] = 'kuesioner_kuesioner$1';
$route['kuesioner/kuesioner_section(:any)'] = 'kuesioner_kuesioner_section$1';
$route['kuesioner/kuesioner_page(:any)'] = 'kuesioner_kuesioner_page$1';
$route['kuesioner/kuesioner_field(:any)'] = 'kuesioner_kuesioner_field$1';
$route['kuesioner/kuesioner_answer(:any)'] = 'kuesioner_kuesioner_answer$1';
