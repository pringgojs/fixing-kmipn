<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Kuesioner
 *
 * @author      PyroCMS
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Kuesioner extends Public_Controller
{
    /**
	 * Mengalihkan ke controller utama frontend
     *
     * @return	void
     */
	public function __construct()
    {
        parent::__construct();

        redirect('kuesioner/kuesioner/index');
    }

}