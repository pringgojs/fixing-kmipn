<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Kuesioner Module
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Admin extends Admin_Controller
{
    /**
	 * Mengalihkan ke controller utama backend
     *
     * @return	void
     */
	public function __construct()
    {
        parent::__construct();

        redirect('admin/kuesioner/kuesioner/index');
    }

}