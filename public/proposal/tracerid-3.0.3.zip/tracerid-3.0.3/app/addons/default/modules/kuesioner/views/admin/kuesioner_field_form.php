<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner_field:'.$mode); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="id_html"><?php echo lang('kuesioner:id_html'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('id_html') != NULL){
					$value = $this->input->post('id_html');
				}elseif($mode == 'edit'){
					$value = $fields['id_html'];
				}
			?>
			<input name="id_html" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="kuesioner_id"><?php echo lang('kuesioner:kuesioner_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('kuesioner_id') != NULL){
					$value = $this->input->post('kuesioner_id');
				}elseif($mode == 'edit'){
					$value = $fields['kuesioner_id'];
				}
			?>
			<input name="kuesioner_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="page_id"><?php echo lang('kuesioner:page_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('page_id') != NULL){
					$value = $this->input->post('page_id');
				}elseif($mode == 'edit'){
					$value = $fields['page_id'];
				}
			?>
			<input name="page_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="section_id"><?php echo lang('kuesioner:section_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('section_id') != NULL){
					$value = $this->input->post('section_id');
				}elseif($mode == 'edit'){
					$value = $fields['section_id'];
				}
			?>
			<input name="section_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="type"><?php echo lang('kuesioner:type'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('type') != NULL){
					$value = $this->input->post('type');
				}elseif($mode == 'edit'){
					$value = $fields['type'];
				}
			?>
			<input name="type" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="options"><?php echo lang('kuesioner:options'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('options') != NULL){
					$value = $this->input->post('options');
				}elseif($mode == 'edit'){
					$value = $fields['options'];
				}
			?>
			<input name="options" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="required"><?php echo lang('kuesioner:required'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('required') != NULL){
					$value = $this->input->post('required');
				}elseif($mode == 'edit'){
					$value = $fields['required'];
				}
			?>
			<input name="required" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="conditional_logic"><?php echo lang('kuesioner:conditional_logic'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('conditional_logic') != NULL){
					$value = $this->input->post('conditional_logic');
				}elseif($mode == 'edit'){
					$value = $fields['conditional_logic'];
				}
			?>
			<input name="conditional_logic" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

</div>

<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<button type="submit" class="btn btn-primary"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

<?php echo form_close();?>