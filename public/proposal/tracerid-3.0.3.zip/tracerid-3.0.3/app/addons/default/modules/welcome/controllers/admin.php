<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Welcome Module
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Welcome\Controllers
 */
class Admin extends Admin_Controller
{
   	/**
	 * Mengalihkan ke controller utama backend
     *
     * @return	void
     */
	public function __construct()
    {
        parent::__construct();

        redirect('admin/welcome/welcome/index');
    }

}