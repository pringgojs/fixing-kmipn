<form>
<?php if($this->session->userdata['group'] != 'alumni'){ ?>  
<select class="page_options" name="index_page">
    <?php
        foreach ($page_select as $key => $page_value) {
    ?>
        <option value = <?php echo $key; ?> <?php if($key == $this->input->get('index_page')){echo "selected";}?>><?php echo 'ID : '.$page_value['id'].' - '.$page_value['title']; ?></option>
    <?php } ?>
</select>
<input type="submit" value="Go">
<?php } ?>
</form>

<!--style-->
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery-ui.css" />
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery.ui.theme.css" />

<style>
    .submit_next, .submit_finish{
        background-color: #087BBA;
        color: white;
        margin-top: 10px;
    }
    .submit_prev{
        color: black;
        margin-top: 10px;
    }
    .kuesioner_title{
        background-color: #2D9FDE;
        color: white;
        font-size: 17pt;
        font-weight: bold;
        width: 100%;
        margin-top: 0px;
        margin-left: -20px;
        margin-bottom: 0px;
        padding-top: 10px;;
        padding-left: 10px;
        padding-bottom: 10px;
    }
    
    .kuesioner_description{
        font-size: 14pt;
        color: black;
        width: 100%;
        border: 1px dotted blue;
        border-top: white;
        border-left: white;
        border-right: white;
        margin-top: 2px;
        margin-left: -20px;
        padding-top:5px;
        padding-bottom: 5px;
        padding-left: 10px
    }
    .page_title{
        font-size: 13pt;
        font-weight: bold;
        margin-bottom: 15px;
    }
    .page_description{
        margin-left: 5px;
        margin-bottom: 15px;
        padding-bottom: 10px;
        color: #00cccc;
    }
    .section_title{
        font-size: 12pt;
        font-weight: bold;
        color: #003333;
        opacity: 0.5;
    }
    .section_description{
        font-size: 11pt;
        font-style: italic;
    }
    .section_body{
        padding-bottom: 10px;
        margin-top: 10px;
        margin-bottom: 10px;
        border: 1px dotted #003333;
        border-top: white;
        border-left: white;
        border-right: white;
    }
    
    .field_title{
        font-family: inherit;
        font-size: 12pt;
        font-weight: 500;
        background-color: #B3E4F3;
        margin-top: 10px;
        margin-bottom: 5px;
        padding-top: 3px;
        padding-bottom: 3px;
    }
    .question_grid td{
        border-right: 0px;
        border-left: 0px;
    }
    .question_scale td{
        border-right: 0px;
        border-left: 0px;
    }
    
</style>

<!--script-->
<script src="<?php echo base_url();?>system/cms/themes/ace/js/json3.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-1.10.1.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-ui-1.10.1.custom.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-2.0.3.min.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/autoNumeric.js"></script>

<script type="text/javascript">
function set_section(){
    var q_id;
    var p_id;
    var s_id;
    <?php foreach($answers as $answer):?>
        var prev_answer = JSON.stringify(<?php echo $answer->answers?>);
        prev_answer = jq.parseJSON(prev_answer);
    <?php endforeach;?>
    
        <?php foreach($page_sections as $section):?>
            q_id = <?php echo $section->kuesioner_id?>;
            p_id = <?php echo $section->page_id?>;
            s_id = <?php echo$section->id?>;
            var cl_obj = JSON.stringify(<?php echo $section->conditional_logic?>);
            if(cl_obj!=null){
                cl_obj=jq.parseJSON(cl_obj);
                for(i=0;i<cl_obj['options'].length;i++){
                    var truth_val = false;
                    var p_target = cl_obj['options'][i].split("_")[0];
                    var s_target = cl_obj['options'][i].split("_")[1];
                    var id_target = cl_obj['options'][i].split("_")[2];
                    var exp_val = cl_obj['value'][i];
                    var act_val = jq('#'+s_target+'_'+id_target).find('.checks:checked').val();
                    if (act_val==null){
                        act_val = jq('#'+s_target+'_'+id_target).find('.selects').find('selected').val();
                    }
//                  
                    if(cl_obj['any'][i]=="any"){
                        if(cl_obj['isnot'][i]=="is"){
                            if(exp_val==act_val){
                                truth_val=true;
                            }
                        }else if(cl_obj['isnot'][i]=="not"){
                            if(exp_val!=act_val){
                                truth_val=true;
                            }
                        }
                    //}else if(cl_obj['all'][i]=="all"){
					}else{
                        truth_val=true;
                        if(cl_obj['isnot'][i]=="is"){
                            if(exp_val!=act_val){
                                truth_val=false;
                            }
                        }else if(cl_obj['isnot'][i]=="not"){
                            if(exp_val==act_val){
                                truth_val=false;
                            }
                        }
                    }
                    
                    if(truth_val==true){
                        if(cl_obj['show'][0]=="show"){
                            jq('#sc_'+s_id).css({
                                "display":"block"
                            });
                        }
                        else{
                            jq('#sc_'+s_id).css({
                                "display":"none"
                            });
                        }
                    }else if(truth_val==false){
                        //alert("masuk sini");
                        if(cl_obj['show'][0]=="show"){
                            jq('#sc_'+s_id).css({
                                "display":"none"
                            });
                        }
                        else{
                            jq('#sc_'+s_id).css({
                                "display":"block"
                            });
                        }
                    }
                }
            }
        <?php endforeach; ?>
}

function set_section_cadangan(){
    var q_id;
    var p_id;
    var s_id;
	var prev_answer = null;
    <?php foreach($answers as $answer):?>
        prev_answer = JSON.stringify(<?php echo $answer->answers?>);
        prev_answer = jq.parseJSON(prev_answer);
    <?php endforeach;?>
    
        <?php foreach($page_sections as $section):?>
            q_id = <?php echo $section->kuesioner_id?>;
            p_id = <?php echo $section->page_id?>;
            s_id = <?php echo $section->id?>;
            var cl_obj = JSON.stringify(<?php echo $section->conditional_logic?>);
            if(cl_obj!=null){
                cl_obj=jq.parseJSON(cl_obj);
				var truth_val = false;
                for(i=0;i<cl_obj['options'].length;i++){
                    var p_target = cl_obj['options'][i].split("_")[0];
                    var s_target = cl_obj['options'][i].split("_")[1];
                    var id_target = cl_obj['options'][i].split("_")[2];
                    var exp_val = cl_obj['value'][i];
                    var act_val = jq('#'+s_target+'_'+id_target).find('.checks:checked').val();
					
                    if (act_val==null){
                        act_val = jq('#'+s_target+'_'+id_target).find('.selects').find(':selected').val();
						if(act_val!=null){
                            if(cl_obj['any'][0]=="any"){
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val==act_val){
                                        truth_val=true;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val!=act_val){
                                        truth_val=true;
                                    }
                                }
                            //}else if(cl_obj['all'][i]=="all"){
							}else{
                                truth_val=true;
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val!=act_val){
                                        truth_val=false;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val==act_val){
                                        truth_val=false;
                                    }
                                }
                            }
                        }
                        else if(act_val==null){
                            truth_val=false;
                        }
                    }else{
                        if(cl_obj['any'][0]=="any"){
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val==act_val){
                                        truth_val=true;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val!=act_val){
                                        truth_val=true;
                                    }
                                }
                            //}else if(cl_obj['all'][i]=="all"){
							}else{
                                truth_val=true;
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val!=act_val){
                                        truth_val=false;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val==act_val){
                                        truth_val=false;
                                    }
                                }
                            }
                    }
                    
                    if(truth_val==true){
                        if(cl_obj['show'][0]=="show"){
                            jq('#sc_'+s_id).css({
                                "display":"block"
                            });
                        }
                        else{
                            jq('#sc_'+s_id).css({
                                "display":"none"
                            });
                        }
                    }else if(truth_val==false){
                        //alert("masuk sini");
                        if(cl_obj['show'][0]=="show"){
                            jq('#sc_'+s_id).css({
                                "display":"none"
                            });
                        }
                        else{
                            jq('#sc_'+s_id).css({
                                "display":"block"
                            });
                        }
                    }
                }
            }
        <?php endforeach; ?>
}

function set_field(){
	var q_id;
    var p_id;
    var s_id;
    var id_h;
    <?php for($n=0;$n<count($sections);$n++){?>
        <?php foreach($sections[$n] as $section):?>
            <?php for($m=0;$m<count($fields[$n]);$m++){?>
                <?php foreach($fields[$n][$m] as $field):?>
                    q_id = <?php echo $field->kuesioner_id?>;
                    p_id = <?php echo $field->page_id?>;
                    s_id = <?php echo $field->section_id?>;
                    id_h = <?php echo $field->id_html?>;
                    var cl_obj = JSON.stringify(<?php echo $field->conditional_logic?>);
					
                    if(cl_obj!=null){
                        cl_obj=jq.parseJSON(cl_obj);
                        
						if(cl_obj['any'][0]=="any"){
							var truth_val = false;
						}else{
							var truth_val = true;
						}
                        
						for(i=0;i<cl_obj['options'].length;i++){
                            var p_target = cl_obj['options'][i].split("_")[0];
                            var s_target = cl_obj['options'][i].split("_")[1];
                            var id_target = cl_obj['options'][i].split("_")[2];
                            var exp_val = cl_obj['values'][i];
                            
                            var act_val = jq('#'+s_target+'_'+id_target).find('.checks:checked').val();
                            if (act_val==null){
                                act_val = jq('#'+s_target+'_'+id_target).find('.selects').find(':selected').val();
                            }
                            if(cl_obj['any'][0]=="any"){
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val==act_val){
                                        truth_val=true;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val!=act_val){
                                        truth_val=true;
                                    }
                                }
                            }else{
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val!=act_val){
                                        truth_val=false;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val==act_val){
                                        truth_val=false;
                                    }
                                }
                            }
                            
                            if(truth_val==true){
                                if(cl_obj['show'][0]=="show"){
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"block"
                                    });
                                }
                                else{
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"none"
                                    });
                                }
                            }else if(truth_val==false){
                                if(cl_obj['show'][0]=="show"){
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"none"
                                    });
                                }
                                else{
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"block"
                                    });
                                }
                            }
                        }
                        
                    }
                    <?php endforeach;?>
            <?php }?>
        <?php endforeach; ?>
    <?php } ?>
}

function set_field_cadangan(){
	var q_id;
	var p_id;
    var s_id;
    var id_h;
	var prev_answer = null;
    <?php foreach($answers as $answer):?>
        var prev_answer = JSON.stringify(<?php echo $answer->answers?>);
        prev_answer = jq.parseJSON(prev_answer);
    <?php endforeach;?>
    <?php for($n=0;$n<count($sections);$n++){?>
        <?php foreach($sections[$n] as $section):?>
            <?php for($m=0;$m<count($fields[$n]);$m++){?>
                <?php foreach($fields[$n][$m] as $field):?>
                    q_id = <?php echo $field->kuesioner_id?>;
					p_id = <?php echo $field->page_id?>;
                    s_id = <?php echo $field->section_id?>;
                    id_h = <?php echo $field->id_html?>;
                    var cl_obj = JSON.stringify(<?php echo $field->conditional_logic?>);
					
                    if(cl_obj!=null){
                        cl_obj=jq.parseJSON(cl_obj);

						var truth_val = false;
                        for(i=0;i<cl_obj['options'].length;i++){
                            var p_target = cl_obj['options'][i].split("_")[0];
                            var s_target = cl_obj['options'][i].split("_")[1];
                            var id_target = cl_obj['options'][i].split("_")[2];
                            var exp_val = cl_obj['values'][i];
                            
                            var act_val = jq('#'+s_target+'_'+id_target).find('.checks:checked').val();
                            if (act_val==null){
                                act_val = jq('#'+s_target+'_'+id_target).find('.selects').find(':selected').val();
                                if(act_val!=null){
                                    if(cl_obj['any'][0]=="any"){
                                        if(cl_obj['isnot'][i]=="is"){
                                            if(exp_val==act_val){
                                                truth_val=true;
                                            }
                                        }else if(cl_obj['isnot'][i]=="not"){
                                            if(exp_val!=act_val){
                                                truth_val=true;
                                            }
                                        }
                                    //}else if(cl_obj['all'][i]=="all"){
									}else{
                                        truth_val=true;
                                        if(cl_obj['isnot'][i]=="is"){
                                            if(exp_val!=act_val){
                                                truth_val=false;
                                            }
                                        }else if(cl_obj['isnot'][i]=="not"){
                                            if(exp_val==act_val){
                                                truth_val=false;
                                            }
                                        }
                                    }
                                }
                                else if(act_val==null){
                                    truth_val=false;
                                }
                            }
                            if(cl_obj['any'][0]=="any"){
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val==act_val){
                                        truth_val=true;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val!=act_val){
                                        truth_val=true;
                                    }
                                }
                            //}else if(cl_obj['all'][i]=="all"){
							}else{
                                truth_val=true;
                                if(cl_obj['isnot'][i]=="is"){
                                    if(exp_val!=act_val){
                                        truth_val=false;
                                    }
                                }else if(cl_obj['isnot'][i]=="not"){
                                    if(exp_val==act_val){
                                        truth_val=false;
                                    }
                                }
                            }
                            
                            if(truth_val==true){
                                if(cl_obj['show'][0]=="show"){
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"block"
                                    });
                                }
                                else{
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"none"
                                    });
                                }
                            }else if(truth_val==false){
                                if(cl_obj['show'][0]=="show"){
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"none"
                                    });
                                }
                                else{
                                    jq('#'+s_id+'_'+id_h).css({
                                        "display":"block"
                                    });
                                }
                            }
                        }
                        
                    }
                    <?php endforeach;?>
            <?php }?>
        <?php endforeach; ?>
    <?php } ?>
}

function add_datepicker(field, option, start, end){
    var yr = new Date();
    var yr1 = yr.getFullYear() - start;
    var yr2 = end - yr.getFullYear();

    if(option=="all"){
        jq(field).datepicker({
            dateFormat: 'dd/mm/yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-"+yr1+":+"+yr2+"",
            showButtonPanel: true

        });
    }
    else if (option=="two"){
        jq(field).datepicker({ 
            dateFormat: 'mm/yy',
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            yearRange:"-"+yr1+":+"+yr2+"",
            onClose: function(dateText, inst) {  
                var month = jq("#ui-datepicker-div .ui-datepicker-month :selected").val(); 
                var year = jq("#ui-datepicker-div .ui-datepicker-year :selected").val(); 
                //                        jq(this).val(jq.datepicker.formatDate('yy-mm', new Date(year, month, 1)));
                jq(this).datepicker('setDate', new Date(year, month, 1));
                jq(this).datepicker("refresh");
            }
        });

        jq(field).focus(function () {
            jq(".ui-datepicker-calendar").hide();
            jq("#ui-datepicker-div").position({
                my: "left top",
                at: "left bottom",
                of: jq(this)
            });    
        });

    }
    else{
        jq(field).datepicker({ 
            dateFormat: 'yy',
            changeMonth: false,
            changeYear: true,
            showButtonPanel: true,
            yearRange:"-"+yr1+":+"+yr2+"",
            onClose: function(dateText, inst) {  
                var year = jq("#ui-datepicker-div .ui-datepicker-year :selected").val(); 
                jq(this).datepicker('setDate', new Date(year, 1));
                jq(this).datepicker("refresh");
            }
        });

        jq(field).focus(function () {
            jq(".ui-datepicker-calendar").hide();
            jq(".ui-datepicker-month").hide();
            jq("#ui-datepicker-div").position({
                my: "left top",
                at: "left bottom",
                of: jq(this)
            });    
        });
    }

}

function cek_email(anu){
    var typingTimer;
    var doneTypingInterval = 5000;
 
    jq(anu).keyup(function(){
       typingTimer=setTimeout(doneTyping, doneTypingInterval); 
    });
 
    jq(anu).keydown(function(){
       clearTimeout(typing_timer); 
    });
    
    function doneTyping(){
        var em_text = anu.val();
        var email_reg =/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
            if(em_text==''){
                alert("harap isi alamat email Anda");
            }else{
                if(email_reg.test(em_text)){
                    alert("alamat email valid");
                }
                else{
                    alert("alamat email tidak valid!");
                }
            }
    }
}


</script>

<?php
if (isset($validation_errors) AND $validation_errors != ''){   
    echo '<div class="alert-message block-message error">' . $validation_errors . '</div>';
}
?>

<?php echo form_open_multipart($this->uri->uri_string(), 'class="module-form constrained ajax-form questionnaire"'); ?>

<input type="hidden" id="kuesioner_id" name="kuesioner_id" value="<?php echo $kuesioner['id']?>">

<input type="hidden" id="page_index" name="page_index" value="<?php echo $index?>">  

<p class="small" style="margin-bottom: 20px"><?php echo $page->deskripsi?></p>

<div id="<?php echo $page->id?>">
	
	<?php for($m=0;$m<count($sections);$m++){?>

	<?php foreach($sections[$m] as $section):?>

	<div class="section_content" id="sc_<?php echo $section->id?>">

	<fieldset>

	<?php $section_options = json_decode($section->section_options, true);?>

	<legend><?php if($section_options["title"][0]=="true"){echo $section->title;}?></legend>
	<span class="section_description"><?php if($section_options["description"][0]=="true"){echo $section->deskripsi;}?></span>

	<div class="section_content" id="sc_<?php echo $section->id?>">

		<div class="section_body" id="sb_<?php echo $section->id?>">

			<?php for($n=0;$n<count($fields[$m]);$n++){?>

			<?php foreach($fields[$m][$n] as $field):?>

			<?php $field_options = json_decode($field->options, true);?>

			<div class="question_content" id="<?php echo $field->section_id.'_'.$field->id_html?>">

				<label>
					<b>
					<span class="question">
					<?php echo $field_options["title"][0]?>
					</span>
					</b>

					<?php if($field_options['required'][0] == "true"): ?>
					<span style="color: red;">*</span>
					<?php endif; ?>
				</label>

				<div class="input">
					<?php if($field->type=="single"){?>

					<input type="text" class="question_single answer" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>">
					
					<?php if(isset($field_options['info'][0]) AND $field_options['info'][0] != ''): ?>
					<div class="block-info"><?php echo $field_options['info'][0] ?></div>
					<?php endif; ?>

					<?php }else if($field->type=="dropdown"){?>

						<select class="question_dropdown selects" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>">
							<?php for($i=0;$i<count($field_options["lab"]);$i++){ ?>
							<option value="<?php echo $field_options["val"][$i]?>"><?php echo $field_options["lab"][$i]?></option>
							<?php } ?>

							<?php
							$field_options = json_decode($field->options);
							$is_has_other_option = NULL;
							if(isset($field_options->has_other_option[0])){
								$is_has_other_option = $field_options->has_other_option[0];
							}
							if($is_has_other_option == 'true'):
							?>
							<option value="other">Lainnya</option>
							<?php endif; ?>
						</select>

						<?php if($is_has_other_option == 'true'): ?>

						<input type="text" class="other_answer" id="other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>" />
						
						<script>
                            // show or hide other answer text input on document ready
                            $(document).ready(function(){
                                if(jq('#<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').val() == 'other'){
                                    $('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').show();
                                }else{
                                    $('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').hide();
                                }
                            });
                            
                            // show or hide other answer text input on change
                            $('#<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').change(function(){
                                if(jq(this).val() == 'other'){
                                    $('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').show();
                                }else{
                                    $('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').hide();
                                }
                            });
                        </script>

						<?php endif; ?>

					<?php }else if($field->type=="checkbox"){ ?>

					<div class="question_checkboxes" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>" style="text-align: left;">

						<?php for($i=0;$i<count($field_options["lab"]);$i++){?>
							<input type="checkbox" class="question_checkbox checks" id="<?php echo "question_checkbox_".$field->id_html."_".$i?>" name="<?php echo "question_checkbox_".$field->id_html."_".$i?>" value="<?php echo $field_options["val"][$i]?>" style="padding:0px" > <?php echo $field_options["lab"][$i]?>
							<br>
						<?php }?>
						
						<?php
						$field_options = json_decode($field->options);
						$is_has_other_option = NULL;
						if(isset($field_options->has_other_option[0])){
							$is_has_other_option = $field_options->has_other_option[0];
						}
						if($is_has_other_option == 'true'):
						?>
					
						<input type="checkbox" class="question_radio checks" id="<?php echo "question_checkbox_".$field->id_html."_".$i?>" name="<?php echo "question_checkbox_".$field->section_id."_".$field->id_html?>" value="other" > Lainnya&nbsp;
						
						<input type="text" class="other_answer" id="other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>" />
						
						<script>
							// show or hide other answer text input on document ready
							jq(document).ready(function(){
								if(jq('#<?php echo "question_checkbox_".$field->id_html."_".$i?>').is(':checked')){
									jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').removeAttr('disabled');
								}else{
									jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').val('');
									jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').attr('disabled', 'disabled');
								}
							});
							
							// show or hide other answer text input on change
							jq('#<?php echo "question_checkbox_".$field->id_html."_".$i?>').change(function(){
								if(jq('#<?php echo "question_checkbox_".$field->id_html."_".$i?>').is(':checked')){
									jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').removeAttr('disabled');
								}else{
									jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').val('');
									jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').attr('disabled', 'disabled');
								}
							});
						</script>
						
						<?php endif; ?>

					</div>

					<?php }else if($field->type=="radio"){ ?>

					<div class="question_radios" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>">
					<?php for($i=0;$i<count($field_options["lab"]);$i++){?>
						<input type="radio" class="question_radio checks" id="<?php echo "question_radio_".$field->id_html."_".$i?>" name="<?php echo "question_radio_".$field->section_id."_".$field->id_html?>" value="<?php echo $field_options["val"][$i]?>" > <?php echo $field_options["lab"][$i]?> <br>
					<?php } ?>
					<?php
					$field_options = json_decode($field->options);
					$is_has_other_option = NULL;
					if(isset($field_options->has_other_option[0])){
						$is_has_other_option = $field_options->has_other_option[0];
					}
					if($is_has_other_option == 'true'):
					?>
					
					<input type="radio" class="question_radio checks" id="<?php echo "question_radio_".$field->id_html."_".$i?>" name="<?php echo "question_radio_".$field->section_id."_".$field->id_html?>" value="other" > Lainnya&nbsp;
					
					<input type="text" class="other_answer" id="other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>" />
						
					<script>
						// show or hide other answer text input on document ready
						jq(document).ready(function(){
							if(jq('input:radio[name=<?php echo "question_radio_".$field->section_id."_".$field->id_html?>]:checked').val() == 'other'){
								jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').removeAttr('disabled');
							}else{
								jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').val('');
								jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').attr('disabled', 'disabled');
							}
						});
						
						// show or hide other answer text input on change
						jq('input:radio[name=<?php echo "question_radio_".$field->section_id."_".$field->id_html?>]').change(function(){
							if(jq('input:radio[name=<?php echo "question_radio_".$field->section_id."_".$field->id_html?>]:checked').val() == 'other'){
								jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').removeAttr('disabled');
							}else{
								jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').val('');
								jq('#other_answer_<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>').attr('disabled', 'disabled');
							}
						});
					</script>
					
					<?php endif; ?>
					</div>

					<?php }else if($field->type=="scale"){?>
					
					<table class="question_scale" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>" style="text-align: center">
						<tr>
							<?php if(($field_options["end_sc"][0] - $field_options["str_sc"][0])==1){?>
							
							<td></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["str_lb"][0]?></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["end_lb"][0]?></td>
							<td></td>
							
							<?php }else if (($field_options["end_sc"][0] - $field_options["str_sc"][0])==2){?>
							
							<td></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["str_lb"][0]?></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["mid_lb"][0]?></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["end_lb"][0]?></td>
							<td></td>
							
							<?php }else{ ?>
							
							<td></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["str_lb"][0]?></td>
							<td colspan="<?php echo ($field_options["end_sc"][0] - 2)?>" style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["mid_lb"][0]?></td>
							<td style="text-align: center; margin: auto; padding-left: 0px"><?php echo $field_options["end_lb"][0]?></td>
							<td></td>
							
							<?php } ?>
						</tr>
						<tr>
							<td></td>
							<?php for($i=$field_options["str_sc"][0];$i<=$field_options["end_sc"][0];$i++){?>
							<td style="text-align: center; margin: auto; padding-left: 0px" class="scale_number"><?php echo $i?></td>
							<?php } ?>
							<td></td>
						</tr>
						<tr>
							<td></td>
							
							<?php $temp_i = (int)(($field_options["end_sc"][0]-$field_options["str_sc"][0]+1)/2);?>
							<?php for($i=$field_options["str_sc"][0];$i<=$field_options["end_sc"][0];$i++){?>
							<td style="text-align: center; margin: auto; padding-left: 0px" width="100px"><input type="radio" class="question_scale_radio checks" name="<?php echo "scale_radio_".$field->page_id."_".$field->section_id."_".$field->id_html?>" value="<?php echo $i?>" <?php if($i==($temp_i+1))?>></td>
							<?php } ?>
							
							<td></td>
						</tr>
					</table>

					<?php }else if($field->type=="grid"){ ?>

					<table class="question_grid" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>">
						<tr>
							<?php if(($field_options["end_sc"][0] - $field_options["str_sc"][0])==1){?>
							<td style="width: 550px"></td>
							<td style="width:10px"><?php echo $field_options["str_lb"][0]?></td>
							<td style="width:10px"><?php echo $field_options["end_lb"][0]?></td>
							<?php }else if (($field_options["end_sc"][0] - $field_options["str_sc"][0])==2){?>
							<td style="width: 550px"></td>
							<td style="width:10px"><?php echo $field_options["str_lb"][0]?></td>
							<td style="width:10px"><?php echo $field_options["mid_lb"][0]?></td>
							<td style="width:10px"><?php echo $field_options["end_lb"][0]?></td>
							<?php }else{ ?>
							<td style="width: 550px"></td>
							<td style="width:20px"><?php echo $field_options["str_lb"][0]?></td>
							<td colspan="<?php echo ($field_options["end_sc"][0] - 2)?>" style="text-align: center;"><?php echo $field_options["mid_lb"][0]?></td>
							<td style="width:20px"><?php echo $field_options["end_lb"][0]?></td>
							<?php } ?>
						</tr>
						<tr>
							<td style="width: 550px"></td>
							<?php for($i=$field_options["str_sc"][0];$i<=$field_options["end_sc"][0];$i++){?>
							<td style="width:35px; text-align: left" class="grid_number"><?php echo $i?></td>
							<?php } ?>
						</tr>
						<?php for($j=0;$j<count($field_options["row_qst"]);$j++){?>
						<tr class="grid_row" id="grid_row_<?php echo $j?>">
							<td style="width: 400px" class="question"><?php echo $field_options["row_qst"][$j]?></td>
							<?php $temp_i = (int)(($field_options["end_sc"][0]-$field_options["str_sc"][0]+1)/2);?>
							<?php for($i=$field_options["str_sc"][0];$i<=$field_options["end_sc"][0];$i++){?>
							<td><input type="radio" class="grid_radio grids" name="<?php echo "grid_radio_".$field->page_id."_".$field->section_id."_".$field->id_html."_".$j?>" value="<?php echo $i?>" <?php if($i==($temp_i+1))?>></td>
							<?php } ?>
						</tr>
						<?php } ?>
					</table>

					<?php } else if($field->type=="email"){ ?>

					<div class="question_email_attribs">
					<input type="hidden" class="answer_required" value="<?php if($field->required=="true"){echo "true";}else{echo "false";}?>">
					<input type="text" class="question_email answer" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>"> <span class="error_message"></span>
					</div>

					<?php } else if($field->type=="date"){?>

					<?php $date_attrib = json_decode($field->options,true);?>
					<div class="question_date_attribs">
					<input type="hidden" class="answer_required" value="<?php if($field->required=="true"){echo "true";}else{echo "false";}?>">
					<input type="hidden" class="date_start_year" name="date_start_year" value="<?php echo $date_attrib["str_yr"][0]?>">
					<input type="hidden" class="date_end_year" name="date_end_year" value="<?php echo $date_attrib["end_yr"][0]?>">
					<input type="hidden" class="date_option" name="date_option" value="<?php echo $date_attrib["date_opt"][0]?>">
					<input type="text" class="question_date answer" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>">
					
					<?php if(isset($field_options['info'][0]) AND $field_options['info'][0] != ''): ?>
					<div class="block-info"><?php echo $field_options['info'][0] ?></div>
					<?php endif; ?>
					
					</div>

					<?php } else if($field->type=="number"){?>

					<div class="question_number_attribs">
					<input type="hidden" class="answer_required" value="<?php if($field->required=="true"){echo "true";}else{echo "false";}?>">
					<input type="text" class="question_number answer" name="number" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>"> 
					
					<?php if(isset($field_options['info'][0]) AND $field_options['info'][0] != ''): ?>
					<div class="block-info"><?php echo $field_options['info'][0] ?></div>
					<?php endif; ?>
					
					<span class="error_message"></span>
					</div>

					<?php } else if($field->type=="phone"){?>

					<input type="hidden" class="answer_required" value="<?php if($field->required=="true"){echo "true";}else{echo "false";}?>">
					<div class="question_phone_attribs">
					<input type="text" class="question_phone answer" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>"> <span class="error_message"></span>
					</div>

					<?php } else if($field->type=="address"){?>

					<table class="question_address">
						<tr>
							<td>Alamat</td>
							<td colspan="3"><input type="text" class="address_street_name answer" name="address_street_name" id="<?php echo 'street_name_'.$field->page_id.'_'.$field->section_id.'_'.$field->id_html?>"></td>
						</tr>
						<tr>
							<td>Kota</td>
							<td><input type="text" class="address_city answer" name="address_city" id="<?php echo 'city_'.$field->page_id.'_'.$field->section_id.'_'.$field->id_html?>"></td>
							<td>Provinsi</td>
							<td>
								<select class="address_province selects" name="address_province" id="<?php echo 'province_'.$field->page_id.'_'.$field->section_id.'_'.$field->id_html?>">
									<option value="jakarta">Jakarta</option>
									<option value="jawa_barat">Jawa Barat</option>
									<option value="jawa_tengah">Jawa Tengah</option>
									<option value="jawa_timur">Jawa Timur</option>
									<option value="banten">Banten</option>
								</select>
							</td>
						</tr>
						<tr>
							<td>Kode Pos</td>
							<td colspan="3"><input type="text" class="address_zipcode answer" name="address_zipcode" id="<?php echo 'zipcode_'.$field->page_id.'_'.$field->section_id.'_'.$field->id_html?>"> <span class="error_message"></span></td>
						</tr>
					</table>

					<?php } else if($field->type=="readonly"){ ?>

					<div class="question_readonly_attribs">
					<?php
					// get user field
					$user_field = json_decode($field->options)->user_field[0];

					// get current user
					$id_user = $this->session->userdata('id');

					$this->db->where('users.id',$id_user);
					$this->db->from('users');
					$this->db->join('profiles','users.id = profiles.user_id');
					$user = $this->db->get()->row();

					// write text
					$value = '';
					if($user_field == 'display_name'){
						$value = $user->display_name;
						echo $value;
					}else{
						if(isset($user->{$user_field}) AND $user->{$user_field} != ''){
							$value = $user->{$user_field};
							echo $value;
						}else{
							echo '<i>NULL</i>';
						}
					}
					?>
					<input type="hidden" class="question_readonly answer" value="<?php echo $value; ?>" id="<?php echo $field->page_id.'_'.$field->section_id.'_'.$field->id_html?>" />
					</div>

					<?php } else if($field->type=="hidden"){}?>

				</div>
			</div>

			<?php endforeach;?>

			<?php }?>

		</div>
	</div>
	</fieldset>

	</div>

	<?php endforeach;?>
	<?php } ?>
</div>

<input type="hidden" id="hidden_answers" name="hidden_answers" >

</div>
<?php echo form_close(); ?>

<script>
jq = jQuery.noConflict(true);
jq(document).ready(function(){
    set_section_cadangan();
    set_field_cadangan();
   
    jq('[name=number]').autoNumeric('init', {mDec: '0'});  

    jq(".question_date").focus(function(){
        var start = jq(this).parents("div:first").find(".date_start_year").val();
        var end = jq(this).parents("div:first").find(".date_end_year").val();
        var option = jq(this).parents("div:first").find(".date_option").val();
        add_datepicker(jq(this), option, start, end );
    });
    jq(".checks, .selects").change(function(){
       set_section_cadangan();
       set_field();
    });
    
});
</script>

