<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Kuesioner Module
 *
 * Modul Kuesioner
 *
 */
class Kuesioner_kuesioner_answer extends Public_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner_answer';
	
    public function __construct()
    {
        parent::__construct();

        // -------------------------------------
		// Load everything we need
		// -------------------------------------

		$this->lang->load('buttons');
        $this->lang->load('kuesioner');
		
		$this->load->model('kuesioner_answer_m');
    }

    /**
	 * List all kuesioner_answer
     *
     * @return	void
     */
    public function index()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner_answer') AND ! group_has_role('kuesioner', 'view_own_kuesioner_answer')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
        // -------------------------------------
		// Pagination
		// -------------------------------------

		$pagination_config['base_url'] = base_url(). 'kuesioner/kuesioner_answer/index';
		$pagination_config['uri_segment'] = 4;
		$pagination_config['total_rows'] = $this->kuesioner_answer_m->count_all_kuesioner_answer();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;
		
        // -------------------------------------
		// Get entries
		// -------------------------------------
		
        $data['kuesioner_answer']['entries'] = $this->kuesioner_answer_m->get_kuesioner_answer($pagination_config);
		$data['kuesioner_answer']['total'] = count($data['kuesioner_answer']['entries']);
		$data['kuesioner_answer']['pagination'] = $this->pagination->create_links();

		// -------------------------------------
		// Build the page. 
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_answer:plural'))
			->set_breadcrumb('Home', '/')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:plural'))
			->build('kuesioner_answer_index', $data);
    }
	
	/**
     * Display one kuesioner_answer
     *
     * @return  void
     */
    public function view($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner_answer') AND ! group_has_role('kuesioner', 'view_own_kuesioner_answer')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Get our entry.
		// -------------------------------------
		
        $data['kuesioner_answer'] = $this->kuesioner_answer_m->get_kuesioner_answer_by_id($id);
		
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'view_all_kuesioner_answer')){
			if($data['kuesioner_answer']->created_by != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}

		// -------------------------------------
		// Build the page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_answer:view'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:plural'), '/kuesioner/kuesioner_answer/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:view'))
			->build('kuesioner_answer_entry', $data);
    }
	
	/**
     * Create a new kuesioner_answer entry
     *
     * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'create_kuesioner_answer')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_answer('new')){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_answer:submit_success'));				
				redirect('kuesioner/kuesioner_answer/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_answer:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'kuesioner/kuesioner_answer/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_answer:new'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:plural'), '/kuesioner/kuesioner_answer/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:new'))
			->build('kuesioner_answer_form', $data);
    }
	
	/**
     * Edit a kuesioner_answer entry
     *
     * We're passing the
     * id of the entry, which will allow entry_form to
     * repopulate the data from the database.
	 * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @param   int [$id] The id of the kuesioner_answer to the be deleted.
     * @return	void
     */
    public function edit($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_answer') AND ! group_has_role('kuesioner', 'edit_own_kuesioner_answer')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_answer')){
			$entry = $this->kuesioner_answer_m->get_kuesioner_answer_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_answer('edit', $id)){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_answer:submit_success'));				
				redirect('kuesioner/kuesioner_answer/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_answer:submit_failure');
			}
		}
		
		$data['fields'] = $this->kuesioner_answer_m->get_kuesioner_answer_by_id($id);
		$data['mode'] = 'edit';
		$data['return'] = 'kuesioner/kuesioner_answer/view/'.$id;
		$data['entry_id'] = $id;
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
        $this->template->title(lang('kuesioner:kuesioner_answer:edit'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:plural'), '/kuesioner/kuesioner_answer/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:view'), '/kuesioner/kuesioner_answer/view/'.$id)
			->set_breadcrumb(lang('kuesioner:kuesioner_answer:edit'))
			->build('kuesioner_answer_form', $data);
    }
	
	/**
     * Delete a kuesioner_answer entry
     * 
     * @param   int [$id] The id of kuesioner_answer to be deleted
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_answer') AND ! group_has_role('kuesioner', 'delete_own_kuesioner_answer')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_answer')){
			$entry = $this->kuesioner_answer_m->get_kuesioner_answer_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->kuesioner_answer_m->delete_kuesioner_answer_by_id($id);
		$this->session->set_flashdata('error', lang('kuesioner:kuesioner_answer:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('kuesioner/kuesioner_answer/index');
    }
	
	/**
     * Insert or update kuesioner_answer entry in database
     *
     * @param   string [$method] The method of database update ('new' or 'edit').
	 * @param   int [$row_id] The entry id (if in edit mode).
     * @return	boolean
     */
	private function _update_kuesioner_answer($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('field_name', lang('kuesioner:kuesioner_answer:field_name'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->kuesioner_answer_m->insert_kuesioner_answer($values);
			}
			else
			{
				$result = $this->kuesioner_answer_m->update_kuesioner_answer($values, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}