<script type="text/javascript" src="<?php echo base_url();?>system/cms/themes/ace/js/ckeditor/ckeditor.js"></script>
<div class="page-header">
	<h1><?php echo lang('welcome:welcome:'.$mode); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="welcome_message"><?php echo lang('welcome:welcome_message'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('welcome_message') != NULL){
					$value = $this->input->post('welcome_message');
				}elseif($mode == 'edit'){
					$value = $fields['welcome_message'];
				}
			?>
			<!--<input name="welcome_message" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			-->
			<textarea name="welcome_message" id="welcome_message"><?php echo $value; ?></textarea>
		</div>
	</div>

</div>

<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<button type="submit" class="btn btn-primary"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

<?php echo form_close();?>
<script type="text/javascript">
CKEDITOR.replace( 'welcome_message' );
</script>