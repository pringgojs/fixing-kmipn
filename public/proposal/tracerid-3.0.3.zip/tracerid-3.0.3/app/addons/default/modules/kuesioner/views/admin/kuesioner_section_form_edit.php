<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery-ui.css" />
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery.ui.theme.css" />
<!--<script src="jquery.min.js"></script>-->


<style>
    .ui-datepicker-month, .ui-datepicker-year{
        min-width: 0em;
    }


    .field_buttons_edit{
        font-family: inherit;
        font-size: 10pt;
        float: right;
        position: relative;
        margin: 5px;
    }
    .field_buttons_view{
        font-family: inherit;
        font-size: 10pt;
        float: right;
        position: relative;
        margin-top: 0px;
    }
    .field_header{
        /*border: solid 1px red;*/
        margin: 0px;
        background-color: #DFEFFF;
        height: 30px;
        cursor: move;
    }
    .field_container{
        /*border: solid 1px red;*/
        margin: 0px;
        background-color: white;
        padding-left: 5px;
        padding-top: 5px;
        padding-bottom: 5px;
    }
    .done_quest, .delete_quest, .edit_quest, .done_quest_dd, .edit_quest_dd, .delete_quest_dd, 
    .done_quest_cb, .edit_quest_cb, .delete_quest_cb,
    .done_quest_rb, .edit_quest_rb, .delete_quest_rb, 
    .done_quest_sc, .edit_quest_sc, .delete_quest_sc, 
    .done_quest_gr, .edit_quest_gr, .delete_quest_gr, 
    .done_quest_em, .edit_quest_em, .delete_quest_em, 
    .done_quest_no, .edit_quest_no, .delete_quest_no, 
    .done_quest_ph, .edit_quest_ph, .delete_quest_ph, 
    .done_quest_dt, .edit_quest_dt, .delete_quest_dt, 
    .done_quest_ad, .edit_quest_ad, .delete_quest_ad, 
    .done_quest_ro, .edit_quest_ro, .delete_quest_ro, 
    .done_quest_hd, .edit_quest_hd, .delete_quest_hd{
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        border-color: #533232;
        border: 1px solid;
        background-color: white;
        margin-left: 5px;
        padding: 2px;
    }

    #floating_question_selector{
        width:260px;
        height:220px;
        /*border:1px solid scrollbar;*/
        /*float: right;*/
        position: fixed;
        margin-left: 10px;
        /*bottom: 20px;*/
        top: 150px;
        right: 60px;
        z-index: 1;
        /*background-color: powderblue;*/
        border-radius: 10px;
    }
    #floating_label{
        background-color: powderblue;
        font-weight: bold;
        padding: 10px;
    }
    #questions_button{
        background-color: #DFEFFF;
        padding: 5px;
    }
    .quest_butt{
        width: 120px;
        /*margin-left: 10px;*/
    }
    #questions_panel{
        margin: 10px;
        height: auto;
        width: 960px;
    }
    .question_fields{
        margin-top: 5px;
        position: relative;
        /*border: 1px solid #02C2FF;*/
        /*background-color: powderblue;*/
        height: 25px;
        padding-bottom: 2px;
    }
    .single_edit_state, .dropdown_edit_state, .checkbox_edit_state, 
    .radio_edit_state, .scale_edit_state, .grid_edit_state, .email_edit_state, 
    .number_edit_state, .phone_edit_state, .date_edit_state, .address_edit_state,
    .readonly_edit_state, .hidden_view_state{
        display: none;
    }
    .done_quest, .done_quest_dd, .done_quest_cb, .done_quest_rb, .done_quest_sc, 
    .done_quest_gr, .done_quest_em, .done_quest_no, .done_quest_ph, .done_quest_dt, 
    .done_quest_ad, .done_quest_ro, .edit_quest_hd{
        display: none;
    }
    .CL_panel_field{
        display: none;
    }

</style>
<style>
    #sortable { list-style-type: none; margin: 0; padding: 0; width: 70%;}
    #sortable li { margin: 0 5px 5px 5px; padding: 3px; pading-left: 1.5em; font-size: 10pt; height: auto;}
    #sortable li span { position: absolute; margin-left: -1.3em; }
</style>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-1.9.0.min.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-ui-1.10.1.custom.js"></script>

<script type="text/javascript">
jq = jQuery.noConflict(true);
var opt_sum = 1;
var opt_sum_cb = 1;
var opt_sum_rb = 1;
var field_num_rb = 1;
var sum_quest_gr = 1;
var ad_cl_sum = 1;
var fields_sum = 0;
var fields_id = new Array();

jq(function() {
    jq( "#sortable" ).sortable({handle: ".field_header"});
    // jq( "#sortable" ).disableSelection();
});

function addpage(anu){
    var row = anu.parents("tr:first");
    if (anu.is(".up")) {
        row.insertBefore(row.prev());
    } else {
        row.insertAfter(row.next());
    }
}
function deletepage(anu){
    var row = anu.parents("tr:first");
    if(anu.is(".delete")){
        row.remove();
    }
}
function addCL(){
    var shows = '<select name="CL2" class="section_conditional" style="min-width:0em; max-width: 25em;" onchange="change_options_CL(jq(this))">'
    +'<?php foreach ($allfields as $af): if($af->section_id!=$id_section){?><?php $cl = json_decode($af->options,true); ?>'
    +'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>">'
    +'<?php echo "Page: ".$af->page_title." - Section: ".$af->section_title." - Question ".$af->id_html." : ".$cl["title"][0] ?>'
    +'</option><?php } endforeach;?></select>'
    +' <select name="is_not" class="section_is_not" style="min-width:0em"><option value="is">Is</option><option value="not">Is Not</option></select>'
    +' <select class="opt_vals" name="opt_vals" style="min-width:0em">'
        <?php foreach($allfields as $af): if($af->section_id!=$id_section){
                $cl_options = json_decode($af->options, true);
                for($k=0;$k<count($cl_options["lab"]);$k++){ ?>
                    +'<option value="<?php echo $cl_options["val"][$k]?>">'
                        +'<?php echo $cl_options["lab"][$k]?>'
                   +'</option>'
                <?php } break;} endforeach; ?>+'</select>'
    var add_remove = ' <a href=# class="addCL">Add</a> <a href=# class="removeCL">Remove</a>';
    var newCLpanel = jq('<div class="input">'+shows+''+add_remove+'</div>');
    jq('.CLpanel').append(newCLpanel);
    newCLpanel.find(".addCL,.removeCL").click(function(event){
        if(jq(this).is(".addCL")){
            event.preventDefault();
            addCL();
        }
        else{
            event.preventDefault();
            jq(this).parent().remove();  
        } 
    });
}
function removeCL(event){
    event.preventDefault();
    jq(this).parent.remove();
}
function change_options_CL(anu){
    var temp = [];
    
    var select = anu.parents("div:first").find(".opt_vals");
    var options = '';
    var page_id = anu.val().split("_")[0];
    var section_id = anu.val().split("_")[1];
    var id_html = anu.val().split("_")[2];
    select.html("");
    <?php foreach ($allfields as $af): $cl_options = json_decode($af->options,true);  ?>
      var p_id = <?php echo $af->page_id?>;
      var s_id = <?php echo $af->section_id?>;
      var id_h = <?php echo $af->id_html?>;
      if(page_id==p_id && section_id==s_id && id_html==id_h){
          <?php for($i=0;$i<count($cl_options["lab"]);$i++) {?>
                  select.append('<option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>');
          <?php } ?>
      }
    <?php endforeach;?>
    
    //alert(p_id);
  
}
function change_CL_field(anu){
    var select = anu.parents("div:first").find(".CL_field_options");
    var page_id = anu.val().split("_")[0];
    var section_id = anu.val().split("_")[1];
    var id_html = anu.val().split("_")[2];
    select.html("");
    <?php foreach ($allfields as $af): $cl_options=json_decode($af->options,true); ?>
      var p_id = <?php echo $af->page_id?>;
      var s_id = <?php echo $af->section_id?>;
      var id_h = <?php echo $af->id_html?>;
      if(page_id==p_id && section_id==s_id && id_html==id_h){
          <?php for($i=0;$i<count($cl_options["lab"]);$i++) {?>
                  select.append('<option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>');
          <?php } ?>
      }
    <?php endforeach;?>
}
function addCL_field(anu){
    var id_h = anu.parents("li:first").attr("id");
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    <?php foreach($allfields as $af):
            //if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php //} 
        endforeach;?>
                for(x=0;x<cl_opt["a"].length;x++){
            cl_options=cl_options+cl_opt["a"][x];
        }
    var CL_row = '<div class="CL_input_val">'
        +'<select id="CL_'+ad_cl_sum+'" class="CL_field_question" style="min-width:0em; max-width:25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_'+ad_cl_sum+'" class="field_is_not" style="min-width:0em">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="CL_ch_'+ad_cl_sum+'" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select>'
        +'<a href="#" class="addCL_field">Add</a> '
        +'<a href="#" class="removeCL_field">Remove</a>'
        +'</div>';
    var field = anu.parents("li:first").find(".CL_panel_field");
    CL_row = jq(CL_row);
    field.append(CL_row);
    CL_row.find(".addCL_field, .removeCL_field").click(function(event){
        if(jq(this).is(".addCL_field")){
            addCL_field(jq(this));
        }
        else{
            event.preventDefault();
            jq(this).parent().remove();
        }
    });
    ad_cl_sum+=1;
}

function checkCL_field(anu){
    var cb = anu.parents("li:first").find("field_CL");
    var panel = anu.parents("li:first").find(".CL_panel_field");
    if(jq(anu).is(':checked')){
        panel.show();
    }else{
        panel.hide();
    }
}

function deletequestion(anu){
    var q = anu.parents("li:first");
    q.remove();
    
}
function quest_done(anu){
    var view = anu.parents("li:first").find(".single_view_state");
    var edit = anu.parents("li:first").find(".single_edit_state");
    var qtext = anu.parents("li:first").find(".quest_text_field").val();
    anu.parents("li:first").find(".single_line_text").html(qtext);
    view.show();
    edit.hide();
}

function done_edit_delete_quest(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".single_view_state");
    var done_button = anu.parents("li:first").find(".done_quest");
    var edit = anu.parents("li:first").find(".single_edit_state");
    var edit_button = anu.parents("li:first").find(".edit_quest");
    var qtext = anu.parents("li:first").find(".question_title").val();
    if(anu.is('.done_quest')){
        anu.parents("li:first").find(".single_line_text").html(qtext);
        view.show();
        edit_button.show();
        edit.hide();
        done_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
   
}

function add_single_line(){
	//fields_sum++;
    var id = ++fields_sum;
    fields_id.push(id);
    
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var single_field = jq('<li id="'+id+'" class="single question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest">edit</a>'
        +'<a href="#" class="done_quest">done</a>'
        +'<a href="#" class="delete_quest">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Single Line Text: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="single_edit_state">'
        +'<div class="single_line">'
        +'Question Title <input type="text" name="single_quest_title" class="question_title"/><br />'
        +'Info <input type="text" class="question_info"/>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="single_view_state">'
        +'<div class="single_line_text">'
        +'Question Text?'
        +'</div>'
        +'<div class="single_line_answer">'    
        +'<input type="text" name="single_answer" />'                      
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(single_field);
    jq("#questions_panel ul li").show();
    
    single_field.find(".field_CL").click(function(){
        checkCL_field(jq(this));
    });
    single_field.find(".addCL_field").click(function(){
        addCL_field(jq(this)); 
    });
    single_field.find(".CL_field_question").change(function(){
       change_CL_field(jq(this)); 
    });
    single_field.find('.done_quest, .edit_quest, .delete_quest').click(function(){
        done_edit_delete_quest(jq(this));
    });
    //alert("bisa");
}

function add_opt_dd(anu){
            //opt_sum+=1;
    var opt_sum = anu.parents("li:first").find("#sum_opt_dd").val();
    ++opt_sum;
    anu.parents("li:first").find("#sum_opt_dd").val(opt_sum);
    var row = jq('<div class="option_dropdown" id="opt_dd_"'+opt_sum+'>'
        +'Option '+opt_sum+' <input type="text" name="label_option_'+opt_sum+'" class="label_opt" style="width: 25%; margin-left: 30px;" /> value: <input type="text" name="value_opt_'+opt_sum+'" class="val_opt" style="width: 25%; " /> <a href="#" class="add_opt_dd">Add</a> <a href=# class="remove_opt_dd">Remove</a>'
        +'</div>');
    var list = anu.parents("li:first").find(".dropdown_list");
    list.append(row);
    row.find('.add_opt_dd, .remove_opt_dd').click(function(event){
        if(jq(this).is('.add_opt_dd')){
            add_opt_dd(jq(this));
        }
        else{
            event.preventDefault();
            var opt_sum = anu.parents("li:first").find("#sum_opt_dd").val();
            --opt_sum;
            anu.parents("li:first").find("#sum_opt_dd").val(opt_sum);
            jq(this).parent().remove();
        }
    });
}

function add_opt_cb(anu){
    //opt_sum_cb+=1;
    var opt_sum_cb = anu.parents("li:first").find("#sum_opt_cb").val();
    ++opt_sum_cb;
    anu.parents("li:first").find("#sum_opt_cb").val(opt_sum_cb);
    var row = jq('<div class="option_checkbox" id="opt_cb_"'+opt_sum_cb+'>'
        +'Option '+opt_sum_cb+' <input type="text" name="label_option_'+opt_sum_cb+'" class="label_opt" style="width: 25%; margin-left: 30px;" /> value: <input type="text" name="value_option_'+opt_sum_cb+'" class="val_opt" style="width: 25%; " /> <a href="#" class="add_opt_cb">Add</a> <a href=# class="remove_opt_cb">Remove</a>'
        +'</div>');
    var list = anu.parents("li:first").find(".checkbox_list");
    list.append(row);
    row.find('.add_opt_cb, .remove_opt_cb').click(function(event){
        if(jq(this).is('.add_opt_cb')){
            add_opt_cb(jq(this));
        }
        else{
            event.preventDefault();
            var opt_sum_cb = anu.parents("li:first").find("#sum_opt_cb").val();
            --opt_sum_cb;
            anu.parents("li:first").find("#sum_opt_cb").val(opt_sum_cb);
            jq(this).parent().remove();
        }
    });
}
function add_opt_rb(anu){
    //opt_sum_rb+=1;
    var opt_sum_rb = anu.parents("li:first").find("#sum_opt_rb").val();
    ++opt_sum_rb;
    anu.parents("li:first").find("#sum_opt_rb").val(opt_sum_rb);
    var row = jq('<div class="option_radio" id="opt_rb_"'+opt_sum_rb+'>'
        +'Option '+opt_sum_rb+' <input type="text" name="label_option_'+opt_sum_rb+'" class="label_opt" style="width: 25%; margin-left: 30px;" /> value: <input type="text" name="value_option_'+opt_sum_rb+'" class="val_opt" style="width: 25%; " /> <a href="#" class="add_opt_rb">Add</a> <a href=# class="remove_opt_rb">Remove</a>'
        +'</div>');
    var list = anu.parents("li:first").find(".radio_list");
    list.append(row);
    row.find('.add_opt_rb, .remove_opt_rb').click(function(event){
        if(jq(this).is('.add_opt_rb')){
            add_opt_rb(jq(this));
        }
        else{
            event.preventDefault();
            var opt_sum_rb = anu.parents("li:first").find("#sum_opt_rb").val();
            --opt_sum_rb;
            anu.parents("li:first").find("#sum_opt_rb").val(opt_sum_rb);
            jq(this).parent().remove();
        }
    });
}

function upper_buttons_dd(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".dropdown_view_state");
    var edit = anu.parents("li:first").find(".dropdown_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_dd");
    var edit_button = anu.parents("li:first").find(".edit_quest_dd");
    var qtext = anu.parents("li:first").find(".question_title").val();
    var row = anu.parents("li:first").find(".option_list_view");
    var sum = anu.parents("li:first").find("#sum_opt_dd").val();
    var i = 1;
    
    if(anu.is('.done_quest_dd')){
        anu.parents("li:first").find(".question_text").html(qtext);
        row.html("");
        var val_list = new Array();
        var label_list = new Array();
        anu.parents("li:first").find(".label_opt").each(function(){
            var lab = jq(this).val();
            label_list.push(lab);
        });
        anu.parents("li:first").find(".val_opt").each(function(){
            var val = jq(this).val();
            val_list.push(val);
        });
        while(i<=sum){
            var j = (i-1);
            var opt = jq('<option name="view_option_'+i+'" id="view_option_'+i+'" value="'+val_list[j]+'">'+label_list[j]+'</option>');
            row.append(opt);
            
            i++;
        }
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_dd')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);

        }
    }
}

function upper_buttons_cb(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".checkbox_view_state");
    var edit = anu.parents("li:first").find(".checkbox_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_cb");
    var edit_button = anu.parents("li:first").find(".edit_quest_cb");
    var qtext = anu.parents("li:first").find(".question_title").val();
    var row = anu.parents("li:first").find(".option_checkbox_view");
    var sum = anu.parents("li:first").find("#sum_opt_cb").val();
    var i = 1;
    
    if(anu.is('.done_quest_cb')){
        anu.parents("li:first").find(".question_text").html(qtext);
        row.html("");    
        var val_list = new Array();
        var label_list = new Array();
        anu.parents("li:first").find(".label_opt").each(function(){
            var lab = jq(this).val();
            label_list.push(lab);
        });
        anu.parents("li:first").find(".val_opt").each(function(){
            var val = jq(this).val();
            val_list.push(val);
        });
        while(i<=sum){
            var j = (i-1);
            //                    var val_opt=anu.parents("li:first").find(".val_opt_"+i).val();
            //                    var label_opt=anu.parents("li:first").find(".label_opt_"+i).val();
            var opt = jq('<input type="checkbox" name="view_option_'+i+'" id="view_option_'+i+'" value="'+val_list[j]+'"> <label for="view_option_'+i+'" style="display: inline;">'+label_list[j]+'</label></br>');
            
            //var list = anu.parents("li:first").find(".option_checkbox_view_form");
            row.append(opt);
            //                    jq(".option_checkbox_view form").append(opt);
            i++;
        }
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_cb')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);

        }
    }
}

function upper_buttons_rb(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".radio_view_state");
    var edit = anu.parents("li:first").find(".radio_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_rb");
    var edit_button = anu.parents("li:first").find(".edit_quest_rb");
    var qtext = anu.parents("li:first").find(".question_title").val();
    var row = anu.parents("li:first").find(".option_radio_view");
    var sum = anu.parents("li:first").find("#sum_opt_rb").val();
    var i = 1;
    
    if(anu.is('.done_quest_rb')){
        anu.parents("li:first").find(".question_text").html(qtext);
        row.html("");
        var val_list = new Array();
        var label_list = new Array();
        anu.parents("li:first").find(".label_opt").each(function(){
            var lab = jq(this).val();
            label_list.push(lab);
        });
        anu.parents("li:first").find(".val_opt").each(function(){
            var val = jq(this).val();
            val_list.push(val);
        });
        while(i<=sum){
            //alert(opt_sum);
            var j = (i-1);
            //                    var val_opt=anu.parents("li:first").find(".val_opt_"+i).val();
            //                    var label_opt=anu.parents("li:first").find(".label_opt_"+i).val();
            var opt = jq('<input type="radio" name="view_option_'+id+'" id="view_option_'+i+'" value="'+val_list[j]+'"> <label for="view_option_'+id+'" style="display: inline;">'+label_list[j]+'</label></br>');
            
            //var list = anu.parents("li:first").find(".option_radio_view_form");
            row.append(opt);
            //                    jq(".option_radio_view form").append(opt);
            i++;
        }
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_rb')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);

        }
    }
}

function upper_buttons_sc(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".scale_view_state");
    var edit = anu.parents("li:first").find(".scale_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_sc");
    var edit_button = anu.parents("li:first").find(".edit_quest_sc");
    var qtext = anu.parents("li:first").find(".question_title").val();
    var row = anu.parents("li:first").find(".option_scale_view");
    var start_label = anu.parents("li:first").find(".start_label").val();
    var middle_label = anu.parents("li:first").find(".middle_label").val();
    var end_label = anu.parents("li:first").find(".end_label").val();
    var start_scale = anu.parents("li:first").find(".start_scale").find(":selected").val();
    var end_scale = anu.parents("li:first").find(".end_scale").find(":selected").val();
    var i = start_scale;
    
    if(anu.is('.done_quest_sc')){
        anu.parents("li:first").find(".question_text").html(qtext);
        anu.parents("li:first").find(".scale_label_first").html(start_label);
        anu.parents("li:first").find(".scale_label_second").html(middle_label);
        anu.parents("li:first").find(".scale_label_third").html(end_label);
        var tr1 = anu.parents("li:first").find(".num_label");
        var tr2 = anu.parents("li:first").find(".radio_scale");
        tr1.html("");
        tr2.html("");
        while(i<=end_scale){
            var num_label = '<td style="padding-left: 25px;">'+i+'</td>';
            var radio_scale = '<td><input type="radio" id="scale_radio_'+i+'" class="scale_radio" style="display: inline;" name="scale_radio_'+id+'"></td>'
            
            
            tr1.append(jq(num_label));
            tr2.append(jq(radio_scale));
            i++;
        }
         
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_sc')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);

        }
    }
}

function upper_buttons_gr(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id")
    var view = anu.parents("li:first").find(".grid_view_state");
    var edit = anu.parents("li:first").find(".grid_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_gr");
    var edit_button = anu.parents("li:first").find(".edit_quest_gr");
    var qtext = anu.parents("li:first").find(".question_title").val();
    var start_label = anu.parents("li:first").find(".start_label").val();
    var middle_label = anu.parents("li:first").find(".middle_label").val();
    var end_label = anu.parents("li:first").find(".end_label").val();
    var start_scale = anu.parents("li:first").find(".start_grid_scale").find(":selected").val();
    var end_scale = anu.parents("li:first").find(".end_grid_scale").find(":selected").val();
    var sum = anu.parents("li:first").find(".sum_row_question").val();
    var i = start_scale;
    var j = start_scale;
    var n = sum_quest_gr;
    var a = 1;
    
    if(anu.is('.done_quest_gr')){
        anu.parents("li:first").find(".question_text").html(qtext);
        anu.parents("li:first").find(".grid_label_first").html(start_label);
        anu.parents("li:first").find(".grid_label_second").html(middle_label);
        anu.parents("li:first").find(".grid_label_third").html(end_label);
        var question_list = new Array();
        anu.parents("li:first").find(".label_question").each(function(){
            var lab = jq(this).val();
            question_list.push(lab);
        });
        var num_row = anu.parents("li:first").find(".grid_view_set");
        num_row.html("");
        var num_tr = jq('<tr class=num_label><td style="width: 200px;"></td></tr>');
        num_row.append(num_tr);
        
        while(j<=end_scale){
            var nums = jq('<td style="padding-left: 25px;">'+j+'</td>');
            var num_label = anu.parents("li:first").find(".num_label");
            num_label.append(nums);
            j++;
        }
        
        while(a<=sum){
            //var qrow = anu.parents("li:first").find(".label_question_"+a+"").val();
            j= (a-1);
            var grid_quest = jq('<tr class="grid_scale_'+a+'"><td class="grid_row_question_'+a+'" name="grid_row_question_'+a+'" style="width: 200px;">'+question_list[j]+'</td></tr>');
            var gr_row = anu.parents("li:first").find(".grid_view_set");
            gr_row.append(grid_quest);
            
            while(i<=end_scale){
                var radio_col = jq('<td id="grid_radio_'+a+'_'+i+'"><input type="radio" class="grid_radio" style="display: inline;" name="grid_radio_'+id+'_'+a+'"></td>');
                var radio_tr = anu.parents("li:first").find(".grid_scale_"+a+"");
                radio_tr.append(radio_col);
                i++;
            }
            i=start_scale;
            a++;
        }
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_gr')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function upper_buttons_em(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".email_view_state");
    var edit = anu.parents("li:first").find(".email_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_em");
    var edit_button = anu.parents("li:first").find(".edit_quest_em");
    var qtext = anu.parents("li:first").find(".question_title").val();
    
    if(anu.is('.done_quest_em')){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_em')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function upper_buttons_ro(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".readonly_view_state");
    var edit = anu.parents("li:first").find(".readonly_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_ro");
    var edit_button = anu.parents("li:first").find(".edit_quest_ro");
    var qtext = anu.parents("li:first").find(".question_title").val();
    
    if(anu.is('.done_quest_ro')){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })

    }
    else if(anu.is('.edit_quest_ro')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function upper_buttons_no(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".number_view_state");
    var edit = anu.parents("li:first").find(".number_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_no");
    var edit_button = anu.parents("li:first").find(".edit_quest_no");
    var qtext = anu.parents("li:first").find(".question_title").val();
    
    if(anu.is(".done_quest_no")){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is(".edit_quest_no")){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function upper_buttons_ph(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".phone_view_state");
    var edit = anu.parents("li:first").find(".phone_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_ph");
    var edit_button = anu.parents("li:first").find(".edit_quest_ph");
    var qtext = anu.parents("li:first").find(".question_title").val();
    
    if(anu.is('.done_quest_ph')){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_ph')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function upper_buttons_dt(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".date_view_state");
    var edit = anu.parents("li:first").find(".date_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_dt");
    var edit_button = anu.parents("li:first").find(".edit_quest_dt");
    var qtext = anu.parents("li:first").find(".question_title").val();
    var date_option = anu.parents("li:first").find(".date_option").find(":selected").val();
    var start_year = anu.parents("li:first").find(".start_year").val();
    var end_year = anu.parents("li:first").find(".end_year").val();
    var input_field = anu.parents("li:first").find(".date_input_field");
    
    if(anu.is('.done_quest_dt')){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        });
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        });
        //                if (date_option=="all"){
        //                    jq(".date_input_field").on("click",function(){
        //                       jq(".ui-datepicker-calendar").css("display","table");
        //                    });
        //                }
        add_datepicker(input_field, date_option, start_year, end_year);
        
        
        
    }
    else if(anu.is('.edit_quest_dt')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }  
}

function upper_buttons_ad(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".address_view_state");
    var edit = anu.parents("li:first").find(".address_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_ad");
    var edit_button = anu.parents("li:first").find(".edit_quest_ad");
    var qtext = anu.parents("li:first").find(".question_title").val();
    
    if(anu.is('.done_quest_ad')){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_ad')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function upper_buttons_hd(anu){
    // event.preventDefault();
    var id = anu.parents("li:first").attr("id");
    var view = anu.parents("li:first").find(".hidden_view_state");
    var edit = anu.parents("li:first").find(".hidden_edit_state");
    var done_button = anu.parents("li:first").find(".done_quest_hd");
    var edit_button = anu.parents("li:first").find(".edit_quest_hd");
    var qtext = anu.parents("li:first").find(".question_title").val();
    
    if(anu.is('.done_quest_hd')){
        anu.parents("li:first").find(".question_text").html(qtext);
        view.show();
        edit.hide();
        done_button.hide();
        edit_button.show();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"white"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"#DFEFFF"
        })
    }
    else if(anu.is('.edit_quest_hd')){
        view.hide();
        edit.show();
        done_button.show();
        edit_button.hide();
        anu.parents("li:first").find(".field_container").css({
            "background-color":"#DFEFFF"
        })
        anu.parents("li:first").find(".field_header").css({
            "background-color":"powderblue"
        })
    }
    else{
        if (confirm('Apakah anda yakin untuk menghapus pertanyaan ini ?')) {
            var index = fields_id.indexOf(id);
            fields_id.splice(index,1);
            deletequestion(anu);
        }
    }
}

function add_grid_question(anu){
    //sum_quest_gr+=1;
    var sum= anu.parents("li:first").find(".sum_row_question").val();
    ++sum;
    anu.parents("li:first").find(".sum_row_question").val(sum);
    var qrow=jq('<div class="qrid_question_label_'+sum+'">'+
        'Question '+sum+' <input type="text" class="label_question" name="label_question_'+sum+'" style="margin-left: 17px;"> <a href="#" class="add_grid_question">Add</a> <a href="#" class="remove_grid_question">Remove</a>'+
        '</div>');
    //alert("how");
    var qlist = anu.parents("li:first").find(".option_grid");
    
    qlist.append(qrow);
    qrow.find('.add_grid_question, .remove_grid_question').click(function(event){
        if(jq(this).is('.add_grid_question')){
            event.preventDefault();
            add_grid_question(jq(this));
        }
        else{
            event.preventDefault();
            var sum= anu.parents("li:first").find(".sum_row_question").val();
            --sum;
            anu.parents("li:first").find(".sum_row_question").val(sum);
            jq(this).parent().remove();
        }
    });
}

function add_dropdown(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var dd=jq('<li id="'+id+'" class="dropdown question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_dd">edit</a>'
        +'<a href="#" class="done_quest_dd">done</a>'
        +'<a href="#" class="delete_quest_dd">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Dropdown: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="dropdown_edit_state">'
        +'<div class="dropdown_list">'
        +'Question Title <input type="text" name="dropdown_title" class="question_title"/>'
        +'<input type="hidden" name="sum_opt" id="sum_opt_dd" class="sum_opt" value="1">'
        +'<div class="option_dropdown" id="opt_dd_1">'
        +'Option 1 <input type="text" name="label_option_1" class="label_opt" style="width: 25%; margin-left: 30px;" /> value: <input type="text" name="value_opt_1" class="val_opt" style="width: 25%; " /> <a href="#" class="add_opt_dd">Add</a>'
        +'</div>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="has_other_option"> Has "Other" Option <br>'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;max-width:25em" onchange="change_CL_field(jq(this))">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="dropdown_view_state">'
        +'<div class="question_dropdown_list">'
        +'<div class="question_text">Question Text?</div>'
        +'<div class="option_dropdown_view" id="opt_dd_1">'
        +'<select class="option_list_view" name="option_list_view">'
                        
        +'</select>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(dd);
    jq("#questions_panel ul li").show();
    dd.find(".done_quest_dd, .edit_quest_dd, .delete_quest_dd").click(function(event){
        event.preventDefault();
        //alert("hai");
        upper_buttons_dd(jq(this));
    });
    dd.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    dd.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    dd.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    dd.find(".add_opt_dd, .remove_opt_dd").click(function(event){
        event.preventDefault();
        add_opt_dd(jq(this)); 
    });
}

function add_checkbox(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var cb=jq('<li id="'+id+'" class="checkbox question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_cb">edit</a>'
        +'<a href="#" class="done_quest_cb">done</a>'
        +'<a href="#" class="delete_quest_cb">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Checkbox: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="checkbox_edit_state">'
        +'<div class="checkbox_list">'
        +'Question Title <input type="text" name="dropdown_title" class="question_title"/>'
        +'<input type="hidden" name="sum_opt" id="sum_opt_cb" class="sum_opt_cb" value="1">'
        +'<div class="option_checkbox" id="opt_cb_1">'
        +'Option 1 <input type="text" name="label_option_1" class="label_opt" style="width: 25%; margin-left: 30px;" /> value: <input type="text" name="value_option_1" class="val_opt" style="width: 25%; " /> <a href="#" class="add_opt_cb">Add</a>'
        +'</div>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="has_other_option"> Has "Other" Option <br>'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="checkbox_view_state">'
        +'<div class="question_checkbox_list">'
        +'<div class="question_text">Question Text?</div>'
        +'<div class="option_checkbox_view" id="opt_cb_1">'
        +'<form>'
                        
        +'</form>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(cb);
    jq("#questions_panel ul li").show();
    cb.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    cb.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    cb.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    cb.find(".done_quest_cb, .edit_quest_cb, .delete_quest_cb").click(function(event){
        event.preventDefault();
        upper_buttons_cb(jq(this));
    });
    cb.find(".add_opt_cb, .remove_opt_cb").click(function(event){
        event.preventDefault();
        add_opt_cb(jq(this)); 
    });
}
function add_radio(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var rb=jq('<li id="'+id+'" class="radio question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_rb">edit</a>'
        +'<a href="#" class="done_quest_rb">done</a>'
        +'<a href="#" class="delete_quest_rb">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Radio Buttons: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="radio_edit_state">'
        +'<div class="radio_list">'
        +'Question Title <input type="text" name="dropdown_title" class="question_title"/>'
        +'<input type="hidden" name="sum_opt" id="sum_opt_rb" class="sum_opt_rb" value="1">'
        +'<div class="option_radio" id="opt_rb_1">'
        +'Option 1 <input type="text" name="label_option_1" class="label_opt" style="width: 25%; margin-left: 30px;" /> value: <input type="text" name="value_option_1" class="val_opt" style="width: 25%; " /> <a href="#" class="add_opt_rb">Add</a>'
        +'</div>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="has_other_option"> Has "Other" Option <br>'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="radio_view_state">'
        +'<div class="question_radio_list">'
        +'<div class="question_text">Question Text?</div>'
        +'<div class="option_radio_view" id="opt_cb_1">'
        +'<form>'
                        
        +'</form>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(rb);
    jq("#questions_panel ul li").show();
    rb.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    rb.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    rb.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    rb.find(".done_quest_rb, .edit_quest_rb, .delete_quest_rb").click(function(event){
        event.preventDefault();
        upper_buttons_rb(jq(this));
    });
    rb.find(".add_opt_rb, .remove_opt_rb").click(function(event){
        event.preventDefault();
        add_opt_rb(jq(this)); 
    });
}
function add_scale(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var sc = jq('<li id="'+id+'" class="scale question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_sc">edit</a>'
        +'<a href="#" class="done_quest_sc">done</a>'
        +'<a href="#" class="delete_quest_sc">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Scale: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="scale_edit_state">'
        +'<div class="scale_list">'
        +'Question Title <input type="text" name="scale_title" class="question_title"/>'
        +'<div class="option_scale" id="opt_sc_1">'
        +'Scale <select class="start_scale" name="start_scale_0" style="margin-left: 47px; min-width: 0em;"><option class="start_scale_opt" val="0">0</option><option class="start_scale_opt" value="1">1</option></select> to <select class="end_scale" name="end_scale_0" style="min-width: 0em;"><option class="end_scale_opt" value="2">2</option><option class="end_scale_opt" value="3">3</option><option class="end_scale_opt" value="4">4</option><option class="end_scale_opt" value="5">5</option></select> </br>'
        +'Start Label <input type="text" class="start_label" name="start_label_0" style="margin-left: 18px; width: 80px;"></br>'
        +'Middle Label <input type="text" class="middle_label" name="middle_label_0" style="margin-left: 7px; width: 80px;"></br>'
        +'End Label <input type="text" class="end_label" name="end_label_0" style="margin-left: 22px; width: 80px;">'
        +'</div>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="scale_view_state">'
        +'<div class="question_scale_list">'
        +'<div class="question_text">Question Text?</div>'
        +'<div class="option_scale_view" id="opt_sc_1">'
        +'<table name="scale_label_set" class="scale_label_set">'
        +'<tr>'
        +'<td class="scale_label_first" style="text-align: left;">awal</td>'
        +'<td class="scale_label_second" style="text-align: left; padding-left:0px;">tengah</td>'
        +'<td class="scale_label_third" style="text-align: left; padding-left:0px;">akhir</td>'
        +'</tr>'
        +'</table>'
        +'<table name="scale_view_set" class="scale_view_set" style="text-align: center;">'
    
        +'<tr class="num_label">'
        +'</tr>'
        +'<tr class="radio_scale">'
        +'</tr>'
        +'</table>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(sc);
    jq("#questions_panel ul li").show();
    sc.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    sc.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    sc.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    sc.find(".done_quest_sc, .edit_quest_sc, .delete_quest_sc").click(function(event){
        event.preventDefault();
        upper_buttons_sc(jq(this));
        setposition_scale(jq(this));
    });
    sc.find(".add_opt_sc, .remove_opt_sc").click(function(){
        add_opt_sc(jq(this)); 
    });
}
function add_grid(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var gr = jq('<li id="'+id+'" class="grid question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_gr">edit</a>'
        +'<a href="#" class="done_quest_gr">done</a>'
        +'<a href="#" class="delete_quest_gr">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Grid: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="grid_edit_state">'
        +'<div class="grid_list">'
        +'Question Title <input type="text" name="scale_title" class="question_title"/>'
        +'<div class="option_grid" id="opt_gr_1">'
        +'Scale <select class="start_grid_scale" name="start_grid_0" style="margin-left: 47px; min-width: 0em;"><option class="start_grid_opt" val="0">0</option><option class="start_grid_opt" value="1">1</option></select> to <select class="end_grid_scale" name="end_grid_0" style="min-width: 0em;"><option class="end_grid_opt" value="2">2</option><option class="end_grid_opt" value="3">3</option><option class="end_grid_opt" value="4">4</option><option class="end_grid_opt" value="5">5</option></select> </br>'
        +'Start Label <input type="text" class="start_label" name="start_label_0" style="margin-left: 18px; width: 80px;"></br>'
        +'Middle Label <input type="text" class="middle_label" name="middle_label_0" style="margin-left: 7px; width: 80px;"></br>'
        +'End Label <input type="text" class="end_label" name="end_label_0" style="margin-left: 22px; width: 80px;"></br>'
        +'<div class="qrid_question_label_1">'
        +'Question 1 <input type="text" class="label_question" name="label_question_1" style="margin-left: 17px;"> <a href="#" class="add_grid_question">Add</a>'
        +'<input type="hidden" name="sum_row_question" class="sum_row_question" id="sum_row_question_'+id+'" value="1">'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="grid_view_state">'
        +'<div class="question_grid_list">'
        +'<div class="question_text">Question Text?</div>'
        +'<div class="option_grid_view" id="opt_sc_1">'
        +'<table name="grid_label_set" class="grid_label_set">'
        +'<tr>'
        +'<td name="empty_text" style="width: 200px;"></td>'
        +'<td class="grid_label_first" style="text-align: left; max-width:125px;">awal</td>'
        +'<td class="grid_label_second" style="text-align: left; max-width:125px;">tengah</td>'
        +'<td class="grid_label_third" style="text-align: left; max-width:125px;">akhir</td>'
        +'</tr>'
        +'</table>'
        +'<table name="grid_view_set" class="grid_view_set" style="text-align: center;">'
                   
                   
        +'</table>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(gr);
    jq("#questions_panel ul li").show();
    gr.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    gr.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    gr.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    gr.find(".done_quest_gr, .edit_quest_gr, .delete_quest_gr").click(function(event){
        event.preventDefault();
        upper_buttons_gr(jq(this));
        setposition(jq(this));
    });
    gr.find(".add_grid_question, .remove_grid_question").click(function(event){
        event.preventDefault();
        add_grid_question(jq(this)); 
    });
}

function add_email(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var em = jq('<li id="'+id+'" class="email question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_em">edit</a>'
        +'<a href="#" class="done_quest_em">done</a>'
        +'<a href="#" class="delete_quest_em">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Email: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="email_edit_state">'
        +'<div class="email_line">'
        +'Question Title <input type="text" name="single_quest_title" class="question_title"/>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width:25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="email_view_state">'
        +'<div class="email_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'<div class="email_input">'
        +'<input type="text" class="email_input_field" name="email_input_field" >'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(em);
    jq("#questions_panel ul li").show();
    em.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    em.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    em.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    em.find(".done_quest_em, .edit_quest_em, .delete_quest_em").click(function(event){
        event.preventDefault();
        upper_buttons_em(jq(this));
    });
    em.find(".email_input_field").keypress(function(event){
        event.preventDefault();
        var em_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            //alert(em_text);
            var email_reg =/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
            if(em_text==''){
                alert("harap isi alamat email Anda");
            }else{
                if(email_reg.test(em_text)){
                    //alert("alamat email valid");
                }
                else{
                    alert("alamat email tidak valid!");
                }
            }
        }
    });
}
function add_number(){
    var id = ++fields_sum;
    fields_id.push(id);
    
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var no = jq('<li id="'+id+'" class="number question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_no">edit</a>'
        +'<a href="#" class="done_quest_no">done</a>'
        +'<a href="#" class="delete_quest_no">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Number: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="number_edit_state">'
        +'<div class="number_line">'
        +'Question Title <input type="text" name="number_question_line" class="question_title"/><br />'
        +'Info <input type="text" class="question_info"/>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width:25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="number_view_state">'
        +'<div class="number_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'<div class="number_input">'
        +'<input type="text" class="number_input_field" name="number_input_field" >'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(no);
    jq("#questions_panel ul li").show();
    no.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    no.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    no.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    no.find(".done_quest_no, .edit_quest_no, .delete_quest_no").click(function(event){
        event.preventDefault();
        upper_buttons_no(jq(this));
    });
    no.find(".number_input_field").keypress(function(event){
        event.preventDefault();
        var no_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            //alert(em_text);
            var number_reg =/^[0-9]+$/;
            if(no_text==''){
                alert("field kosong");
            }else{
                if(number_reg.test(no_text)){
                    //alert("masukan valid");
                }
                else{
                    alert("masukan tidak valid! hanya boleh angka!");
                }
            }
        }
    });
}
function add_address(){
    var id = ++fields_sum;
    fields_id.push(id);
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var ad = jq('<li id="'+id+'" class="address question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_ad">edit</a>'
        +'<a href="#" class="done_quest_ad">done</a>'
        +'<a href="#" class="delete_quest_ad">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Address: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="address_edit_state">'
        +'<div class="address_line">'
        +'Question Title <input type="text" name="address_question_line" class="question_title"/>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="address_view_state">'
        +'<div class="address_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'<div class="address_input">'
        +'Street Name <input type="text" class="address_st_input_field" name="address_st_input_field" > </br>'
        +'City <input type="text" class="address_city_input_field" name="address_city_input_field" style="width: 15%; margin-left: 50px;"> Province <select name="address_prov_input" class="address_prov_input" style="min-width: 0em;"><option name="address_prov_1" id="address_prov_1" value="jakarta">Jakarta</option><option name="address_prov_2" id="address_prov_2" value="jawa_barat">Jawa Barat</option><option name="address_prov_3" id="address_prov_3" value="jawa_tengah">Jawa Tengah</option><option name="address_prov_4" id="address_prov_4" value="jawa_timur">Jawa Timur</option></select> </br>'
        +'Zip Code <input type="text" class="address_zc_input_field" name="address_zc_input_field" style="width: 5em; margin-left: 23px;" >'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(ad);
    jq("#questions_panel ul li").show();
    ad.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    ad.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    ad.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    ad.find(".done_quest_ad, .edit_quest_ad, .delete_quest_ad").click(function(event){
        event.preventDefault();
        upper_buttons_ad(jq(this));
    });
    ad.find(".address_zc_input_field").keypress(function(event){
        event.preventDefault();
        var zc_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            //alert(em_text);
            var email_reg =/^\d{5}$/;
            if(zc_text==''){
                alert("field kosong");
            }else{
                if(email_reg.test(zc_text)){
                    //alert('masukan valid');
                    
                }
                else{
                    alert("masukan tidak valid!");
                }
            }
        }
    });
}
function add_phone(){
    var id = ++fields_sum;
    fields_id.push(id);
    
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var ph = jq('<li id="'+id+'" class="phone question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_ph">edit</a>'
        +'<a href="#" class="done_quest_ph">done</a>'
        +'<a href="#" class="delete_quest_ph">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Phone: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="phone_edit_state">'
        +'<div class="phone_line">'
        +'Question Title <input type="text" name="phone_question_line" class="question_title"/>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width:25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="phone_view_state">'
        +'<div class="phone_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'<div class="phone_input">'
        +'<input type="text" class="phone_input_field" name="phone_input_field" >'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(ph);
    jq("#questions_panel ul li").show();
    ph.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    ph.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    ph.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
    ph.find(".done_quest_ph, .edit_quest_ph, .delete_quest_ph").click(function(event){
        event.preventDefault();
        upper_buttons_ph(jq(this));
    });
    ph.find(".phone_input_field").keypress(function(event){
        event.preventDefault();
        var ph_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);

        if(keycode == '13'){
            //alert(em_text);
            var email_reg =/[0-9]{10,12}/;
            var number_check = /^\d+$/;
            if(ph_text==''){
                alert("field kosong");
            }else{
                if(email_reg.test(ph_text) && number_check.test(ph_text)){
                    if(ph_text.length>9 && ph_text.length<13){
                        //alert("masukan valid");
                    }
                    else{
                        alert("masukan tidak valid, nomor kurang atau berlebih");
                    }
                    
                }
                else{
                    alert("masukan tidak valid!");
                }
            }
        }
    });
}

function add_datepicker(field, option, start, end){
    var yr = new Date();
    var yr1 = yr.getFullYear() - start;
    var yr2 = end - yr.getFullYear();
    
    if(option=="all"){
        jq(field).datepicker({
            dateFormat: 'dd/mm/yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-"+yr1+":+"+yr2+"",
            showButtonPanel: true
            
        });
    }
    else if (option=="two"){
        jq(field).datepicker({ 
            dateFormat: 'mm/yy',
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            yearRange:"-"+yr1+":+"+yr2+"",
            onClose: function(dateText, inst) {  
                var month = jq("#ui-datepicker-div .ui-datepicker-month :selected").val(); 
                var year = jq("#ui-datepicker-div .ui-datepicker-year :selected").val(); 
                //                        jq(this).val(jq.datepicker.formatDate('yy-mm', new Date(year, month, 1)));
                jq(this).datepicker('setDate', new Date(year, month, 1));
                jq(this).datepicker("refresh");
            }
        });

        jq(field).focus(function () {
            jq(".ui-datepicker-calendar").hide();
            jq("#ui-datepicker-div").position({
                my: "left top",
                at: "left bottom",
                of: jq(this)
            });    
        });
        
    }
    else{
        jq(field).datepicker({ 
            dateFormat: 'yy',
            changeMonth: false,
            changeYear: true,
            showButtonPanel: true,
            yearRange:"-"+yr1+":+"+yr2+"",
            onClose: function(dateText, inst) {  
                var year = jq("#ui-datepicker-div .ui-datepicker-year :selected").val(); 
                jq(this).datepicker('setDate', new Date(year, 1));
                jq(this).datepicker("refresh");
            }
        });

        jq(field).focus(function () {
            jq(".ui-datepicker-calendar").hide();
            jq(".ui-datepicker-month").hide();
            jq("#ui-datepicker-div").position({
                my: "left top",
                at: "left bottom",
                of: jq(this)
            });    
        });
    }
    
}
function add_date(){
    var id = ++fields_sum;
    fields_id.push(id);
    
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var dt = jq('<li id="'+id+'" class="date question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_dt">edit</a>'
        +'<a href="#" class="done_quest_dt">done</a>'
        +'<a href="#" class="delete_quest_dt">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Date: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="date_edit_state">'
        +'<div class="date_line">'
        +'Question Title <input type="text" name="date_question_line" class="question_title"/><br>'
        +'Info <input type="text" class="question_info"/><br>'
        +'Year Range <input type="text" name="start_year" class="start_year" style="width: 35px; margin-left: 12px;" value="1980"> to <input type="text" name="end_year" class="end_year" style="width: 35px;" value="2020"><br>'
        +'Option <select name="date_option" class="date_option" style="min-width: 0em; margin-left: 42px;"><option value="all" class="date_option_1">Show All</option><option value="two" class="date_option_2">Show Only Month and Year</option><option value="one" class="date_option_3">Show Only Year</option></select>'
        +'</div>'
        +'<div class="field_rules">'
        +'<input type="checkbox" class="required_field"> Required <br>'
        +'<input type="checkbox" class="field_CL"> Enable Condtional Logic <br>'
        +'<div class="CL_panel_field">'
        +'<div class="CL_input_shows">'
        +'<select class="CL_shows" style="min-width: 0em;">'
        +'<option value="show" selected="true">Show</option>'
        +'<option value="hide">Hide</option>'
        +'</select>'
        +'if'
        +'<select class="CL_anys" style="min-width: 0em;">'
        +'<option value="any" selected="true">Any</option>'
        +'<option value="all">All</option>'
        +'</select>'
        +'of this/these following match:'
        +'</div>'
        +'<div class="CL_input_val">'
        +'<select id="CL_0" class="CL_field_question" style="min-width:0em; max-width:25em" onchange="change_CL_field(jq(this))">'
        +cl_questions
        +'</select> '
        +'<select id="CL_is_0" class="field_is_not" style="min-width:0em;">'
        +'<option value="is">Is</option>'
        +'<option value="not">Is not</option>'
        +'</select> '
        +'<select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">'
        +cl_options
        +'</select> '
        +'<a href="#" class="addCL_field">Add</a>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'<div class="date_view_state">'
        +'<div class="date_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'<div class="date_input">'
        +'<input type="text" class="date_input_field" name="date_input_field" style="max-width: 10em;" />'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(dt);
    jq("#questions_panel ul li").show();
    dt.find(".done_quest_dt, .edit_quest_dt, .delete_quest_dt").click(function(event){
        event.preventDefault();
        upper_buttons_dt(jq(this));
    });
    dt.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    dt.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    dt.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
}

function add_readonly(){
    var id = ++fields_sum;
    fields_id.push(id);
    
    var id_h = id;
    var cl_questions = '';
    var cl_options = '';
    var cl_opt = {};
    var iterator = "a";
    cl_opt[iterator] = [];
    <?php foreach($allfields as $af):
        $cl_options = json_decode($af->options, true);?>
        cl_opt[iterator] = [];
        var section_id = <?php echo $af->section_id?>;
        var id_html = <?php echo $af->id_html?>;
        var s_id = <?php echo $id_section?>;
        if(section_id!=s_id || id_html!=id_h){
        cl_questions = cl_questions+'<option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>'
            <?php for($p=0;$p<count($cl_options["lab"]);$p++){?>
            cl_opt[iterator].push('<option value="<?php echo $cl_options["val"][$p]?>"><?php echo $cl_options["lab"][$p]?></option>');
            <?php }  ?>
        iterator="b";
        }
        <?php 
        endforeach;?>
    for(x=0;x<cl_opt["a"].length;x++){
        cl_options=cl_options+cl_opt["a"][x];
    }
    var ro = jq('<li id="'+id+'" class="readonly question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_ro">edit</a>'
        +'<a href="#" class="done_quest_ro">done</a>'
        +'<a href="#" class="delete_quest_ro">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'User Field: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="readonly_edit_state">'
        +'<div class="readonly_line">'
        +'Label <input type="text" name="readonly_question_field" class="question_title"/><br />'
        +'Field <select name="readonly_question_field" class="user_field">'
        <?php foreach ($db_fields as $df) { ?>
            +'<option value="<?php echo $df; ?>"><?php echo $df; ?></option>'  
        <?php } ?>
        +'</select></div><br />'
        +'</div>'
        +'<div class="field_rules">'
        +'<input style="display: none;" type="checkbox" class="required_field" checked>'
        +'</div>'
        +'</div>'
        +'<div class="readonly_view_state">'
        +'<div class="readonly_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(ro);
    jq("#questions_panel ul li").show();
    ro.find(".done_quest_ro, .edit_quest_ro, .delete_quest_ro").click(function(event){
        event.preventDefault();
        upper_buttons_ro(jq(this));
    });
    ro.find(".field_CL").click(function(event){
        event.preventDefault();
        checkCL_field(jq(this));
    });
    ro.find(".addCL_field").click(function(event){
        event.preventDefault();
        addCL_field(jq(this)); 
    });
    ro.find(".CL_field_question").change(function(event){
        event.preventDefault();
       change_CL_field(jq(this)); 
    });
}

function add_hidden(){
    var id=++fields_sum;
    fields_id.push(id);
    var hd = jq('<li id="'+id+'" class="hidden question_fields">'
        +'<div class="field_header">'
        +'<div class="field_buttons_edit">'
        +'<a href="#" class="edit_quest_hd">edit</a>'
        +'<a href="#" class="done_quest_hd">done</a>'
        +'<a href="#" class="delete_quest_hd">delete</a>'
        +'</div>'
        +'<div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">'
        +'Hidden: '+id
        +'</div>'
        +'</div>'
        +'<div class="field_container">'
        +'<div class="hidden_edit_state">'
        +'<div class="hidden_line">'
        +'Label <input type="text" name="hidden_question_field" class="question_title"/>'
        +'</div>'
        +'</div>'
        +'<div class="hidden_view_state">'
        +'<div class="hidden_line">'
        +'<div class="question_text">'
        +'Question Text'
        +'</div>'
        +'<input type="hidden" class="hidden_label_text" name="hidden_label_text">'
        +'</div>'
        +'</div>'
        +'</div>'
        +'</li>');
    jq("#questions_panel ul").append(hd);
    jq("#questions_panel ul li").show();
    hd.find(".done_quest_hd, .edit_quest_hd, .delete_quest_hd").click(function(event){
        event.preventDefault();
        upper_buttons_hd(jq(this));
    });
}

function setposition(anu){
    if(anu.is(".done_quest_gr")){
        var start_scale = anu.parents("li:first").find(".start_grid_scale").find(":selected").val();
        var end_scale = anu.parents("li:first").find(".end_grid_scale").find(":selected").val();
        var n = sum_quest_gr;
        
        var label = anu.parents("li:first").find(".grid_label_third");
        var label2 = anu.parents("li:first").find(".grid_label_second");
        var radio1 = anu.parents("li:first").find("#grid_radio_1_"+start_scale+"");
        var radio = anu.parents("li:first").find("#grid_radio_1_"+end_scale+"");
        
        
        var pos1 = radio1.offset().left;
        var pos3 = radio.offset().left;
        var pos2 = pos1 + (pos3-pos1)/2;
        //alert(radio.offset().left);
        label.offset({left:radio.offset().left});
        label2.offset({left:pos2});
        //alert(label.position().left);
    }
}

function setposition_scale(anu){
    if(anu.is(".done_quest_sc")){
        var start_scale = anu.parents("li:first").find(".start_scale").find(":selected").val();
        var end_scale = anu.parents("li:first").find(".end_scale").find(":selected").val();
        
        var label = anu.parents("li:first").find(".scale_label_third");
        var label2 = anu.parents("li:first").find(".scale_label_second");
        var radio1 = anu.parents("li:first").find("#scale_radio_"+start_scale+"");
        var radio = anu.parents("li:first").find("#scale_radio_"+end_scale+"");
        
        
        var pos1 = radio1.offset().left;
        var pos3 = radio.offset().left;
        var pos2 = pos1 + (pos3-pos1)/2;
        //alert(radio.offset().left);
        label.offset({left:radio.offset().left});
        label2.offset({left:pos2});
        //alert(label.position().left);
    }
}

function save_sortable_list(){
    var data="";
    var sequence = {};
    sequence['urutan'] = [];
    sequence['type'] = [];
    sequence['jumlah'] = [];
    
    jq("#sortable li").each(function(){
        sequence['urutan'].push(jq(this).attr("id"));
        sequence['type'].push(jq(this).attr("class").split(" ")[0]);
    });
    sequence['jumlah'].push(sequence['urutan'].length);
    data = JSON.stringify(sequence);
    
    jq("#order_field").val(data);
}

function save_to_json(){
    var options_object = {};
    jq("#sortable li").each(function(){
        var id = "id"+jq(this).attr("id");
        options_object[id] = {};
        options_object[id]["title"] = [];
		options_object[id]["info"] = [];
        options_object[id]["val"] = [];
        options_object[id]["lab"] = [];
        options_object[id].str_sc = [];
        options_object[id].end_sc = [];
        options_object[id].str_lb = [];
        options_object[id].mid_lb = [];
        options_object[id].end_lb = [];
        options_object[id].row_qst = [];
        options_object[id].str_yr = [];
        options_object[id].end_yr = [];
        options_object[id].date_opt = [];
		options_object[id].user_field = [];
        options_object[id].required = [];
		options_object[id].has_other_option = [];
		
        jq(this).find(".question_title").each(function(){
            options_object[id].title.push(jq(this).val());
        });
		jq(this).find(".question_info").each(function(){
            options_object[id].info.push(jq(this).val());
        });
        jq(this).find(".val_opt").each(function(){
            options_object[id].val.push(jq(this).val());
        });
        jq(this).find(".label_opt").each(function(){
            options_object[id].lab.push(jq(this).val());
        });
        jq(this).find(".start_scale").each(function(){
            options_object[id].str_sc.push(jq(this).val()); 
        });
        jq(this).find(".end_scale").each(function(){
            options_object[id].end_sc.push(jq(this).val()); 
        });
        jq(this).find(".start_grid_scale").each(function(){
            options_object[id].str_sc.push(jq(this).val()); 
        });
        jq(this).find(".end_grid_scale").each(function(){
            options_object[id].end_sc.push(jq(this).val()); 
        });
        jq(this).find(".start_label").each(function(){
            options_object[id].str_lb.push(jq(this).val());
        });
        jq(this).find(".middle_label").each(function(){
            options_object[id].mid_lb.push(jq(this).val());
        });
        jq(this).find(".end_label").each(function(){
            options_object[id].end_lb.push(jq(this).val());
        });
        jq(this).find(".label_question").each(function(){
            options_object[id].row_qst.push(jq(this).val());
        })
        jq(this).find(".start_year").each(function(){
            options_object[id].str_yr.push(jq(this).val()); 
        });
        jq(this).find(".end_year").each(function(){
            options_object[id].end_yr.push(jq(this).val()); 
        });
        jq(this).find(".date_option").find(":selected").each(function(){
            options_object[id].date_opt.push(jq(this).val()); 
        });
		jq(this).find(".user_field").each(function(){
            options_object[id].user_field.push(jq(this).val()); 
        });
        jq(this).find(".required_field").each(function(){
            if(jq(this).is(":checked")){
                options_object[id].required.push("true");
            }else{
                options_object[id].required.push("false");
            }
        });
		jq(this).find(".has_other_option").each(function(){
            if(jq(this).is(":checked")){
                options_object[id].has_other_option.push("true");
            }else{
                options_object[id].has_other_option.push("false");
            }
        });
    });
    var data = JSON.stringify(options_object);
    jq("#options").val(data);
    
}

function save_section_attr(){
    var section_attr = {};
    section_attr["title"]=[];
    section_attr["description"]=[];
    if(jq("#show_section_title").is(":checked")){
        section_attr["title"].push("true");
    }
    else{
        section_attr["title"].push("false");
    }
    if(jq("#show_section_description").is(":checked")){
        section_attr["description"].push("true");
    }
    else{
        section_attr["description"].push("false");
    }
    var data = JSON.stringify(section_attr);
    jq("#section_attr").val(data);
}

function save_CL_section(){
    var CL_section = {};
    CL_section["options"] = [];
    CL_section["isnot"] = [];
    CL_section["value"] = [];
    CL_section["show"] = [];
    CL_section["any"] = [];
    
    var data = "";
    if(jq("#CL_page").is(":checked")){
        jq(".show_option").each(function(){
           CL_section["show"].push(jq(this).find(":selected").val()); 
        });
        jq(".any_all").each(function(){
           CL_section["any"].push(jq(this).find(":selected").val()); 
        });
        jq(".section_is_not").each(function(){
           CL_section["isnot"].push(jq(this).find(":selected").val()); 
        });
        jq(".section_conditional").each(function(){
            CL_section["options"].push(jq(this).find(":selected").val());
        });
        jq(".opt_vals").each(function(){
           CL_section["value"].push(jq(this).find(":selected").val()); 
        });
        data = JSON.stringify(CL_section);
        jq("#hidden_cl_section").val(data);
    }
    //alert(data);
}

function save_CL_field(){
    var CL_field = {};
    jq("#sortable li").each(function(){
        var id_h = "id"+jq(this).attr("id");
        var check = jq(this).find(".field_CL");
        CL_field[id_h] = {};
        if(check.is(":checked")){
            CL_field[id_h]["options"]=[];
            CL_field[id_h]["values"]=[];
            CL_field[id_h]["isnot"] = [];
            CL_field[id_h]["show"] = [];
            CL_field[id_h]["any"] = [];

            jq(this).find(".field_is_not").each(function(){
               CL_field[id_h]["isnot"].push(jq(this).find(":selected").val());
            });
            jq(this).find(".CL_shows").each(function(){
                CL_field[id_h]["show"].push(jq(this).find(":selected").val());
            });
            jq(this).find(".CL_anys").each(function(){
               CL_field[id_h]["any"].push(jq(this).find(":selected").val()); 
            });
            jq(this).find(".CL_field_question").each(function(){
                CL_field[id_h]["options"].push(jq(this).find(":selected").val());
            });
            jq(this).find(".CL_field_options").each(function(){
                CL_field[id_h]["values"].push(jq(this).find(":selected").val());
            });
        }
        //alert(CL_field);
    })
    var data = JSON.stringify(CL_field);
    jq("#hidden_cl_field").val(data);
    //alert(data);
    
    
}

function set_fields_sum(){
    fields_sum = jq("#last_id").val();
    jq("#sortable li").each(function(){
        cur_id = jq(this).attr("id");
        if((+cur_id) > (+fields_sum)){
            fields_sum = cur_id;
        }
    });
}

jq(document).ready(function(){
    set_fields_sum();
    /*jq(".option_radio").find('remove_opt_rb').click(function(){
        checkCL_field(jq(this));
    });*/
    jq(".field_CL").click(function(){
        checkCL_field(jq(this));
    });
    jq(".field_CL").each(function(){
       checkCL_field(jq(this)); 
    });
    jq(".date_input_field").hover(function(){
        var start = jq(this).parents("li:first").find(".hidden_start_year").val();
        var end = jq(this).parents("li:first").find(".hidden_end_year").val();
        var option = jq(this).parents("li:first").find(".hidden_date_option").val();
        
        add_datepicker(jq(this), option, start, end );
    });
    jq("#simpan").click(function(){
        save_section_attr();
        save_to_json();
        save_sortable_list();
        save_CL_section();
        save_CL_field();
    });
    jq(".CLpanel").hide();
    jq(".email_input_field").keypress(function(){
        var em_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            var email_reg =/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
            if(em_text==''){
                alert("harap isi alamat email Anda");
            }else{
                if(email_reg.test(em_text)){
                    alert("alamat email valid");
                }
                else{
                    alert("alamat email tidak valid!");
                }
            }
        }
    });
    jq(".number_input_field").keypress(function(){
        var no_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            var email_reg =/[0-9]+/;
            if(no_text==''){
                alert("field kosong");
            }else{
                if(email_reg.test(no_text)){
                    //alert("masukan valid");
                }
                else{
                    alert("masukan tidak valid! hanya boleh angka!");
                }
            }
        }
    });
    jq(".phone_input_field").keypress(function(){
        var no_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            //alert(em_text);
            var email_reg =/[0-9]{10,12}/;
            var number_check = /^\d+$/;
            if(no_text==''){
                alert("field kosong");
            }else{
                if(email_reg.test(no_text) && number_check.test(no_text)){
                    if(no_text.length>9 && no_text.length<13){
                        //alert("masukan valid");
                    }
                    else{
                        alert("masukan tidak valid, nomor kurang atau berlebih");
                    }
                }
                else{
                    alert("masukan tidak valid!");
                }
            }
        }
    });
    jq(".address_zc_input_field").keypress(function(){
        var zc_text = jq(this).val();
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
            //alert(em_text);
            var email_reg =/^\d{5}$/;
            if(zc_text==''){
                alert("field kosong");
            }else{
                if(email_reg.test(zc_text)){
                    //alert('masukan valid');
                    
                }
                else{
                    alert("masukan tidak valid!");
                }
            }
        }
    });
    jq('.add_opt_dd').click(function(){
        add_opt_dd(jq(this));
    });
    jq(".add_opt_cb, .remove_opt_dd").click(function(event){
        if(jq(this).is('.add_opt_cb')){
            add_opt_cb(jq(this)); 
        }else{
            event.preventDefault();
            var opt_sum_cb = jq(this).parents("li:first").find("#sum_opt_cb").val();
            --opt_sum_cb;
            jq(this).parents("li:first").find("#sum_opt_cb").val(opt_sum_cb);
            jq(this).parent().remove();
        }
    });
    jq('.add_opt_rb, .remove_opt_rb').click(function(){
        if(jq(this).is('.add_opt_rb')){
            add_opt_rb(jq(this));
        }
        else{
            event.preventDefault();
            var opt_sum_rb = jq(this).parents("li:first").find("#sum_opt_rb").val();
            --opt_sum_rb;
            jq(this).parents("li:first").find("#sum_opt_rb").val(opt_sum_rb);
            jq(this).parent().remove();
        }
    });
    jq(".add_grid_question, .remove_grid_question").click(function(event){
        event.preventDefault();
        add_grid_question(jq(this));
    });
    jq('.done_quest_dd, .edit_quest_dd, .delete_quest_dd').click(function(event){
        event.preventDefault();
        upper_buttons_dd(jq(this)); 
    });
    jq('.done_quest_cb, .edit_quest_cb, .delete_quest_cb').click(function(event){
        event.preventDefault();
        upper_buttons_cb(jq(this)); 
    });
    jq('.done_quest_rb, .edit_quest_rb, .delete_quest_rb').click(function(event){
        event.preventDefault();
        upper_buttons_rb(jq(this)); 
    });
    jq('.done_quest_sc, .edit_quest_sc, .delete_quest_sc').click(function(event){
        event.preventDefault();
        upper_buttons_sc(jq(this)); 
    });
    jq('.done_quest_gr, .edit_quest_gr, .delete_quest_gr').click(function(event){
        event.preventDefault();
        upper_buttons_gr(jq(this)); 
    });
    jq('.done_quest_em, .edit_quest_em, .delete_quest_em').click(function(event){
        event.preventDefault();
        upper_buttons_em(jq(this)); 
    });
    jq('.done_quest_dt, .edit_quest_dt, .delete_quest_dt').click(function(event){
        event.preventDefault();
        upper_buttons_dt(jq(this)); 
    });
    jq('.done_quest_hd, .edit_quest_hd, .delete_quest_hd').click(function(event){
        event.preventDefault();
        upper_buttons_hd(jq(this)); 
    });
    jq('.done_quest_no, .edit_quest_no, .delete_quest_no').click(function(event){
        event.preventDefault();
        upper_buttons_no(jq(this)); 
    });
    jq('.done_quest_ph, .edit_quest_ph, .delete_quest_ph').click(function(event){
        event.preventDefault();
        upper_buttons_ph(jq(this)); 
    });
    jq('.done_quest_ad, .edit_quest_ad, .delete_quest_ad').click(function(event){
        event.preventDefault();
        upper_buttons_ad(jq(this)); 
    });
    jq('.done_quest_ro, .edit_quest_ro, .delete_quest_ro').click(function(event){
        event.preventDefault();
        upper_buttons_ro(jq(this)); 
    });
    jq(".delete_quest").click(function(event){
        event.preventDefault();
        deletequestion(jq(this)); 
    });
    jq("#simpan").click(function(){
        window.location="<?//php echo site_url(SITE_AREA . '/admin/kuesioner/kuesioner_section/edit') ?>";
    });
    jq(".up,.down").click(function(){
        addpage(jq(this));
    });
    jq(".delete").click(function(){
        deletepage(jq(this)); 
    });
    jq(".addCL").click(function(event){
        event.preventDefault();
        addCL();
    });
    jq(".removeCL").click(function(event){
        event.preventDefault();
        jq(this).parent().remove();
    });
    jq(".addCL_field").click(function(){
        addCL_field(jq(this)); 
    });
    jq(".removeCL_field").click(function(event){
        event.preventDefault();
        jq(this).parent().remove();
    });
    jq("#CL_page").each(function(){
        if(jq(this).is(':checked')){
            //alert("clpanel checked");
          jq(".CLpanel").show();
        }else{
            jq(".CLpanel").hide();
        }
    });
    jq("#CL_page").click(function(){
        if(jq(this).is(':checked')){
            //alert("clpanel checked");
          jq(".CLpanel").show();
        }else{
            jq(".CLpanel").hide();
        }
    });
    jq(".done_quest, .edit_quest, .delete_quest").click(function(event){
        event.preventDefault();
        done_edit_delete_quest(jq(this));
    });
    //            jq(".done_quest_dd, edit_quest_dd, .delete_quest_dd").click(function(){
    //                upper_buttons_dd(jq(this)); 
    //            });
    jq(".tambah").click(function(){
        var trbaru = jq('<tr><td>04</td><td>Data Tambahan</td><td>none</td><td>none</td><td>6</td><td><a href="#" class="up">Up</a> <a href="#" class="down">Down</a> <a href="#" class="edit">Edit</a> <a href="#" class="delete">Delete</a></td></tr>');
        jq("#daftar_section").append(trbaru);
        trbaru.find(".up,.down").click(function(){
            addpage(jq(this));
        });
        trbaru.find(".delete").click(function(){
            deletepage(jq(this)); 
        });
    });
});

</script>

<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner_section:'.$mode); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

    <?php 
        $value = NULL;
        if($this->input->post('kuesioner_id') != NULL){
            $value = $this->input->post('id');
        }elseif($mode == 'edit'){
            $value = $fields['id'];
        }
    ?>
    <input name="id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" hidden/>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="title"><?php echo lang('kuesioner:title'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('title') != NULL){
					$value = $this->input->post('title');
				}elseif($mode == 'edit'){
					$value = $fields['title'];
				}
			?>
			<input name="title" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
		
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:deskripsi'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('deskripsi') != NULL){
					$value = $this->input->post('deskripsi');
				}elseif($mode == 'edit'){
					$value = $fields['deskripsi'];
				}
			?>
			<!--<input name="deskripsi" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />-->
            <textarea name="deskripsi" class="col-xs-15 col-sm-5"><?php echo $value; ?></textarea>
			
		</div>
	</div>

	<?php 
		$value = NULL;
		if($this->input->post('kuesioner_id') != NULL){
			$value = $this->input->post('kuesioner_id');
		}elseif($mode == 'edit'){
			$value = $fields['kuesioner_id'];
		}
	?>
	<input name="kuesioner_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" hidden="true"/>


	<?php 
		$value = NULL;
		if($this->input->post('page_id') != NULL){
			$value = $this->input->post('page_id');
		}elseif($mode == 'edit'){
			$value = $fields['page_id'];
		}
	?>
	<input name="page_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" hidden="true"/>
	
    <?php $section_attrib = json_decode($fields['section_options'], true);?>
	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="section_options"><?php echo lang('kuesioner:show_title'); ?></label>

		<div class="col-sm-10">
			<!--<?php 
				$value = NULL;
				if($this->input->post('section_options') != NULL){
					$value = $this->input->post('section_options');
				}elseif($mode == 'edit'){
					$value = $fields['section_options'];
				}
			?>
			<input name="section_options" type="text" value='<?php echo $value; ?>' class="col-xs-10 col-sm-5" id="" />-->
            <input type="checkbox" name="show_section_title" id="show_section_title" <?php if($section_attrib["title"][0]=="true"){echo "checked";}?>>
		</div>
	</div>
    
    <div class="form-group">
        <label class="col-sm-2 control-label no-padding-right"><?php echo lang('kuesioner:show_description'); ?></label>

        <div class="col-sm-10">
            <!--<input name="section_options" type="hidden" value='<?php echo $value; ?>' class="col-xs-10 col-sm-5" id="" />-->
            <input type="checkbox" name="show_section_description" id="show_section_description" <?php if($section_attrib["description"][0]=="true"){echo "checked";}?>>
        </div>
    </div>
    <!--
	   <div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="fields"><?php echo lang('kuesioner:fields'); ?></label>

		<div class="col-sm-10">-->
			<?php 
				$value = NULL;
				if($this->input->post('fields') != NULL){
					$value = $this->input->post('fields');
				}elseif($mode == 'edit'){
					$value = $fields['fields'];
				}
			?>
			<input name="fields" type="hidden" value='<?php echo $value; ?>' class="col-xs-10 col-sm-5" id="" />

		<!--</div>
	</div>-->

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="conditional_logic"><?php echo lang('kuesioner:conditional_logic'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('conditional_logic') != NULL){
					$value = $this->input->post('conditional_logic');
				}elseif($mode == 'edit'){
					$value = $fields['conditional_logic'];
				}
			?>
			<!--<input name="conditional_logic" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />-->
            <input type="checkbox" name="kuesioner_CL_page" id="CL_page" <?php if($fields['conditional_logic']!=null){echo "checked";}?>>

		</div>
	</div>
    <div class="clearfix">
        <div class="CLpanel">
            
            <?php if(is_array($allfields_cl_section) AND count($allfields_cl_section) > 0): ?>
            
            <div class="input">
                <?php foreach($records as $record):?>
                <?php $cl_s_content = json_decode($record->conditional_logic,true);?>
                <select class="show_option" style="min-width:0em" name="show_options">
                    <option value="show" <?php if($cl_s_content!=null && $cl_s_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                    <option value="hide" <?php if($cl_s_content!=null && $cl_s_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                </select>
                if 
                <select class="any_all" style="min-width:0em" name="any_all">
                    <option value="any" <?php if($cl_s_content!=null && $cl_s_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                    <option value="all" <?php if($cl_s_content!=null && $cl_s_content["any"][0]=="all"){echo "selected";}?>>All</option>
                </select>
                <?php endforeach;?>
            </div>
            <?php foreach($records as $record): 
                if($record->conditional_logic!=null){
                $cl_s_content = json_decode($record->conditional_logic, true);
                for($n=0;$n<count($cl_s_content["options"]);$n++) {
                list($p_id,$s_id,$id_h)=explode("_",$cl_s_content["options"][$n]);
            ?>
            <div class="input">
                <select name="CL1" class="CL1 section_conditional" style="min-width:0em; max-width: 25em" onchange="change_options_CL(jq(this))">
                <?php foreach ($allfields_cl_section as $af): if($af->section_id!=$id_section){?>
                    <?php $cl = json_decode($af->options,true); ?>
                    <option value="<?php echo $af->page_id?>_<?php echo $af->section_id?>_<?php echo $af->id_html?>" <?php if ($af->page_id==$p_id && $af->section_id==$s_id && $af->id_html==$id_h){echo "selected";}?>>
                    Page "<?php echo $af->page_title?>" &raquo; Section "<?php echo $af->section_title?>" &raquo; Question "<?php echo $cl["title"][0];?>"
                    </option>      
                <?php } endforeach;?>
                </select>
                
                <?php
                //$CL_is_not = array('is' => 'Is', 'not' => 'Is Not');
                //echo form_dropdown('is_not', $CL_is_not, 'is', 'class="section_is_not" style="min-width:0em"');
                ?>
                <select name="is_not" class="section_is_not" style="min-width:0em">
                    <option value="is" <?php if($cl_s_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                    <option value="not" <?php if($cl_s_content["isnot"][$n]=="not"){echo "selected";}?>>Is Not</option>
                </select>
                <select name="opt_vals" class="opt_vals" style="min-width: 0em; max-width: 15em">
                
                <?php  foreach ($allfields_cl_section as $af):
                        if($af->section_id!=$id_section && $af->page_id==$p_id && $af->section_id==$s_id && $af->id_html==$id_h){
                        $cl_options = json_decode($af->options, true);
                        for($k=0;$k<count($cl_options["lab"]);$k++){ ?>
                        <option value="<?php echo $cl_options["val"][$k]?>" <?php if($cl_s_content["value"][$n]==$cl_options["val"][$k]){echo "selected";}?>><?php echo $cl_options["lab"][$k]?></option>
                <?php } break;} endforeach;?>
                
                </select>
                
                <a href="#" class="addCL">Add</a> <a href=# class="removeCL">Remove</a>
                </div>
            <?php }} else{ ?>
                <div class="input">
                <select name="CL1" class="CL1 section_conditional" style="min-width:0em; max-width: 25em" onchange="change_options_CL(jq(this))">
                <?php foreach ($allfields as $af): if($af->section_id!=$id_section){?>
                    <?php $cl = json_decode($af->options,true); ?>
                    <option value="<?php echo $af->page_id?>_<?php echo $af->section_id?>_<?php echo $af->id_html?>" >
                    Page "<?php echo $af->page_title?>" &raquo; Section "<?php echo $af->section_title?>" &raquo; Question "<?php echo $af->id_html." : ".$cl["title"][0];?>"
                    </option>      
                <?php } endforeach;?>
                </select>
                
                <?php
                $CL_is_not = array('is' => 'Is', 'not' => 'Is Not');
                echo form_dropdown('is_not', $CL_is_not, 'is', 'class="section_is_not" style="min-width:0em"');
                ?>
                <select name="opt_vals" class="opt_vals" style="min-width: 0em; max-width: 15em">
                
                <?php  foreach ($allfields as $af):
                        if($af->section_id!=$id_section){
                        $cl_options = json_decode($af->options, true);
                        for($k=0;$k<count($cl_options["lab"]);$k++){ ?>
                        <option value="<?php echo $cl_options["val"][$k]?>"><?php echo $cl_options["lab"][$k]?></option>
                <?php } break;} endforeach;?>
                
                </select>
                
                <a href="#" class="addCL">Add</a>
           
            </div>
            <?php } endforeach;?>
            
            <?php else: ?>
                <div class="input">Tidak tersedia <i>field</i> yang dapat digunakan sebagai aturan <i>conditional logic</i>.</div>
            <?php endif; ?>
            
        </div>
    </div>

</div>
<input type="hidden" name="last_id" id="last_id" value="<?php

    $last_id = json_decode($fields['fields'], true);
    //print_r(json_decode($fields['fields'], true));
    //echo $last_id['urutan'];
    $index = $last_id["jumlah"][0] - 1;
    $id = $last_id["urutan"][$index];
    //echo $last_id["jumlah"][0];
    //var_dump($last_id["urutan"]);
    echo $id;
        ?>">

<input type="hidden" name="cl_options" id="cl_options" value="<?php
    foreach($allfields as $af => $val):
        echo $val->options;
    endforeach;
?>">
<?php echo "<br>"; ?>
<input type="hidden" name="hidden_cl_section" id="hidden_cl_section">
<input type="hidden" name="hidden_cl_field" id="hidden_cl_field" >
<input type="hidden" name="options" id="options">
<input type="hidden" name="section_attr" id="section_attr">
<input type="hidden" name="order_field" id="order_field" >
<input type="hidden" name="order_field_old" id="order_field_old" value='<?php echo $fields['fields']; ?>' >

<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<button type="submit" class="btn btn-primary" id="simpan"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>



<?php echo form_close();?>
<form action="" method="get" id="questions_panel">
    <ul id="sortable">
        <?php for ($k = 0; $k < count($questions_fields); $k++) { ?>
            <?php foreach ($questions_fields[$k] as $field): ?>
                <?php
                    if ($field->type == "single") {
                ?>
                    <li id="<?php echo $field->id_html ?>" class="single question_fields">
                        <div class="field_header">
                            <div class="field_buttons_edit">
                                <a href="#" class="edit_quest">edit</a>
                                <a href="#" class="done_quest">done</a>
                                <a href="#" class="delete_quest">delete</a>
                            </div>
                            <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                Single Line Text: <?php echo $field->id_html; ?>
                            </div>
                        </div>
                        <div class="field_container">
                            <div class="single_edit_state">
                                <div class="single_line">
                                    <?php
                                        $field_options = json_decode($field->options, true);
                                        $title = $field_options["title"][0];
                                        $info = isset($field_options["info"][0]) ? $field_options["info"][0] : '';
                                    ?>
                                    Question Title <input type="text" name="single_quest_title" class="question_title" value="<?php echo $title; ?>"/><br />
                                    Info <input type="text" class="question_info" value="<?php echo $info; ?>" />
                                </div>
                                <div class="field_rules">
                                    <input type="checkbox" class="required_field" <?php if($field_options["required"][0]=="true"){echo "checked";}?> > Required <?php echo $field_options["required"][0]; ?><br>
                                    <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                    <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                    ?>
                                    <div class="CL_panel_field">
                                        <div class="CL_input_shows">
                                            <select class="CL_shows" style="min-width: 0em;">
                                                <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                            </select>
                                            if
                                            <select class="CL_anys" style="min-width: 0em;">
                                                <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                            </select>
                                            of this/these following match:
                                        </div>
                                        <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                        ?>
                                        <div class="CL_input_val">
                                            <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                <?php foreach($allfields as $af):
                                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                        $cl_options = json_decode($af->options, true);
                                                ?>
                                                <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>>
                                                    <?php echo 'Page "'.$af->page_title.'" Section "'.$af->section_title.'" Question "'.$cl_options['title'][0].'"' ?>
                                                </option>
                                                <?php } endforeach;?>
                                            </select>
                                            <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                            </select>
                                            <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                <?php foreach($allfields as $af):
                                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                        if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                        $cl_options = json_decode($af->options,true);
                                                        for($i=0;$i<count($cl_options["lab"]);$i++){
                                                ?>
                                                <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                <?php } break; }} endforeach;?>
                                            </select>
                                            <a href="#" class="addCL_field">Add</a>
                                            <a href="#" class="removeCL_field">Remove</a>
                                        </div>
                                        <?php } ?>
                                    </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>">
                                                        <?php echo 'Page "'.$af->page_title.'" Section "'.$af->section_title .'" Question "'.$cl_options["title"][0].'"' ?>
                                                    </option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="single_view_state">
                                    <div class="single_line_text">
                                        <?php
                                        $title = json_decode($field->options, true);
                                        echo $title["title"][0];
                                        ?>
                                    </div>
                                    <div class="single_line_answer">    
                                        <input type="text" name="single_answer" />                      
                                    </div>
                                </div>
                            </div>
                        </li>

                    <?php } else if ($field->type == "dropdown") {
                        ?>
                        <li id="<?php echo $field->id_html ?>" class="dropdown question_fields">
                            <div class="field_header">
                                <div class="field_buttons_edit">
                                    <a href="#" class="edit_quest_dd">edit</a>
                                    <a href="#" class="done_quest_dd">done</a>
                                    <a href="#" class="delete_quest_dd">delete</a>
                                </div>
                                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                    Dropdown: <?php echo $field->id_html ?>
                                </div>
                            </div>
                            <div class="field_container">
                                <div class="dropdown_edit_state">
                                    <div class="dropdown_list">
                                        <?php
                                            $field_opt = json_decode($field->options, true);
                                        ?>
                                        Question Title <input type="text" name="dropdown_title" class="question_title" value="<?php
                                            echo $field_opt["title"][0];
                                        ?>"/>
                                        <input type="hidden" name="sum_opt" id="sum_opt_dd" class="sum_opt" value="<?php echo count($field_opt["lab"]) ?>">
                                        <div class="option_dropdown" id="opt_dd_1">
                                            Option 1 <input type="text" name="label_option_1" class="label_opt" style="width: 25%; margin-left: 30px;" value="<?php echo $field_opt["lab"][0] ?>" /> value: <input type="text" name="value_opt_1" class="val_opt" style="width: 25%; " value="<?php echo $field_opt["val"][0] ?>" /> <a href="#" class="add_opt_dd">Add</a>
                                        </div>
                                        <?php for ($n = 1; $n < count($field_opt["lab"]); $n++) { ?>
                                            <div class="option_dropdown" id="opt_dd_<?php echo $n + 1 ?>">
                                                Option <?php echo $n + 1 ?> <input type="text" name="label_option_<?php echo $n + 1 ?>" class="label_opt" style="width: 25%; margin-left: 30px;" value="<?php echo $field_opt["lab"][$n] ?>" /> value: <input type="text" name="value_opt_<?php echo $n + 1 ?>" class="val_opt" style="width: 25%; " value="<?php echo $field_opt["val"][$n] ?>" /> <a href="#" class="add_opt_dd">Add</a> <a href=# class="remove_opt_dd">Remove</a>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div class="field_rules">
                                        <input type="checkbox" class="has_other_option" <?php if(isset(json_decode($field->options)->has_other_option[0]) AND json_decode($field->options)->has_other_option[0]=="true"){echo "checked";}?> > Has "Other" option <br />
                                        <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                                        <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="dropdown_view_state">
                                    <div class="question_dropdown_list">
                                        <div class="question_text"><?php echo $field_opt["title"][0] ?></div>
                                        <div class="option_dropdown_view" id="opt_dd_1">
                                            <select class="option_list_view" name="option_list_view">
                                                <?php for ($m = 0; $m < count($field_opt["lab"]); $m++) { ?>
                                                    <option name="view_option_<?php echo $m + 1 ?>" id="view_option_<?php echo $m + 1 ?>" value="<?php echo $field_opt["val"][$m] ?>"><?php echo $field_opt["lab"][$m] ?></option>      
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                    <?php } else if ($field->type == "checkbox") {
                        ?>
                        <li id="<?php echo $field->id_html ?>" class="checkbox question_fields">
                            <div class="field_header">
                                <div class="field_buttons_edit">
                                    <a href="#" class="edit_quest_cb">edit</a>
                                    <a href="#" class="done_quest_cb">done</a>
                                    <a href="#" class="delete_quest_cb">delete</a>
                                </div>
                                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                    Checkbox: <?php echo $field->id_html ?>
                                </div>
                            </div>
                            <div class="field_container">
                                <div class="checkbox_edit_state">
                                    <div class="checkbox_list">
                                        <?php
                                            $field_opt = json_decode($field->options, true);
                                        ?>
                                        Question Title <input type="text" name="dropdown_title" class="question_title" value="<?php
                                        echo $field_opt["title"][0];
                                                    ?>" />
                                        <input type="hidden" name="sum_opt" id="sum_opt_cb" class="sum_opt_cb" value="<?php echo count($field_opt["lab"]) ?>">
                                        <div class="option_checkbox" id="opt_cb_1">
                                            Option 1 <input type="text" name="label_option_1" class="label_opt" style="width: 25%; margin-left: 30px;" value="<?php echo $field_opt["lab"][0] ?>" /> value: <input type="text" name="value_option_1" class="val_opt" style="width: 25%; " value="<?php echo $field_opt["val"][0] ?>"  /> <a href="#" class="add_opt_cb">Add</a>
                                        </div>
                                        <?php for ($n = 1; $n < count($field_opt["lab"]); $n++) { ?>
                                            <div class="option_checkbox" id="opt_cb_<?php echo $n + 1 ?>">
                                                Option <?php echo $n + 1 ?> <input type="text" name="label_option_<?php echo $n + 1 ?>" class="label_opt" style="width: 25%; margin-left: 30px;" value="<?php echo $field_opt["lab"][$n] ?>" /> value: <input type="text" name="value_option_<?php echo $n + 1 ?>" class="val_opt" style="width: 25%; " value="<?php echo $field_opt["val"][$n] ?>"  /> <a href="#" class="add_opt_cb">Add</a> <a href=# class="remove_opt_dd">Remove</a>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div class="field_rules">
                                        <input type="checkbox" class="has_other_option" <?php if(isset(json_decode($field->options)->has_other_option[0]) AND json_decode($field->options)->has_other_option[0]=="true"){echo "checked";}?> > Has "Other" option <br />
                                        <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                                        <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="checkbox_view_state">
                                    <div class="question_checkbox_list">
                                        <div class="question_text"><?php echo $field_opt["title"][0] ?></div>
                                        <div class="option_checkbox_view" id="opt_cb_1">
                                            <?php for ($m = 0; $m < count($field_opt["lab"]); $m++) { ?>
                                                <input type="checkbox" name="view_option_<?php echo $m + 1 ?>" id="view_option_<?php echo $m + 1 ?>" value="<?php echo $field_opt["val"][$m] ?>"> <label for="view_option_<?php echo $m + 1 ?>" style="display: inline;"><?php echo $field_opt["lab"][$m] ?></label> <br>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php } else if ($field->type == "radio") { ?>
                        <li id="<?php echo $field->id_html ?>" class="radio question_fields">
                            <div class="field_header">
                                <div class="field_buttons_edit">
                                    <a href="#" class="edit_quest_rb">edit</a>
                                    <a href="#" class="done_quest_rb">done</a>
                                    <a href="#" class="delete_quest_rb">delete</a>
                                </div>
                                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                    Radio Buttons: <?php echo $field->id_html ?>
                                </div>
                            </div>
                            <div class="field_container">
                                <div class="radio_edit_state">
                                    <div class="radio_list">
                                        <?php $field_opt = json_decode($field->options, true); ?>
                                        Question Title <input type="text" name="dropdown_title" class="question_title" value="<?php
                                        echo $field_opt["title"][0]; ?>" />
                                        <input type="hidden" name="sum_opt" id="sum_opt_rb" class="sum_opt_rb" value="<?php echo count($field_opt["lab"]) ?>">
                                        <div class="option_radio" id="opt_rb_1">
                                            Option 1 <input type="text" name="label_option_1" class="label_opt" style="width: 25%; margin-left: 30px;" value="<?php echo $field_opt["lab"][0] ?>" /> value: <input type="text" name="value_option_1" class="val_opt" style="width: 25%; " value="<?php echo $field_opt["val"][0] ?>" /> <a href="#" class="add_opt_rb">Add</a>
                                            <?php for ($n = 1; $n < count($field_opt["lab"]); $n++) { ?>
                                                <div class="option_radio" id="opt_rb_<?php echo $n + 1 ?>">
                                                    Option <?php echo $n + 1 ?> <input type="text" name="label_option_<?php echo $n + 1 ?>" class="label_opt" style="width: 25%; margin-left: 30px;" value="<?php echo $field_opt["lab"][$n] ?>" /> value: <input type="text" name="value_option_<?php echo $n + 1 ?>" class="val_opt" style="width: 25%; " value="<?php echo $field_opt["val"][$n] ?>" /> <a href="#" class="add_opt_rb">Add</a> <a href=# class="remove_opt_rb">Remove</a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="field_rules">
                                        <input type="checkbox" class="has_other_option" <?php if(isset(json_decode($field->options)->has_other_option[0]) AND json_decode($field->options)->has_other_option[0]=="true"){echo "checked";}?> > Has "Other" option <br />
                                        <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                                        <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="radio_view_state">
                                    <div class="question_radio_list">
                                        <div class="question_text"><?php echo $field_opt["title"][0] ?></div>
                                        <div class="option_radio_view" id="opt_rb_1">
                                            <?php for ($m = 0; $m < count($field_opt["lab"]); $m++) { ?>
                                                <input type="radio" name="view_option_<?php echo $field->id_html ?>" id="view_option_<?php echo $m + 1 ?>" value="<?php echo $field_opt["val"][$m] ?>"> <label for="view_option_<?php echo $field->id_html ?>" style="display: inline;"><?php echo $field_opt["lab"][$m] ?></label></br>
                                            <?php } ?>
                                            <form>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php } else if ($field->type == "scale") { ?>
                        <li id="<?php echo $field->id_html ?>" class="scale question_fields">
                            <div class="field_header">
                                <div class="field_buttons_edit">
                                    <a href="#" class="edit_quest_sc">edit</a>
                                    <a href="#" class="done_quest_sc">done</a>
                                    <a href="#" class="delete_quest_sc">delete</a>
                                </div>
                                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                    Scale: <?php echo $field->id_html ?>
                                </div>
                            </div>
                            <div class="field_container">
                                <div class="scale_edit_state">
                                    <div class="scale_list">
                                        <?php  $field_opt = json_decode($field->options, true); ?>
                                        Question Title <input type="text" name="scale_title" class="question_title" value="<?php
                                        echo $field_opt["title"][0];
                                                    ?>"/>
                                        <div class="option_scale" id="opt_sc_1">
                                            Scale <select class="start_scale" name="start_scale_0" style="margin-left: 47px; min-width: 0em;"><option class="start_scale_opt" val="0" <?php if ($field_opt["str_sc"][0] == 0) {
                                                      echo "selected";
                                                  } ?>>0</option><option class="start_scale_opt" value="1" <?php if ($field_opt["str_sc"][0] == 1) {
                                        echo "selected";
                                    } ?>>1</option></select> to 
                                            <select class="end_scale" name="end_scale_0" style="min-width: 0em;">
            <?php for ($p = 2; $p < 8; $p++) { ?>
                                                    <option class="end_scale_opt" value="<?php echo $p ?>" <?php if ($field_opt["end_sc"][0] == $p) {
                    echo "selected";
                } ?>><?php echo $p ?></option>
            <?php } ?></select></br>
                                            Start Label <input type="text" class="start_label" name="start_label_0" style="margin-left: 18px; width: 80px;" value="<?php echo $field_opt["str_lb"][0] ?>"></br>
                                            Middle Label <input type="text" class="middle_label" name="middle_label_0" style="margin-left: 7px; width: 80px;" value="<?php echo $field_opt["mid_lb"][0] ?>"></br>
                                            End Label <input type="text" class="end_label" name="end_label_0" style="margin-left: 22px; width: 80px;" value="<?php echo $field_opt["end_lb"][0] ?>">
                                        </div>
                                    </div>
                                    <div class="field_rules">
                                        <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                                        <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="scale_view_state">
                                    <div class="question_scale_list">
                                        <div class="question_text"><?php echo $field_opt["title"][0] ?></div>
                                        <div class="option_scale_view" id="opt_sc_1">
                                            <table name="scale_label_set" class="scale_label_set">
                                                <tr>
                                                    <td class="scale_label_first" style="text-align: left;"><?php echo $field_opt["str_lb"][0] ?></td>
                                                    <td class="scale_label_second" style="text-align: left; padding-left:0px;"><?php echo $field_opt["mid_lb"][0] ?></td>
                                                    <td class="scale_label_third" style="text-align: left; padding-left:0px;"><?php echo $field_opt["end_lb"][0] ?></td>
                                                </tr>
                                            </table>
                                            <table name="scale_view_set" class="scale_view_set" style="text-align: center;">

                                                <tr class="num_label">
                                                    <?php for ($i = $field_opt["str_sc"][0]; $i <= $field_opt["end_sc"][0]; $i++) { ?>
                                                        <td style="padding-left: 25px;"><?php echo $i ?></td>
            <?php } ?>
                                                </tr>
                                                <tr class="radio_scale">
            <?php for ($i = $field_opt["str_sc"][0]; $i <= $field_opt["end_sc"][0]; $i++) { ?>
                                                        <td><input type="radio" id="scale_radio_<?php echo $i ?>" class="scale_radio" style="display: inline;" name="scale_radio_<?php echo $field->id_html ?>"></td>
            <?php } ?>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
        <?php } else if ($field->type == "hidden") { ?>
                        <li id="<?php echo $field->id_html ?>" class="hidden question_fields">
                            <div class="field_header">
                                <div class="field_buttons_edit">
                                    <a href="#" class="edit_quest_hd">edit</a>
                                    <a href="#" class="done_quest_hd">done</a>
                                    <a href="#" class="delete_quest_hd">delete</a>
                                </div>
                                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                    Hidden: <?php echo $field->id_html ?>
                                </div>
                            </div>
                            <div class="field_container">
                                <div class="hidden_edit_state">
                                    <div class="hidden_line">
                                        <?php $field_opt = json_decode($field->options, true); ?>
                                        Label <input type="text" name="hidden_question_field" class="question_title" value="<?php
            echo $field_opt["title"][0];
            ?>"/>
                                    </div>
                                </div>
                                <div class="hidden_view_state">
                                    <div class="hidden_line">
                                        <div class="question_text">
            <?php echo $field_opt["title"][0] ?>
                                        </div>
                                        <input type="hidden" class="hidden_label_text" name="hidden_label_text">
                                    </div>
                                </div>
                            </div>
                        </li>

        <?php } else if ($field->type == "grid") { ?>
                        <li id="<?php echo $field->id_html ?>" class="grid question_fields">
                            <div class="field_header">
                                <div class="field_buttons_edit">
                                    <a href="#" class="edit_quest_gr">edit</a>
                                    <a href="#" class="done_quest_gr">done</a>
                                    <a href="#" class="delete_quest_gr">delete</a>
                                </div>
                                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                                    Grid: <?php echo $field->id_html ?>
                                </div>
                            </div>
                            <div class="field_container">
                                <div class="grid_edit_state">
                                    <div class="grid_list">
                                        <?php $field_opt = json_decode($field->options, true); ?>
                                        Question Title <input type="text" name="scale_title" class="question_title" value="<?php
                                        echo $field_opt["title"][0];
                                        ?>"/>
                                        <div class="option_grid" id="opt_gr_1">
                                            Scale <select class="start_grid_scale" name="start_grid_0" style="margin-left: 47px; min-width: 0em;"><option class="start_grid_opt" val="0" <?php if ($field_opt["str_sc"][0] == 0) {
                                        echo "selected";
                                    } ?>>0</option><option class="start_grid_opt" value="1" <?php if ($field_opt["str_sc"][0] == 1) {
                                        echo "selected";
                                    } ?>>1</option></select> to 
                                            <select class="end_grid_scale" name="end_grid_0" style="min-width: 0em;">
            <?php for ($p = 2; $p <8; $p++) { ?>
                                                    <option class="end_grid_opt" value="<?php echo $p ?>" <?php if ($field_opt["end_sc"][0] == $p) {
                    echo "selected";
                } ?> ><?php echo $p ?></option>
            <?php } ?>
                                            </select> </br>
                                            Start Label <input type="text" class="start_label" name="start_label_0" style="margin-left: 18px; width: 80px;" value="<?php echo $field_opt["str_lb"][0] ?>"></br>
                                            Middle Label <input type="text" class="middle_label" name="middle_label_0" style="margin-left: 7px; width: 80px;" value="<?php echo $field_opt["mid_lb"][0] ?>"></br>
                                            End Label <input type="text" class="end_label" name="end_label_0" style="margin-left: 22px; width: 80px;" value="<?php echo $field_opt["end_lb"][0] ?>"></br>
                                            <div class="qrid_question_label_1">
                                                Question 1 <input type="text" class="label_question" name="label_question_1" style="margin-left: 17px;" value="<?php echo $field_opt["row_qst"][0] ?>"> <a href="#" class="add_grid_question">Add</a>
            <?php for ($i = 1; $i < count($field_opt["row_qst"]); $i++) { ?>
                                                    <div class="qrid_question_label_<?php echo $i + 1 ?>">
                                                  Question <?php echo $i+1?> <input type="text" class="label_question" name="label_question_<?php echo $i + 1 ?>" style="margin-left: 17px;" value="<?php echo $field_opt["row_qst"][$i] ?>"> <a href="#" class="add_grid_question">Add</a> <a href="#" class="remove_grid_question">Remove</a>
                                                    </div>
            <?php } ?>
                                                <input type="hidden" name="sum_row_question" class="sum_row_question" id="sum_row_question_<?php echo $field->id_html ?>" value="<?php echo count($field_opt["row_qst"]); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="field_rules">
                                        <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                                        <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="grid_view_state">
                                    <div class="question_grid_list">
                                        <div class="question_text"><?php echo $field_opt["title"][0] ?></div>
                                        <div class="option_grid_view" id="opt_sc_1">
                                            <table name="grid_label_set" class="grid_label_set">
                                                <tr>
                                                    <td name="empty_text" style="width: 200px;"></td>
                                                    <td class="grid_label_first" style="text-align: left; max-width:125px;"><?php echo $field_opt["str_lb"][0] ?></td>
                                                    <td class="grid_label_second" style="text-align: left; max-width:125px;"><?php echo $field_opt["mid_lb"][0] ?></td>
                                                    <td class="grid_label_third" style="text-align: left; max-width:125px;"><?php echo $field_opt["end_lb"][0] ?></td>
                                                </tr>
                                            </table>
                                            <table name="grid_view_set" class="grid_view_set" style="text-align: center;">
                                                <tr class=num_label>
                                                    
                                                    <td style="width: 200px;"></td>
            <?php for ($j = $field_opt["str_sc"][0]; $j <= $field_opt["end_sc"][0]; $j++) { ?>
                                                        <td style="padding-left: 25px;"><?php echo $j ?></td>
            <?php } ?>
                                                </tr>
            <?php for ($h = 0; $h < count($field_opt["row_qst"]); $h++) { ?>
                                                    <tr class="grid_scale_<?php echo $h ?>">
                                                        <td class="grid_row_question_<?php echo $h+1?>" name="grid_row_question_<?php echo $h+1?>" style="width: 200px;"><?php echo $field_opt["row_qst"][$h] ?></td>
                            <?php for ($n = $field_opt["str_sc"][0]; $n <= $field_opt["end_sc"][0]; $n++) { ?>
                                                            <td id="grid_radio_<?php echo $h+1 ?>_<?php echo $n ?>"><input type="radio" class="grid_radio" style="display: inline;" name="grid_radio_<?php echo $field->id_html ?>_<?php echo $h+1 ?>"></td>
                <?php } ?>
                                                    </tr>
            <?php }?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        
        <?php } else if($field->type == "email"){?>
                <li id="<?php echo $field->id_html?>" class="email question_fields">
                <div class="field_header">
                <div class="field_buttons_edit">
                <a href="#" class="edit_quest_em">edit</a>
                <a href="#" class="done_quest_em">done</a>
                <a href="#" class="delete_quest_em">delete</a>
                </div>
                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                Email: <?php echo $field->id_html?>
                </div>
                </div>
                <div class="field_container">
                <div class="email_edit_state">
                <div class="email_line">
                <?php $field_opt = json_decode($field->options, true); ?>
                Question Title <input type="text" name="single_quest_title" class="question_title" value="<?php 
                echo $field_opt["title"][0];
                ?>"/>
                </div>
                <div class="field_rules">
                <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                    <?php 
                    if($field->conditional_logic!=null){
                    $cl_f_content = json_decode($field->conditional_logic, true);

                    ?>
                    <div class="CL_panel_field">
                        <div class="CL_input_shows">
                            <select class="CL_shows" style="min-width: 0em;">
                                <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                            </select>
                            if
                            <select class="CL_anys" style="min-width: 0em;">
                                <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                            </select>
                            of this/these following match:
                        </div>
                        <?php 
                        for($n=0;$n<count($cl_f_content["options"]);$n++){
                        list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                        ?>
                        <div class="CL_input_val">
                            <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                        $cl_options = json_decode($af->options, true);
                                ?>
                                <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                <?php } endforeach;?>
                            </select>
                            <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                            </select>
                            <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                        if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                        $cl_options = json_decode($af->options,true);
                                        for($i=0;$i<count($cl_options["lab"]);$i++){
                                ?>
                                <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                <?php } break; }} endforeach;?>
                            </select>
                            <a href="#" class="addCL_field">Add</a>
                            <a href="#" class="removeCL_field">Remove</a>
                        </div>
                        <?php } ?>
                    </div>
                    <?php }else{ ?>
                    <div class="CL_panel_field">
                        <div class="CL_input_shows">
                            <select class="CL_shows" style="min-width: 0em;">
                                <option value="show" >Show</option>
                                <option value="hide" >Hide</option>
                            </select>
                            if
                            <select class="CL_anys" style="min-width: 0em;">
                                <option value="any" >Any</option>
                                <option value="all" >All</option>
                            </select>
                            of this/these following match:
                        </div>
                        <div class="CL_input_val">
                            <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                        $cl_options = json_decode($af->options, true);
                                ?>
                                <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                <?php } endforeach;?>
                            </select>
                            <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                <option value="is">Is</option>
                                <option value="not">Is not</option>
                            </select>
                            <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                        $cl_options = json_decode($af->options,true);
                                        for($i=0;$i<count($cl_options["lab"]);$i++){
                                ?>
                                <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                <?php } break; } endforeach;?>
                            </select>
                            <a href="#" class="addCL_field">Add</a>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                </div>
                <div class="email_view_state">
                <div class="email_line">
                <div class="question_text">
                <?php echo $field_opt["title"][0]?>
                </div>
                <div class="email_input">
                <input type="text" class="email_input_field" name="email_input_field" >
                </div>
                </div>
                </div>
                </div>
                </li>
            <?php } else if($field->type=="date"){ ?>
                <li id="<?php echo $field->id_html?>" class="date question_fields">
                <div class="field_header">
                <div class="field_buttons_edit">
                <a href="#" class="edit_quest_dt">edit</a>
                <a href="#" class="done_quest_dt">done</a>
                <a href="#" class="delete_quest_dt">delete</a>
                </div>
                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                Date: <?php echo $field->id_html?>
                </div>
                </div>
                <div class="field_container">
                <div class="date_edit_state">
                <div class="date_line">
                
                <?php 
                    $field_opt = json_decode($field->options, true);
                    $title = $field_opt["title"][0];
                    $info = isset($field_opt["info"][0]) ? $field_opt["info"][0] : '';
                ?>
                Question Title <input type="text" name="date_question_line" class="question_title" value="<?php echo $title; ?>"/><br>
                Info <input type="text" class="question_info" value="<?php echo $info; ?>"/><br>
                Year Range <input type="text" name="start_year" class="start_year" style="width: 35px; margin-left: 12px;" value="<?php echo $field_opt["str_yr"][0]?>"> to <input type="text" name="end_year" class="end_year" style="width: 35px;" value="<?php echo $field_opt["end_yr"][0]?>"><br>
                Option <select name="date_option" class="date_option" style="min-width: 0em; margin-left: 42px;"><option value="all" class="date_option_1" <?php if($field_opt["date_opt"][0]=="all"){echo "selected";} ?>>Show All</option><option value="two" class="date_option_2" <?php if($field_opt["date_opt"][0]=="two"){echo "selected";} ?>>Show Only Month and Year</option><option value="one" class="date_option_3" <?php if($field_opt["date_opt"][0]=="one"){echo "selected";} ?>>Show Only Year</option></select>
                </div>
                <div class="field_rules">
                <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                    <?php 
                    if($field->conditional_logic!=null){
                    $cl_f_content = json_decode($field->conditional_logic, true);

                    ?>
                    <div class="CL_panel_field">
                        <div class="CL_input_shows">
                            <select class="CL_shows" style="min-width: 0em;">
                                <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                            </select>
                            if
                            <select class="CL_anys" style="min-width: 0em;">
                                <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                            </select>
                            of this/these following match:
                        </div>
                        <?php 
                        for($n=0;$n<count($cl_f_content["options"]);$n++){
                        list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                        ?>
                        <div class="CL_input_val">
                            <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                        $cl_options = json_decode($af->options, true);
                                ?>
                                <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                <?php } endforeach;?>
                            </select>
                            <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                            </select>
                            <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                        if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                        $cl_options = json_decode($af->options,true);
                                        for($i=0;$i<count($cl_options["lab"]);$i++){
                                ?>
                                <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                <?php } break; }} endforeach;?>
                            </select>
                            <a href="#" class="addCL_field">Add</a>
                            <a href="#" class="removeCL_field">Remove</a>
                        </div>
                        <?php } ?>
                    </div>
                    <?php }else{ ?>
                    <div class="CL_panel_field">
                        <div class="CL_input_shows">
                            <select class="CL_shows" style="min-width: 0em;">
                                <option value="show" >Show</option>
                                <option value="hide" >Hide</option>
                            </select>
                            if
                            <select class="CL_anys" style="min-width: 0em;">
                                <option value="any" >Any</option>
                                <option value="all" >All</option>
                            </select>
                            of this/these following match:
                        </div>
                        <div class="CL_input_val">
                            <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                        $cl_options = json_decode($af->options, true);
                                ?>
                                <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                <?php } endforeach;?>
                            </select>
                            <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                <option value="is">Is</option>
                                <option value="not">Is not</option>
                            </select>
                            <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                <?php foreach($allfields as $af):
                                    if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                        $cl_options = json_decode($af->options,true);
                                        for($i=0;$i<count($cl_options["lab"]);$i++){
                                ?>
                                <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                <?php } break; } endforeach;?>
                            </select>
                            <a href="#" class="addCL_field">Add</a>
                        </div>
                    </div>
                    <?php } ?>
                </div>
                </div>
                <div class="date_view_state">
                <div class="date_line">
                <div class="question_text">
                <?php echo $field_opt["title"][0]?>
                </div>
                <div class="date_input">
                <input type="text" class="date_input_field" name="date_input_field" style="max-width: 10em;" />
                <input type="hidden" class="hidden_date_option" name="hidden_date_option" value="<?php echo $field_opt["date_opt"][0]?>">
                <input type="hidden" class="hidden_start_year" name="hidden_start_year" value="<?php echo $field_opt["str_yr"][0]?>">
                <input type="hidden" class="hidden_end_year" name="hidden_end_year" value="<?php echo $field_opt["end_yr"][0]?>">
                </div>
                </div>
                </div>
                </div>
                </li>
            <?php } else if($field->type=="number"){?>
                <li id="<?php echo $field->id_html?>" class="number question_fields">
                <div class="field_header">
                <div class="field_buttons_edit">
                <a href="#" class="edit_quest_no">edit</a>
                <a href="#" class="done_quest_no">done</a>
                <a href="#" class="delete_quest_no">delete</a>
                </div>
                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                Number: <?php echo $field->id_html?>
                </div>
                </div>
                <div class="field_container">
                <div class="number_edit_state">
                <div class="number_line">
                
                <?php 
                    $field_opt = json_decode($field->options, true);
                    $title = $field_opt["title"][0];
                    $info = isset($field_opt["info"][0]) ? $field_opt["info"][0] : '';
                ?>
                Question Title <input type="text" name="number_question_line" class="question_title" value="<?php echo $title; ?>"/><br />
                Info <input type="text" class="question_info" value="<?php echo $info; ?>"/>
                </div>
                <div class="field_rules">
                <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                </div>
                </div>
                <div class="number_view_state">
                <div class="number_line">
                <div class="question_text">
                <?php echo $field_opt["title"][0]?>
                </div>
                <div class="number_input">
                <input type="text" class="number_input_field" name="number_input_field" >
                </div>
                </div>
                </div>
                </div>
                </li>
            <?php } else if($field->type=="phone"){ ?>
                <li id="<?php echo $field->id_html?>" class="phone question_fields">
                <div class="field_header">
                <div class="field_buttons_edit">
                <a href="#" class="edit_quest_ph">edit</a>
                <a href="#" class="done_quest_ph">done</a>
                <a href="#" class="delete_quest_ph">delete</a>
                </div>
                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                Phone: <?php echo $field->id_html?>
                </div>
                </div>
                <div class="field_container">
                <div class="phone_edit_state">
                <div class="phone_line">
                <?php echo $field_opt = json_decode($field->options, true); ?>    
                Question Title <input type="text" name="phone_question_line" class="question_title" value="<?php 
                echo $field_opt["title"][0];
                ?>"/>
                </div>
                <div class="field_rules">
                <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                </div>
                </div>
                <div class="phone_view_state">
                <div class="phone_line">
                <div class="question_text">
                <?php echo $field_opt["title"][0]?>
                </div>
                <div class="phone_input">
                <input type="text" class="phone_input_field" name="phone_input_field" >
                </div>
                </div>
                </div>
                </div>
                </li>
            <?php } else if($field->type=="address"){?>
                <li id="<?php echo $field->id_html?>" class="address question_fields">
                <div class="field_header">
                <div class="field_buttons_edit">
                <a href="#" class="edit_quest_ad">edit</a>
                <a href="#" class="done_quest_ad">done</a>
                <a href="#" class="delete_quest_ad">delete</a>
                </div>
                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                Address: <?php echo $field->id_html?>
                </div>
                </div>
                <div class="field_container">
                <div class="address_edit_state">
                <div class="address_line">
                <?php echo $field_opt = json_decode($field->options, true); ?>    
                Question Title <input type="text" name="address_question_line" class="question_title" value="<?php 
                echo $field_opt["title"][0];
                ?>"/>
                </div>
                <div class="field_rules">
                <input type="checkbox" class="required_field" <?php if($field_opt["required"][0]=="true"){echo "checked";}?>> Required <br>
                <input type="checkbox" class="field_CL" <?php if($field->conditional_logic!=null){echo "checked";} ?>> Enable Condtional Logic <br>
                                        <?php 
                                        if($field->conditional_logic!=null){
                                        $cl_f_content = json_decode($field->conditional_logic, true);
                                        
                                        ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" <?php if($cl_f_content["show"][0]=="show"){echo "selected";}?>>Show</option>
                                                    <option value="hide" <?php if($cl_f_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" <?php if($cl_f_content["any"][0]=="any"){echo "selected";}?>>Any</option>
                                                    <option value="all" <?php if($cl_f_content["any"][0]=="all"){echo "selected";}?>>All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <?php 
                                            for($n=0;$n<count($cl_f_content["options"]);$n++){
                                            list($p_id,$s_id,$id_h)=explode("_",$cl_f_content["options"][$n]);
                                            ?>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>" <?php if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){echo "selected";}?>><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is" <?php if($cl_f_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
                                                    <option value="not" <?php if($cl_f_content["isnot"][$n]=="not"){echo "selected";}?>>Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            if($p_id==$af->page_id && $s_id==$af->section_id && $id_h==$af->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>" <?php if($cl_options["val"][$i]==$cl_f_content["values"][$n]){echo "selected";}?>><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; }} endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                                <a href="#" class="removeCL_field">Remove</a>
                                            </div>
                                            <?php } ?>
                                        </div>
                                        <?php }else{ ?>
                                        <div class="CL_panel_field">
                                            <div class="CL_input_shows">
                                                <select class="CL_shows" style="min-width: 0em;">
                                                    <option value="show" >Show</option>
                                                    <option value="hide" >Hide</option>
                                                </select>
                                                if
                                                <select class="CL_anys" style="min-width: 0em;">
                                                    <option value="any" >Any</option>
                                                    <option value="all" >All</option>
                                                </select>
                                                of this/these following match:
                                            </div>
                                            <div class="CL_input_val">
                                                <select id="CL_0" class="CL_field_question" style="min-width:0em; max-width: 25em" onchange="change_CL_field(jq(this))">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html) {
                                                            $cl_options = json_decode($af->options, true);
                                                    ?>
                                                    <option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page: ".$af->page_title." Section: ".$af->section_title." Question ".$af->id_html." : ".$cl_options["title"][0]?></option>
                                                    <?php } endforeach;?>
                                                </select>
                                                <select id="CL_is_0" class="field_is_not" style="min-width:0em;">
                                                    <option value="is">Is</option>
                                                    <option value="not">Is not</option>
                                                </select>
                                                <select id="address_CL_ch_0" class="CL_field_options" style="min-width:0em;">
                                                    <?php foreach($allfields as $af):
                                                        if($af->section_id!=$id_section || $af->id_html!=$field->id_html){
                                                            $cl_options = json_decode($af->options,true);
                                                            for($i=0;$i<count($cl_options["lab"]);$i++){
                                                    ?>
                                                    <option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>
                                                    <?php } break; } endforeach;?>
                                                </select>
                                                <a href="#" class="addCL_field">Add</a>
                                            </div>
                                        </div>
                                        <?php } ?>
                </div>
                </div>
                <div class="address_view_state">
                <div class="address_line">
                <div class="question_text">
                <?php echo $field_opt["title"][0]?>
                </div>
                <div class="address_input">
                Street Name <input type="text" class="address_st_input_field" name="address_st_input_field" > </br>
                City <input type="text" class="address_city_input_field" name="address_city_input_field" style="width: 15%; margin-left: 50px;"> Province <select name="address_prov_input" class="address_prov_input" style="min-width: 0em;"><option name="address_prov_1" id="address_prov_1" value="jakarta">Jakarta</option><option name="address_prov_2" id="address_prov_2" value="jawa_barat">Jawa Barat</option><option name="address_prov_3" id="address_prov_3" value="jawa_tengah">Jawa Tengah</option><option name="address_prov_4" id="address_prov_4" value="jawa_timur">Jawa Timur</option></select> </br>
                Zip Code <input type="text" class="address_zc_input_field" name="address_zc_input_field" style="width: 5em; margin-left: 23px;" >
                </div>
                </div>
                </div>
                </div>
                </li>
            <?php } else if($field->type=="readonly"){?>
                <li id="<?php echo $field->id_html?>" class="readonly question_fields">
                <div class="field_header">
                <div class="field_buttons_edit">
                <a href="#" class="edit_quest_ro">edit</a>
                <a href="#" class="done_quest_ro">done</a>
                <a href="#" class="delete_quest_ro">delete</a>
                </div>
                <div class="quest_admin_label" style="font-size: 11pt; font-weight: bold; padding: 5px;">
                User Profile: <?php echo $field->id_html?>
                </div>
                </div>
                <div class="field_container">
                <div class="readonly_edit_state">
                <div class="readonly_line">
                Label <input type="text" name="readonly_question_field" class="question_title" value="<?php 
                $field_opt = json_decode($field->options, true);
                echo $field_opt["title"][0];
                ?>"/>
                <br />
                Field <!--<input type="text" class="user_field" value="<?php if(isset($field_opt["user_field"][0])){echo $field_opt["user_field"][0];} ?>" />-->
                <select class="user_field" id="<?php echo $field->id_html?>">
                    <?php foreach ($db_fields as $df) { ?>
                        <option value="<?php echo $df; ?>" <?php if($df == $field_opt["user_field"][0]){echo "selected";}?>><?php echo $df; ?></option>
                    <?php } ?>
                </select>
                </div>
                <div class="field_rules">
                <input style="display: none;" type="checkbox" class="required_field" <?php if($field_opt["required"]=="true"){echo "checked";}?>>
                </div>
                </div>
                <div class="readonly_view_state">
                <div class="readonly_line">
                <div class="question_text">
                <?php echo $field_opt["title"][0]?>
                </div>
                </div>
                </div>
                </div>
                </li>
              <?php } ?>
    <?php endforeach; ?>
<?php } ?>
    </ul>
</form>
<div id="floating_question_selector">
    <div id="floating_label">
        Pilih Jenis Pertanyaan...
    </div>
    <div id="questions_button">
        <button class="quest_butt" onclick="add_single_line();">Single Line Text</button>
        <button class="quest_butt" onclick="add_email();">Email</button>
        <button class="quest_butt" onclick="add_dropdown();">Dropdown List</button>
        <button class="quest_butt" onclick="add_date();">Date</button>
        <button class="quest_butt" onclick="add_checkbox();">Checkboxes</button>
        <button class="quest_butt" onclick="add_number();">Number</button>
        <button class="quest_butt" onclick="add_radio();">Radio Buttons</button>
        <button class="quest_butt" onclick="add_phone();">Phone</button>
        <button class="quest_butt" onclick="add_scale();">Scale</button>
        <!-- <button class="quest_butt" onclick="add_address();">Address</button> -->
        <!-- <button class="quest_butt" onclick="add_hidden();">Hidden</button> -->
        <button class="quest_butt" onclick="add_readonly();">User Field</button>
        <button class="quest_butt" onclick="add_grid();">Grid</button>
    </div>
</div> 


<!--
<form action="<?php echo base_url().'/admin/kuesioner/kuesioner_section/create'?>">
<div class="form-horizontal">
<h1>Add Fields</h1>
<hr>
	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="id_html"><?php echo lang('kuesioner:id_html'); ?></label>

		<div class="col-sm-10">
			
			<input name="id_html" type="text" value="" class="col-xs-10 col-sm-5" id="" />
			
		</div>
	</div>
			
	<input name="kuesioner_id" type="text" value="<?php echo $fields['kuesioner_id']; ?>" class="col-xs-10 col-sm-5" id="" hidden="true"/>
	<input name="page_id" type="text" value="<?php echo $fields['page_id']; ?>" class="col-xs-10 col-sm-5" id="" hidden="true"/>
	<input name="section_id" type="text" value="<?php echo $fields['id'] ?>" class="col-xs-10 col-sm-5" id="" hidden="true"/>


	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="type"><?php echo lang('kuesioner:type'); ?></label>

		<div class="col-sm-10">

			<input name="type" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="options"><?php echo lang('kuesioner:options'); ?></label>

		<div class="col-sm-10">

			<input name="options" type="text" value="" class="col-xs-10 col-sm-5" id="" />
		
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="required"><?php echo lang('kuesioner:required'); ?></label>

		<div class="col-sm-10">
			
			<input name="required" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="conditional_logic"><?php echo lang('kuesioner:conditional_logic'); ?></label>

		<div class="col-sm-10">

			<input name="conditional_logic" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
		</div>
	</div>

</div>

<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<button type="submit" class="btn btn-primary"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

</form>-->
