<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Welcome extends Module
{
    public $version = '1.0';

    public function info()
    {
        $info = array();
		$info['name'] = array(
			'en' => 'Welcome',
			'id' => 'Welcome',
		);
		$info['description'] = array(
			'en' => 'Welcome Message',
			'id' => 'Welcome Message',
		);
		$info['frontend'] = true;
		$info['backend'] = true;
		$info['menu'] = 'content';
		$info['roles'] = array(
			'access_welcome_backend', 'view_all_welcome', 'view_own_welcome', 'edit_all_welcome', 'edit_own_welcome', 'delete_all_welcome', 'delete_own_welcome', 'create_welcome',
		);
		
		if(group_has_role('welcome', 'access_welcome_backend')){
			$info['sections']['welcome']['name'] = 'welcome:welcome:plural';
			$info['sections']['welcome']['uri'] = 'admin/welcome/welcome/index';
			
			if(group_has_role('welcome', 'create_welcome')){
				$info['sections']['welcome']['shortcuts']['create'] = array(
					'name' => 'welcome:welcome:new',
					'uri' => 'admin/welcome/welcome/create',
					'class' => 'add'
				);
			}
		}
		
		return $info;
    }
	
	/**
	 * Admin menu
	 *
	 * If a module has an admin_menu function, then
	 * we simply run that and allow it to manipulate the
	 * menu array
	 */
	public function admin_menu(&$menu_items, &$menu_order){
		
	}

    /**
     * Install
     *
     * This function will set up our streams
	 *
     */
    public function install()
    {
        $this->load->dbforge();

		// welcome
		$fields = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => 11,
				'unsigned' => TRUE,
				'auto_increment' => TRUE,
			),
			'welcome_message' => array(
				'type' => 'TEXT',
			),
		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table('welcome_welcome', TRUE);

		return true;
    }

    /**
     * Uninstall
     *
     * Uninstall our module - this should tear down
     * all information associated with it.
     */
    public function uninstall()
    {
		$this->load->dbforge();
        $this->dbforge->drop_table('welcome_welcome');
        return true;
    }

    public function upgrade($old_version)
    {
        return true;
    }

    public function help()
    {
        // Return a string containing help info
        // You could include a file and return it here.
        return "No documentation has been added for this module.<br />Contact the module developer for assistance.";
    }

}