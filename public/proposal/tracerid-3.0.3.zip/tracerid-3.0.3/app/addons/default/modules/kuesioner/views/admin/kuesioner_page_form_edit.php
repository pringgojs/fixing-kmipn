<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/reveal.css" />
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery-ui.css" />
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery.ui.theme.css" />

<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-1.9.0.min.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-ui-1.10.1.custom.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery.reveal.js"></script>	

<script type="text/javascript">
	jq = jQuery.noConflict(true);
	jq(document).ready(function(){
        jq(".CLpanel").hide();
        
        jq("#up,#down").click(function(){
            addpage(jq(this));
            save_row_list();
        });
        jq(".delete").click(function(){
            deletepage(jq(this)); 
        });
        jq(".addCL").click(function(event){
            //alert('click');
            event.preventDefault();
            addCL();
        });
		jq(".removeCL").click(function(event){
            event.preventDefault();
			jq(this).parent().remove();
        });
        jq("#CL_page").click(function(){
            if(jq(this).is(':checked')){
                jq(".CLpanel").show();
            }else{
                jq(".CLpanel").hide();
            }
        });
        jq("#CL_page").each(function(){
            if(jq(this).is(':checked')){
                jq(".CLpanel").show();
            }else{
                jq(".CLpanel").hide();
            }
        });
        jq('.tambah').click(function(e) {
            e.preventDefault();
            jq('#myModal').reveal();
        });
        jq('#insert, #simpan').click(function(){
           	//alert('click');
            save_row_list();
            save_CL_page();
        })
        
    });
    
</script>
<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner_page:'.$mode); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<?php 
		$value = NULL;
		if($this->input->post('id') != NULL){
			$value = $this->input->post('id');
		}elseif($mode == 'edit'){
			$value = $fields['id'];
		}
	?>
	<input name="id" type="hidden" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="title"><?php echo lang('kuesioner:title'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('title') != NULL){
					$value = $this->input->post('title');
				}elseif($mode == 'edit'){
					$value = $fields['title'];
				}
			?>
			<input name="title" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
		</div>
	</div>

	<?php 
		$value = NULL;
		if($this->input->post('kuesioner_id') != NULL){
			$value = $this->input->post('kuesioner_id');
		}elseif($mode == 'edit'){
			$value = $fields['kuesioner_id'];
		}
	?>
	<input name="kuesioner_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" hidden=true/>
	

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:deskripsi'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('deskripsi') != NULL){
					$value = $this->input->post('deskripsi');
				}elseif($mode == 'edit'){
					$value = $fields['deskripsi'];
				}
			?>
			<textarea  name="deskripsi" class="col-xs-10 col-sm-5"><?php echo $value; ?></textarea>
			<!--<input name="deskripsi" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />-->
			
		</div>
	</div>

	<?php $conditional_logic = json_decode($fields['conditional_logic'], true);?>
	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="conditional_logic"><?php echo lang('kuesioner:conditional_logic'); ?></label>

		<div class="col-sm-10">
			<!--<?php 
				$value = NULL;
				if($this->input->post('conditional_logic') != NULL){
					$value = $this->input->post('conditional_logic');
				}elseif($mode == 'edit'){
					$value = $fields['conditional_logic'];
				}
			?>
			<input name="conditional_logic" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />-->
			<div class="input">
		        <?php //echo form_checkbox(array('name' => 'kuesioner_CL_page', 'id' => 'CL_page')) ?>
		        <input type="checkbox" name="kuesioner_CL_page" id="CL_page" <?php if($conditional_logic['options'][0] != ''){echo "checked";}?>>
		    </div>
		</div>
	</div>
	<input type="hidden" name="sections" id="sections">
	<!-- MULAI -->
<!--<div class="clearfix">
    <?php echo form_label('Conditional Logic', 'kuesioner_CL_page'); ?>
    <div class="input">
        <?php //echo form_checkbox(array('name' => 'kuesioner_CL_page', 'id' => 'CL_page')) ?>
        <input type="checkbox" name="kuesioner_CL_page" id="CL_page" <?php if($fields['conditional_logic']!=null){echo "checked";}?>>
    </div>
</div>-->
	
	<div class="clearfix">
	    <div class="CLpanel">

	    	<?php 
	    	if(is_array($allfields) AND count($allfields) > 0): 
	    		$jumlah = 0;
	    		foreach ($allfields as $count) {
	    			if($count->page_id != $id_page){
	    				$jumlah++;
	    			}
	    		}
	    		if($jumlah != 0):
	    	?>
		        <?php if($fields['conditional_logic'] != '' && $conditional_logic['options'][0]): ?>

		        <?php $cl_p_content = json_decode($fields['conditional_logic'],true); ?>

		        <div class="input">
		            <select class="show_option" name="show_option" style="min-width: 0em">
		                <option value="show" <?php if($cl_p_content["show"][0]=="show"){echo "selected";}?>>Show</option>
		                <option value="hide" <?php if($cl_p_content["show"][0]=="hide"){echo "selected";}?>>Hide</option>
		            </select>
		            <select class="any_all" name="any_all" style="min-width: 0em">
		                <option value="any" <?php if($cl_p_content["any"][0]=="any"){echo "selected";}?>>Any</option>
		                <option value="all" <?php if($cl_p_content["any"][0]=="all"){echo "selected";}?>>All</option>
		            </select>
		            of this/these following match:
		        </div>
		        
				<?php for($n=0;$n<count($cl_p_content["options"]);$n++): ?>

		        <?php
				// extract IDs
				list($p_id, $s_id, $id_h) = explode("_",$cl_p_content["options"][$n]);
				
				// get type of field
				$this->db->where('page_id', $p_id);
				$this->db->where('section_id', $s_id);
				$this->db->where('id_html', $id_h);
				$cl_option_field_type = $this->db->get('default_kuesioner_kuesioner_field')->row('type');
				//echo $cl_option_field_type;
				?>

		        <div class="input">

		            <select name="CL1" class="CL1 page_conditional" style="min-width:0em; max-width: 25em" onchange="change_options_CL(jq(this))">
		                
						<?php foreach ($allfields as $af): ?>

		                <?php if($af->page_id != $id_page): ?>

		                    <?php $cl = json_decode($af->options,true); ?>

		                    <option value="<?php echo $af->page_id?>_<?php echo $af->section_id?>_<?php echo $af->id_html?>" <?php if($af->page_id==$p_id && $af->section_id==$s_id && $af->id_html==$id_h){echo "selected";}?>>
								Page "<?php echo $af->page_title?>" &raquo;
								Section "<?php echo $af->section_title?>" &raquo;
								Question "<?php echo $cl["title"][0];?>"
		                    </option>

		                <?php  endif; ?>
						
						<?php endforeach;?>

		            </select>
		            
		            <select name="is_not" class="page_is_not" style="min-width: 0em">
		                <option value="is" <?php if($cl_p_content["isnot"][$n]=="is"){echo "selected";}?>>Is</option>
		                <option value="not" <?php if($cl_p_content["isnot"][$n]=="not"){echo "selected";}?>>Is Not</option>
		            </select>

		            <div class="opt_vals">

					<?php if($cl_option_field_type == 'readonly'): ?>

					<input type="text" name="opt_vals" value="<?php echo $cl_p_content['value'][$n]; ?>" style="width: 100px;" />

					<?php else: ?>

					<select name="opt_vals" style="min-width: 0em; max-width: 15em">
		                <?php foreach ($allfields as $af): ?>
		                        
						<?php if($af->page_id != $id_page): ?>
							
						<?php if($af->page_id == $p_id && $af->section_id == $s_id && $af->id_html == $id_h): ?>
							
							<?php
							$cl_options = json_decode($af->options, true);
							for($k = 0; $k < count($cl_options["lab"]); $k++):
							?>

							<option value="<?php echo $cl_options["val"][$k]?>" <?php if($cl_p_content["value"][$n]==$cl_options["val"][$k]){echo "selected";}?>>
								<?php echo $cl_options["lab"][$k]?>
							</option>
						
							<?php endfor; ?>
							
						<?php endif; ?>
						
						<?php endif; ?>

						<?php endforeach;?>
					</select>

					<?php endif; /*$cl_option_field_type == 'readonly'*/ ?>

					</div>
		            
					<a href="#" class="addCL">Add</a>

					<?php if($n > 0): ?>
					<a href="#" class="removeCL">Remove</a>
					<?php endif; ?>

		        </div>

		        <?php endfor; ?>

				<?php else: ?>

		        <div class="input">
		            <?php
		            $shows = array('show' => 'Show', 'hide' => 'Hide');
		            echo form_dropdown('show_option', $shows, 'show', 'class="show_option" style="min-width:0em"')
		            ?> if <?php
		            $any_all = array('any' => 'Any', 'all' => 'All');
		            echo form_dropdown('any_all', $any_all, 'any', 'class="any_all" style="min-width:0em"')
		            ?> of this/these following match:
		        </div>
		        <div class="input">
		            <select name="CL1" class="CL1 page_conditional" style="min-width:0em; max-width: 25em" onchange="change_options_CL(jq(this))">
		                <?php foreach ($allfields as $af): if($af->page_id!=$id_page){?>
		                    <?php $cl = json_decode($af->options,true); ?>
		                    <option value="<?php echo $af->page_id?>_<?php echo $af->section_id?>_<?php echo $af->id_html?>">
								Page "<?php echo $af->page_title?>" &raquo;
								Section "<?php echo $af->section_title?>" &raquo;
								Question "<?php echo $cl["title"][0];?>"
		                    </option>      
		                <?php } endforeach;?>
		            </select>
		            
		            <?php
		            $CL_is_not = array('is' => 'Is', 'not' => 'Is Not');
		            echo form_dropdown('is_not', $CL_is_not, 'is', 'class="page_is_not" style="min-width:0em"');
					?>
					<div class="opt_vals">
		            <select name="opt_vals" style="min-width: 0em; max-width: 20em">
		                <?php foreach ($allfields as $af): ?>
							<?php if($af->page_id!=$id_page): ?>
								<?php $cl_options = json_decode($af->options, true); ?>
								<?php for($k=0;$k<count($cl_options["lab"]);$k++): ?>

								<option value="<?php echo $cl_options["val"][$k]?>">
									<?php echo $cl_options["lab"][$k]; ?>
								</option>

								<?php endfor; /* for($k=0;$k<count($cl_options["lab"]);$k++) */ ?>
								<?php break; ?>
							<?php endif; /* if($af->page_id!=$id_page) */ ?>
						<?php endforeach; /* foreach ($allfields as $af) */ ?>
					</select>
					</div>
		            <?php
		            
		            ?>
		            <a href="#" class="addCL">Add</a>
		        </div>

		        <?php endif; ?>
			    <?php else: ?>
			    	<div class="input">Tidak tersedia <i>field</i> yang dapat digunakan sebagai aturan <i>conditional logic</i>.</div>
				<?php endif; ?>
		    <?php else: ?>
		    	<div class="input">Tidak tersedia <i>field</i> yang dapat digunakan sebagai aturan <i>conditional logic</i>.</div>
		    <?php endif; ?>
	    </div>
	</div>

	<input type="hidden" name="hidden_cl_page" id="hidden_cl_page">
	<input type="hidden" name="pages_attr" id="pages_attr">
	<div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
			<button type="submit" class="btn btn-primary" id="simpan"><span><?php echo lang('buttons:save'); ?></span></button>
			<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
		</div>
	</div>
</div>
<?php echo form_close();?>

 <a href='#' id="btn_add_section">Tambah Section</a>

<form action="<?php echo base_url().'admin/kuesioner/kuesioner_section/create'; ?>" method="post" id="add_section">
<center>
	<h1>Add Section</h1>
	<table class="table table-striped table-bordered table-hover">
		<tr>
			<td >
				<label for="title"><?php echo lang('kuesioner:title'); ?></label>
			</td>
			<td>:</td>
			<td>
				<input name="title" type="text" class="col-xs-10 col-sm-10" id="" />
			</td>
		</tr>
		<tr>
			<td>
				<label for="deskripsi"><?php echo lang('kuesioner:deskripsi'); ?></label>
			</td>
			<td>:</td>
			<td>
				<input name="deskripsi" type="text" class="col-xs-10 col-sm-10" id="" />
			</td>
		</tr>
		<input name="kuesioner_id" type="hidden" value="<?php echo $fields['kuesioner_id']; ?>" class="col-xs-10 col-sm-5" id=""/>
		<input name="page_id" type="hidden" value="<?php echo $fields['id']; ?>" class="col-xs-10 col-sm-5" id="" />
		<tr>
			<td colspan="3" align='center'>
				<button type="submit" class="btn btn-primary" id="insert"><span><?php echo lang('buttons:save'); ?></span></button>
			</td>
		</tr>
		
	</table>
</center>
</form>

<script>
	$("#add_section").dialog({
	    autoOpen: false,
	    show: 'slide',
	    resizable: false,
	    position: 'center',
	    stack: true,
	    height: 'auto',
	    width: 'auto',
	    modal: true
	});
	$("#btn_add_section").click(function(e){
		$("#add_section").dialog({
			autoOpen: true,
			width: '600px',
			height: 'auto',
		});
	});
</script>


<?php if ($total > 0): ?>
	
	<p class="pull-right"><?php echo lang('kuesioner:showing').' '.count($sections).' '.lang('kuesioner:of').' '.$total ?></p>
	
	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>
				<th>Section ID</th>
				<th><?php echo lang('kuesioner_section:title'); ?></th>
				<th><?php echo lang('kuesioner_section:deskripsi'); ?></th>
				<th><?php echo lang('kuesioner_section:conditional_logic'); ?></th>
				<th><?php echo "Num of Question"; ?></th>
				<th><?php echo "Action"; ?></th>
			</tr>
		</thead>
		<tbody>
			<?php 
			$cur_page = (int) $this->uri->segment($pagination_config['uri_segment']);
			if($cur_page != 0){
				$item_per_page = $pagination_config['per_page'];
				$no = (($cur_page -1) * $item_per_page) + 1;
			}else{
				$no = 1;
			}
			?>
			
			<?php foreach ($sections as $kuesioner_section_entry => $val): ?>
			<tr>
				<td class="id_section"><?php echo $val->id; ?></td>
				<td><?php echo $val->title; ?></td>
				<td><?php echo $val->deskripsi; ?></td>
				<!--<td><?php echo $val->section_options; ?></td>
				<td><?php echo $val->fields; ?></td>
				<td><?php echo $val->conditional_logic; ?></td>-->
				<td>
					<?php 
					$cl = json_decode($val->conditional_logic,true);

					if ($cl['options'] != null) {
						$td = $cl["show"][0]." if ".$cl["any"][0].":\n";
						for($i=0;$i<count($cl["options"]);$i++){
							list($p_id,$s_id,$id_h)=explode("_",$cl["options"][$i]);

							// get conditional logic page name
							$this->db->where('kuesioner_id', $id_kuesioner);
							$this->db->where('id', $p_id);
							$page_name = $this->db->get('default_kuesioner_kuesioner_page')->row('title');

							// get conditional logic section name
							$this->db->where('kuesioner_id', $id_kuesioner);
							$this->db->where('page_id', $p_id);
							$this->db->where('id', $s_id);
							$section_name = $this->db->get('default_kuesioner_kuesioner_section')->row('title');

							// get field options
							$this->db->where('kuesioner_id', $id_kuesioner);
							$this->db->where('page_id', $p_id);
							$this->db->where('section_id', $s_id);
							$this->db->where('id_html', $id_h);
							$field_options = $this->db->get('default_kuesioner_kuesioner_field')->row('options');
							$field_options_arr = json_decode($field_options);

							// get conditional logic question text
							$field_name = $field_options_arr->title[0];

							// get conditional logic question selected value
							$field_values = $field_options_arr->val;
							$field_value_labels = $field_options_arr->lab;
							$selected_value_idx = array_search($cl["value"][$i], $field_values);
							$selected_value_label = $field_value_labels[$selected_value_idx];

							// make human sentence
							$td = $td.'Page "'.$page_name.'" &raquo; Section "'.$section_name.'" &raquo; Question "'.$field_name.'" '.$cl["isnot"][$i].' "'.$selected_value_label.'"'."\n";
						}
						echo nl2br($td);
					} else {
						echo "none";
					}
					?>
				</td>
				<td>
					<?php
						$this->db->where('section_id', $val->id);
						$this->db->from('default_kuesioner_kuesioner_field');
						echo $this->db->count_all_results();
					?>
				</td>
				<td class="acti ons">
				<a href="<?php echo current_url() . '#'; ?>" class="btn btn-xs btn-grey" id="up">Up</a>
	            <a href="<?php echo current_url() . '#'; ?>" class="btn btn-xs btn-grey" id="down">Down</a>
				<!--<?php 
				if(group_has_role('kuesioner', 'view_all_kuesioner_section')){
					echo anchor('admin/kuesioner/kuesioner_section/view/' . $val->id, lang('global:view'), 'class="btn btn-xs btn-info view"');
				}elseif(group_has_role('kuesioner', 'view_own_kuesioner_section')){
					if($kuesioner_section_entry['created_by']['user_id'] == $this->current_user->id){
						echo anchor('admin/kuesioner/kuesioner_section/view/' . $val->id, lang('global:view'), 'class="btn btn-xs btn-info view"');
					}
				}
				?>-->
				<?php 
				if(group_has_role('kuesioner', 'edit_all_kuesioner_section')){
					echo anchor('admin/kuesioner/kuesioner_section/edit/' . $val->kuesioner_id.'/'.$val->page_id.'/'.$val->id, lang('global:edit'), 'class="btn btn-xs btn-info edit"');
				}elseif(group_has_role('kuesioner', 'edit_own_kuesioner_section')){
					if($kuesioner_section_entry['created_by']['user_id'] == $this->current_user->id){
						echo anchor('admin/kuesioner/kuesioner_section/edit/' . $val->kuesioner_id.'/'.$val->page_id.'/'.$val->id, lang('global:edit'), 'class="btn btn-xs btn-info edit"');
					}
				}
				?>
				<?php 
				if(group_has_role('kuesioner', 'delete_all_kuesioner_section')){
					echo anchor('admin/kuesioner/kuesioner_section/delete/' . $val->id, lang('global:delete'), array('class' => 'confirm btn btn-xs btn-danger delete'));
				}elseif(group_has_role('kuesioner', 'delete_own_kuesioner_section')){
					if($kuesioner_section_entry['created_by']['user_id'] == $this->current_user->id){
						echo anchor('admin/kuesioner/kuesioner_section/delete/' . $val->id, lang('global:delete'), array('class' => 'confirm btn btn-xs btn-danger delete'));
					}
				}
				?>
				</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	
	<!-- <?php echo $pagination; ?> -->
	
<?php else: ?>
	<div class="well"><?php echo lang('kuesioner:kuesioner_section:no_entry'); ?></div>
<?php endif;?>

<script type="text/javascript">
	
    function addpage(anu){
        var row = anu.parents("tr:first");
        if (anu.is("#up")) {
            row.insertBefore(row.prev());
        } else {
            row.insertAfter(row.next());
        }
    }
    function deletepage(anu){
        // var row = anu.parents("tr:first");
        // if(anu.is(".delete")){
        //     row.remove();
        // }
    }

    function addCL(){
        var shows = '<select class="CL2 page_conditional" style="min-width:0em; max-width: 25em;" onchange="change_options_CL(jq(this))">'
            +'<?php foreach ($allfields as $af): if($af->page_id!=$id_page){?><?php $cl = json_decode($af->options,true); ?><option value="<?php echo $af->page_id."_".$af->section_id."_".$af->id_html?>"><?php echo "Page ".$af->page_title." - Section ".$af->section_title." - Question ".$af->id_html." : ".$cl["title"][0] ?></option><?php } endforeach;?></select>'
            +' <select name="is_not" class="page_is_not" style="min-width:0em"><option value="is">Is</option><option value="not">Is Not</option></select>'
            +' <div class="opt_vals">'
			+' <select name="opt_vals" style="min-width:0em">'
                <?php foreach($allfields as $af): if($af->page_id!=$id_page){
                        $cl_options = json_decode($af->options, true);
                        for($k=0;$k<count($cl_options["lab"]);$k++){ ?>
                            +'<option value="<?php echo $cl_options["val"][$k]?>">'
                                +'<?php echo $cl_options["lab"][$k]?>'
                           +'</option>'
                        <?php } break;} endforeach; ?>+'</select></div>'
        var add_remove = ' <a href=# class="addCL">Add</a> <a href=# class="removeCL">Remove</a>';
        var newCLpanel = jq('<div class="input">'+shows+add_remove+'</div>');
        jq('.CLpanel').append(newCLpanel);
        newCLpanel.find(".addCL,.removeCL").click(function(event){
            if(jq(this).is(".addCL")){
            	event.preventDefault();
                addCL();
            }
            else{
                event.preventDefault();
                jq(this).parent().remove();  
            } 
        });
    }

    function removeCL(anu){
        anu.parent.remove();
    }
    
    function save_CL_page(){
        var CL_page = {};
        CL_page["options"] = [];
        CL_page["op_labels"] = [];
        CL_page["isnot"] = [];
        CL_page["value"] = [];
        CL_page["val_labels"] = [];
        CL_page["show"] = [];
        CL_page["any"] = [];
        
        var data = "";
        if(jq("#CL_page").is(":checked")){
            jq(".show_option").each(function(){
               CL_page["show"].push(jq(this).find(":selected").val()); 
            });
            jq(".any_all").each(function(){
               CL_page["any"].push(jq(this).find(":selected").val()); 
            });
            jq(".page_is_not").each(function(){
               CL_page["isnot"].push(jq(this).find(":selected").val()); 
            });
            jq(".page_conditional").each(function(){
                CL_page["options"].push(jq(this).find(":selected").val());
                CL_page["op_labels"].push(jq.trim(jq(this).find(":selected").text().split(": ")[1]));
            });
            jq(".opt_vals").each(function(){
				jq(this).find("[name='opt_vals']").each(function(){
					CL_page["value"].push(jq(this).val());
					CL_page["val_labels"].push(jq(this).val());
				});
				//CL_page["val_labels"].push(jq.trim(jq(this).find(":selected").text()));
            });
            data = JSON.stringify(CL_page);
            jq("#hidden_cl_page").val(data);
        }
        //alert("alksjdklajsdlajdlasjd");
		return false;
    }
    
    function change_options_CL(anu){
        var temp = [];
        
        var div_opt_vals = anu.parents("div:first").find(".opt_vals");
        var options = '';
        var page_id = anu.val().split("_")[0];
        var section_id = anu.val().split("_")[1];
        var id_html = anu.val().split("_")[2];

		div_opt_vals.html("<select style='min-width: 0em; max-width: 15em' name='opt_vals'>");
		var select = div_opt_vals.find("select");
        
		<?php foreach ($allfields as $af): $cl_options = json_decode($af->options,true);  ?>
			var p_id = <?php echo $af->page_id?>;
			var s_id = <?php echo $af->section_id?>;
			var id_h = <?php echo $af->id_html?>;
			var field_type = "<?php echo $af->type; ?>";

			if(field_type == "readonly"){
				if(page_id==p_id && section_id==s_id && id_html==id_h){
					div_opt_vals.html('<input type="text" name="opt_vals" style="width:100px;" />');
				}
			}else{
				if(page_id==p_id && section_id==s_id && id_html==id_h){
				<?php for($i=0;$i<count($cl_options["lab"]);$i++) {?>
					select.append('<option value="<?php echo $cl_options["val"][$i]?>"><?php echo $cl_options["lab"][$i]?></option>');
				<?php } ?>
				}
			}
        <?php endforeach;?>
    }

    function save_row_list(){
        var pages_attr = {};
        pages_attr['urutan'] = [];
        pages_attr['jumlah'] = [];
        jq(".id_section").each(function(){
            var id = jq(this).text();
            pages_attr['urutan'].push(id);
        });
        pages_attr['jumlah'].push(pages_attr['urutan'].length);
        
        var data = JSON.stringify(pages_attr);
        jq("#sections").val(data);
        jq("#page_attr").val(data);
    }
</script>