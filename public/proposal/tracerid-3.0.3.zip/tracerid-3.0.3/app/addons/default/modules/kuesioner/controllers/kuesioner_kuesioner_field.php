<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Kuesioner Module
 *
 * Modul Kuesioner
 *
 */
class Kuesioner_kuesioner_field extends Public_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner_field';
	
    public function __construct()
    {
        parent::__construct();

        // -------------------------------------
		// Load everything we need
		// -------------------------------------

		$this->lang->load('buttons');
        $this->lang->load('kuesioner');
		
		$this->load->model('kuesioner_field_m');
    }

    /**
	 * List all kuesioner_field
     *
     * @return	void
     */
    public function index()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner_field') AND ! group_has_role('kuesioner', 'view_own_kuesioner_field')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
        // -------------------------------------
		// Pagination
		// -------------------------------------

		$pagination_config['base_url'] = base_url(). 'kuesioner/kuesioner_field/index';
		$pagination_config['uri_segment'] = 4;
		$pagination_config['total_rows'] = $this->kuesioner_field_m->count_all_kuesioner_field();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;
		
        // -------------------------------------
		// Get entries
		// -------------------------------------
		
        $data['kuesioner_field']['entries'] = $this->kuesioner_field_m->get_kuesioner_field($pagination_config);
		$data['kuesioner_field']['total'] = count($data['kuesioner_field']['entries']);
		$data['kuesioner_field']['pagination'] = $this->pagination->create_links();

		// -------------------------------------
		// Build the page. 
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_field:plural'))
			->set_breadcrumb('Home', '/')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:plural'))
			->build('kuesioner_field_index', $data);
    }
	
	/**
     * Display one kuesioner_field
     *
     * @return  void
     */
    public function view($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner_field') AND ! group_has_role('kuesioner', 'view_own_kuesioner_field')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Get our entry.
		// -------------------------------------
		
        $data['kuesioner_field'] = $this->kuesioner_field_m->get_kuesioner_field_by_id($id);
		
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'view_all_kuesioner_field')){
			if($data['kuesioner_field']->created_by != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}

		// -------------------------------------
		// Build the page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_field:view'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:plural'), '/kuesioner/kuesioner_field/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:view'))
			->build('kuesioner_field_entry', $data);
    }
	
	/**
     * Create a new kuesioner_field entry
     *
     * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'create_kuesioner_field')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_field('new')){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_field:submit_success'));				
				redirect('kuesioner/kuesioner_field/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_field:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'kuesioner/kuesioner_field/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_field:new'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:plural'), '/kuesioner/kuesioner_field/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:new'))
			->build('kuesioner_field_form', $data);
    }
	
	/**
     * Edit a kuesioner_field entry
     *
     * We're passing the
     * id of the entry, which will allow entry_form to
     * repopulate the data from the database.
	 * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @param   int [$id] The id of the kuesioner_field to the be deleted.
     * @return	void
     */
    public function edit($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_field') AND ! group_has_role('kuesioner', 'edit_own_kuesioner_field')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_field')){
			$entry = $this->kuesioner_field_m->get_kuesioner_field_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_field('edit', $id)){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_field:submit_success'));				
				redirect('kuesioner/kuesioner_field/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_field:submit_failure');
			}
		}
		
		$data['fields'] = $this->kuesioner_field_m->get_kuesioner_field_by_id($id);
		$data['mode'] = 'edit';
		$data['return'] = 'kuesioner/kuesioner_field/view/'.$id;
		$data['entry_id'] = $id;
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
        $this->template->title(lang('kuesioner:kuesioner_field:edit'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:plural'), '/kuesioner/kuesioner_field/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_field:view'), '/kuesioner/kuesioner_field/view/'.$id)
			->set_breadcrumb(lang('kuesioner:kuesioner_field:edit'))
			->build('kuesioner_field_form', $data);
    }
	
	/**
     * Delete a kuesioner_field entry
     * 
     * @param   int [$id] The id of kuesioner_field to be deleted
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_field') AND ! group_has_role('kuesioner', 'delete_own_kuesioner_field')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_field')){
			$entry = $this->kuesioner_field_m->get_kuesioner_field_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->kuesioner_field_m->delete_kuesioner_field_by_id($id);
		$this->session->set_flashdata('error', lang('kuesioner:kuesioner_field:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('kuesioner/kuesioner_field/index');
    }
	
	/**
     * Insert or update kuesioner_field entry in database
     *
     * @param   string [$method] The method of database update ('new' or 'edit').
	 * @param   int [$row_id] The entry id (if in edit mode).
     * @return	boolean
     */
	private function _update_kuesioner_field($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('field_name', lang('kuesioner:kuesioner_field:field_name'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->kuesioner_field_m->insert_kuesioner_field($values);
			}
			else
			{
				$result = $this->kuesioner_field_m->update_kuesioner_field($values, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}