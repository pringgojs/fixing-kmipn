<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Kuesioner_kuesioner
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Kuesioner_kuesioner extends Public_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner';
	
    public function __construct()
    {
        parent::__construct();

        // -------------------------------------
		// Load everything we need
		// -------------------------------------

		$this->lang->load('buttons');
        $this->lang->load('kuesioner');
		$this->load->model('kuesioner_m');
		$this->load->model('kuesioner_answer_m');
		$this->load->model('kuesioner_page_m');
		$this->load->model('kuesioner_section_m');
		$this->load->model('kuesioner_field_m');
    }

    /**
	 * Menampilkan semua kuesioner untuk alumni
     *
     * Fungsi ini akan menampilkan semua kuesioner yang status penginputannya belum selesai. Pada fungsi ini terdapat beberapa pengecekan :
     * 1. Mengecek user group
     * 2. Mengecek rules yang sidah ditentukan
     * 3. Mengecek status pengerjaan
     * Jika ada yang belum terpenuhi maka halaman akan di redirect ke function finish_page
	 *
     * Fungsi ini juga akan melakukan proses pengecekan jawaban dan melanjutkan proses pengecekan tersebut untuk di simpan ke database.
     * @return	void
     */
    public function index()
    {
    	$this->session->unset_userdata('error');
    	// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! is_logged_in()){
			redirect('admin/login');
		}
		
		$kuesioner_id = (int) $this->uri->segment(4);

		// Cek Kuesioner
		$data['error'] = false;
		if($kuesioner_id != ""){
			$kuesioner = $this->kuesioner_m->get_kuesioner_by_id($kuesioner_id);
			if(count($kuesioner) == 0){
				$data['error'] = true;
				$data['info'] = "Tidak ada data kuesioner";
			}else{
				$this->db->where('kuesioner_id',$kuesioner_id);
				$query = $this->db->get('default_kuesioner_kuesioner_field');
				$field = $query->num_rows();

				$this->db->where('kuesioner_id', $kuesioner_id);
				$data_page = $this->db->get('default_kuesioner_kuesioner_page');
				$jml_page = $data_page->num_rows();

				$this->db->where('kuesioner_id', $kuesioner_id);
				$this->db->group_by('page_id');
				$data_section = $this->db->get('default_kuesioner_kuesioner_field');
				$jml_page_on_field = $data_section->num_rows();

				$this->db->where('kuesioner_id', $kuesioner_id);
				$data_page = $this->db->get('default_kuesioner_kuesioner_section');
				$jml_section = $data_page->num_rows();

				$this->db->where('kuesioner_id', $kuesioner_id);
				$this->db->group_by('section_id');
				$data_section = $this->db->get('default_kuesioner_kuesioner_field');
				$jml_section_on_field = $data_section->num_rows();

				if($field == 0 || $jml_page_on_field < $jml_page || $jml_section_on_field < $jml_section){
					$data['error'] = true;
					$data['info'] = "Kuesioner belum selesai dibuat";
				}
			}
		}
		
		//get current user
		$id_user = $this->session->userdata('id');
		$group = $this->session->userdata('group');

		// only alumni can fill questionnaire
		if(strtolower($group) != 'alumni'){
			if((strtolower($group) == 'admin' || strtolower($group) == 'site_admin') && $kuesioner_id == ''){
				redirect(base_url(). 'kuesioner/kuesioner/admin_kuesioner_view');
			}elseif(strtolower($group) != 'alumni' && strtolower($group) != 'admin' && strtolower($group) != 'site_admin'){
				redirect(base_url(). 'kuesioner/kuesioner/no_kuesioner_available_page');
			}
		}


		if(!$data['error']){

		$count = 0;
		$added_notification = '';
		if($kuesioner_id == ''){
			$this->db->where('active_status', 1);
			$all_kuesioner = $this->db->get('kuesioner_kuesioner')->result();
			$kuesioner_filling_status = array();
			$kuesioner_filling_status['kuesioner'] = array();
			$kuesioner_filling_status['status'] = array();
			foreach ($all_kuesioner as $key => $value) {
				$responden = $this->kuesioner_m->get_responden($value);
				$peserta = array();
				foreach ($responden as $key => $res) {
					array_push($peserta, $res['id']);
				}
				if(in_array($this->session->userdata('id'), $peserta)){
					$this->db->where('kuesioner_id', $value->id);
					$this->db->where('user_id', $id_user);
					$res = $this->db->get('kuesioner_kuesioner_answer')->row_array();
					$kuesioner_id = $value->id;
					array_push($kuesioner_filling_status['kuesioner'], $value);
					array_push($kuesioner_filling_status['status'], $res['status']);
					$count++;
					// $this->db->where('kuesioner_id', $value->id);
					// $this->db->where('user_id', $id_user);
					// $res = $this->db->get('kuesioner_kuesioner_answer')->row_array();
					// if(count($res) == 0 || $res['status'] == 'ongoing'){
					// 	$kuesioner_id = $value->id;
					// 	break;
					// }
				}		
			}
		}
		if($count > 0){

			$data['kuesioner_filling_status'] = json_encode($kuesioner_filling_status);
			$this->template->title(lang('kuesioner:kuesioner:plural'))
				->set_breadcrumb('Home', '/')
				->set_breadcrumb(lang('kuesioner:kuesioner:plural'))
				->build('list_kuesioner', $data);
			//redirect(base_url(). 'kuesioner/kuesioner/finish_page_all');
		}else{
			if($kuesioner_id != 0){
				// if user hasn't finish input, redirect to kuesioner page
				$this->db->where('kuesioner_id', $kuesioner_id);
				$this->db->where('user_id', $id_user);
				$res = $this->db->get('kuesioner_kuesioner_answer')->row_array();
				if(count($res) != 0){
					$status = $res['status'];
					if($status == 'finish'){
						redirect(base_url(). 'kuesioner/kuesioner/finish_page');
					}
				}
				//get user
		        $this->db->where('id',$id_user);
		        $user = $this->db->get('users')->result();
		        foreach ($user as $us){
		            $username = $us->username;
		        }

				// variables
		        $index = 0;
				$jumlah = 0;
		        $page_flag = "";
				$data = array();
				$data['error'] = false;
				$is_answer_valid = NULL;
				// if POST exist
				if($_POST){
					// variables
					
					if(!is_null($this->input->post('hidden_answers'))){
						$answers = $this->input->post('hidden_answers');
					}else{
						$answers = '';
					}
					// dump($answers);

					$k_id = $this->input->post('kuesioner_id');
					$index = $this->input->post('page_index');
					//dump(json_decode($answers));exit;
					if($this->input->post('submit_next')){
						$page_flag = "next";

						// get page id by page index
						$this->db->select('pages');
						$this->db->where('id', $k_id);
						$result = $this->db->get('kuesioner_kuesioner')->result();
						$pages_info_json = $result[0]->pages;
						$pages_info = json_decode($pages_info_json);
						if(isset($pages_info->urutan[$index-1])){
							$page_id = $pages_info->urutan[$index-1];
						}else{
							$page_id = 0;
						}
						
						
						// get existing answer
						$this->db->where('kuesioner_id',$k_id);
						$this->db->where('user_id',$id_user);
						$temp_res = $this->db->get('kuesioner_kuesioner_answer')->result();

						// validate if error browser occur, if the submitted answer is null
						if($answers != null && $answers != ''){
							// answer is exist
							if($temp_res != null && !(is_array($temp_res) && count($temp_res) == 0)){
								// merge with existing answer
								$existing_answer = json_decode($temp_res[0]->answers);
								$new_answers = json_decode($answers);
								if(isset($new_answers->{'q_'.$k_id}->{'p_'.$page_id})){
									$existing_answer->{'q_'.$k_id}->{'p_'.$page_id} = $new_answers->{'q_'.$k_id}->{'p_'.$page_id};
								}
								$answers = json_encode($existing_answer);
							}

							// delete all entries for corresponding kuesioner id and user id
							$this->db->delete('kuesioner_kuesioner_answer', array(
								'kuesioner_id' => $k_id,
								'user_id' => $id_user,
							));
							
							// re-insert answer
							$this->db->set('kuesioner_id',$k_id);
							$this->db->set('user_id',$id_user);
							$this->db->set('answers',$answers);
							$this->db->set('status',"ongoing");
							$this->db->set('username',$username);
							if($temp_res == null){
								$this->db->set('created_on',date('Y-m-d H:i'));
								$this->db->set('created_by',$this->session->userdata('id'));
							}else{
								$this->db->set('created_on',$temp_res[0]->created_on);
								$this->db->set('created_by',$temp_res[0]->created_by);
							}
							$this->db->set('updated_on',date('Y-m-d H:i'));
							$this->db->set('updated_by',$this->session->userdata('id'));
							$this->db->insert('kuesioner_kuesioner_answer');
							
							// get current page's answers
							$answers = json_decode($answers, TRUE);
						}else{
							if($temp_res != null && !(is_array($temp_res) && count($temp_res) == 0)){
								$answers = $temp_res[0]->answers;
							}else{
								$answers = '';
							}
							$answers = json_decode($answers, TRUE);
							$added_notification = "<b>Terjadi error code 523 (Error Browser). Harap hubungi admin.<b>";
						}

						// dump($answers);


						
						// repopulate readonly field from database
						$this->db->where('kuesioner_id', $k_id);
						$this->db->where('type', 'readonly');
						$readonly_fields = $this->db->get('kuesioner_kuesioner_field')->result();
						
						foreach($readonly_fields as $readonly_field){
							if(isset($answers['q_'.$k_id]['p_'.$readonly_field->page_id]['s_'.$readonly_field->section_id]['id_'.$readonly_field->id_html])){
								$option = json_decode($readonly_field->options, TRUE);
								$field = $answers['q_'.$k_id]['p_'.$readonly_field->page_id]['s_'.$readonly_field->section_id]['id_'.$readonly_field->id_html];
								
								// get user field value
								$id_user = $this->session->userdata('id');
								$this->db->select('*');
								$this->db->from('users');
								$this->db->join('profiles','users.id = profiles.user_id');
								$this->db->where('users.id',$id_user);
								$user = $this->db->get()->row();
								$user_field = $option['user_field'][0];
								
								if($user_field != 'display_name'){
									//$field->answer[0] = $user->{$user_field};
									$answers['q_'.$k_id]['p_'.$readonly_field->page_id]['s_'.$readonly_field->section_id]['id_'.$readonly_field->id_html]['answer'][0] = $user->{$user_field};
								}else{
									//$field->answer[0] = $user->first_name.' '.$user->last_name;
									$answers['q_'.$k_id]['p_'.$readonly_field->page_id]['s_'.$readonly_field->section_id]['id_'.$readonly_field->id_html]['answer'][0] = $user->display_name;
								}
							}
						}

						// dump($answers);
						// die();
						// validate answers
						$validation = $this->_is_answer_valid($answers, $k_id, $page_id);
						//dump($validation);
						if($validation['status'] != 'OK'){
							// set is valid variable
							$is_answer_valid = false;

							// change back index
							$index--;
							
							// set flash data
							$data['validation_errors'] = implode("<br />", $validation['message']);
							if($added_notification != ''){
								$data['validation_errors'] = $data['validation_errors']."<br />".$added_notification;
							}
							
							// dump($data['validation_errors']);
						}else{
							// set is valid variable
							$is_answer_valid = true;
							$data['validation_errors'] = '';
						}

					}else if($this->input->post('submit_prev')){

						$page_flag="left";

					}else if($this->input->post('submit_finish')){
						// set status to finish

						$this->db->where('kuesioner_id',$k_id);
						$this->db->where('user_id',$id_user);
						$this->db->set('status',"finish");
						$this->db->set('updated_on',date('Y-m-d H:i'));
						$this->db->set('updated_by',$this->session->userdata('id'));
						$this->db->update('kuesioner_kuesioner_answer');

						// redirect to final page
						redirect(base_url(). 'kuesioner/kuesioner/finish_page');
					}
				}

				// get current kuesioner
				$this->db->where('id', $kuesioner_id);
		        $data["kuesioner"] = $this->db->get('kuesioner_kuesioner')->row();

				// get order of pages
				if(is_null($data["kuesioner"]->pages)) {
					redirect(base_url(). 'kuesioner/kuesioner/finish_page_all');
				}
				$dp = json_decode($data["kuesioner"]->pages);
				$pages_id = $dp->urutan;
				
				// get next page index
				$next_page_index = 0;
				if($index >= count($pages_id)){
					$next_page_index = -1;
				}elseif($index == -1){
					// return from confirmation page, so get last available page
					foreach($pages_id as $idx => $page_id){
						$is_show = $this->_is_show_conditional_logic($data["kuesioner"]->id, $page_id);
						if($is_show){
							$next_page_index = $idx;
						}
					}
				}else{
					foreach($pages_id as $idx => $page_id){
						// user hit "Lanjutkan"
						if($this->input->post('submit_next') AND $idx >= $index){
							$next_page_index = -1;
							if($is_answer_valid == true){
								$is_show = $this->_is_show_conditional_logic($data["kuesioner"]->id, $page_id);
								if($is_show){
									$next_page_index = $idx;
									break;
								}
							}else{
								$next_page_index = $index;
								break;
							}
						// user hit "Kembali"
						}elseif($this->input->post('submit_prev') AND $idx <= $index){
							$is_show = $this->_is_show_conditional_logic($data["kuesioner"]->id, $page_id);
							if($is_show){
								$next_page_index = $idx;
							}
						}
					}
				}

				// set index
				$index = $next_page_index;

				// get answer
				$this->db->where('kuesioner_id',$kuesioner_id);
				$this->db->where('user_id',$id_user);
				$this->db->select('answers');
				$data_answer = $this->db->get('kuesioner_kuesioner_answer')->row_array();

				if(count($data_answer) > 0) {
					// dump($data_answer);
					$data_answer = json_decode($data_answer['answers'], true);
					$last_page = '';
					foreach ($data_answer as $key => $q) {
						$temp_p = '';
						foreach ($q as $key => $p) {
							$last_page = $key;
							$last_page = explode('_', $last_page);
							$last_page = $last_page[1];
							$pages_id2[] = $last_page;
						}
					}

					// dump($last_page);
					// dump($pages_id);
					if(!$_POST){
						// dump($data_answer);
						$validation = $this->_is_answer_valid($data_answer, $kuesioner_id, $last_page, FALSE);
						// dump($validation);
						// die();
						foreach ($pages_id as $key => $page) {
							if($page == $last_page){
								$index = $key+1;
								$keyss = $key;
								break;
							}
						}
						if($validation['status'] != 'OK'){
							$index = $keyss;
						}else{
							// dump($index);

							foreach($pages_id as $idx => $page_id){
								// user hit "Lanjutkan"
								if($idx >= $index){
									$next_page_index = -1;
									$is_show = $this->_is_show_conditional_logic($data["kuesioner"]->id, $page_id);
									// dump($page_id);
									// dump($is_show);
									if($is_show){
										$next_page_index = $idx;
										break;
									}
								}
							}
							$index = $next_page_index;
						}
					}
					// dump($last_page);
				}
				// dump($pages_id[$index]);
				// die();

				// get next page
				 if($index != -1){
				//if(TRUE){
					$this->db->where('id', $pages_id[$index]);
					$this->db->where('kuesioner_id', $data["kuesioner"]->id);
					$data['page'] = $this->db->get('kuesioner_kuesioner_page')->row();
					// get sections in ordered fashion
					$section_ids = json_decode($data['page']->sections)->urutan;
					$data['page_sections'] = array();
					foreach($section_ids as $section_id){
						// get from database by section id
						$this->db->where('id', $section_id);
						$data['page_sections'][$section_id] = $this->db->get('kuesioner_kuesioner_section')->row();
					}

					// status quo
					$this->db->where('id', $kuesioner_id);
					$data["records"]=$this->db->get('kuesioner_kuesioner')->result();

					foreach($data["records"] as $dt){
						$kuesioner_id = $dt->id;
						$pages_order = json_decode($dt->pages, true);
						$jumlah = $pages_order["jumlah"][0];

						// get current page
						$this->db->where('id', $pages_order["urutan"][$index]);
						$this->db->where('kuesioner_id', $kuesioner_id);
						$data['pages'] = $this->db->get('kuesioner_kuesioner_page')->result();

						// get answer
						$this->db->where('kuesioner_id',$kuesioner_id);
						$this->db->where('user_id',$id_user);
						$this->db->select('answers');
						$data["answers"] = $this->db->get('kuesioner_kuesioner_answer')->result();

						$page_cl_value = false;

						// get page, answer, section, and fields data
						foreach ($data['pages'] as $pg){
							// get conditional logic rules
							$page_cl = json_decode($pg->conditional_logic, true);

							// if conditional logic rule is set
							if($page_cl != null){
								// get "any" or "all"
								$page_cl_any=$page_cl["any"][0];

								// iterate each rule
								for($m = 0; $m < count($page_cl["options"]); $m++){
									// get page, section, and field id
									list($p_id,$s_id,$id_h) = explode("_",$page_cl["options"][$m]);

									// get "is" or "is not"
									$isnot = $page_cl["isnot"][$m];

									// get all answer for current user
									foreach($data["answers"] as $ans){
										$ans_obj = json_decode($ans->answers, true);
									}

									// check if user has answer
									if($ans_obj != null){
										// iterate all the user answer for a question
										for($n = 0; $n < count($ans_obj["q_".$kuesioner_id]["p_".$p_id]["s_".$s_id]["id_".$id_h]["answer"]); $n++){

											// get actual answer by user
											$act_answer = $ans_obj["q_".$kuesioner_id]["p_".$p_id]["s_".$s_id]["id_".$id_h]["answer"][$n];

											// if the rule is "any"
											if($page_cl_any == "any"){
												if($isnot == "is"){
													if($page_cl["value"][$m] == $act_answer){
														$page_cl_value = true;
													}
												}else if($isnot == "not"){
													if($page_cl["value"][$m] != $act_answer){
														$page_cl_value = true;
													}
												}
											}else if($page_cl_any == "all"){
												$page_cl_value = true;
												if($isnot == "is"){
													if($page_cl["value"][$m] != $act_answer){
														$page_cl_value = false;
													}
												}else if($isnot == "not"){
													if($page_cl["value"][$m] == $act_answer){
														$page_cl_value = false;
													}
												}
											}
										}
									}else if($ans_obj==null){
										$page_sections = json_decode($pg->sections,true);
										$data['sections']=array();
										for($j=0;$j<$page_sections["jumlah"][0];$j++){
											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('id',$page_sections["urutan"][$j]);
											$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
											array_push($data['sections'],$tmp);
										}

										$data['fields']=array();
										for($k=0;$k<count($data['sections']);$k++){
										$data['fields'][$k]=array();
										foreach($data['sections'][$k] as $sect){
											$urutan = json_decode($sect->fields,true);
											$id_section = $sect->id;
										}

											for($i=0;$i<$urutan["jumlah"][0];$i++){
												$this->db->where('section_id',$id_section);
												$this->db->where('id_html',$urutan["urutan"][$i]);
												$temp=$this->db->get('kuesioner_kuesioner_field')->result();
												array_push($data['fields'][$k],$temp);
											}
										}
									}
								}
								if($page_cl_value==true){
									if($page_cl["show"][0]=="show"){
										$page_sections = json_decode($pg->sections,true);
										//var_dump($page_sections);
										$data['sections']=array();
										for($j=0;$j<$page_sections["jumlah"][0];$j++){
											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('id',$page_sections["urutan"][$j]);
											$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
											array_push($data['sections'],$tmp);
										}

										$data['fields']=array();
										for($k=0;$k<count($data['sections']);$k++){
											$data['fields'][$k]=array();
											foreach($data['sections'][$k] as $sect){
												$urutan = json_decode($sect->fields,true);
												$id_section = $sect->id;
											}

											for($i=0;$i<$urutan["jumlah"][0];$i++){
												$this->db->where('section_id',$id_section);
												$this->db->where('id_html',$urutan["urutan"][$i]);
												$temp=$this->db->get('kuesioner_kuesioner_field')->result();
												array_push($data['fields'][$k],$temp);
											}
										}
									}else if($page_cl["show"]=="hide"){
										if($page_flag=="next"){
											$index+=1;
										}elseif($page_flag == "prev"){
											$index-=1;
										}
										if($index==$jumlah){
											$array_object = array();
											$object->id = 0;
											$object->kuesioner_id = 0;
											$object->title = "Finish!";
											$object->deskripsi = "Terima kasih atas kerjasamanya...";
											array_push($array_object,$object);
											$data['pages']=$array_object;
										}else{
											$this->db->where('id',$pages_order["urutan"][$index]);
											$this->db->where('kuesioner_id',$kuesioner_id);
											$data['pages']=$this->db->get('kuesioner_kuesioner_page')->result();

											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('user_id',$id_user);
											$this->db->select('answers');
											$data["answers"]=$this->db->get('kuesioner_kuesioner_answer')->result();

											$page_sections = json_decode($pg->sections,true);
										//var_dump($page_sections);
											$data['sections']=array();
											for($j=0;$j<$page_sections["jumlah"][0];$j++){
												$this->db->where('kuesioner_id',$kuesioner_id);
												$this->db->where('id',$page_sections["urutan"][$j]);
												$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
												array_push($data['sections'],$tmp);
											}

											$data['fields']=array();
											for($k=0;$k<count($data['sections']);$k++){
												$data['fields'][$k]=array();
												foreach($data['sections'][$k] as $sect){
													$urutan = json_decode($sect->fields,true);
													$id_section = $sect->id;
												}

												for($i=0;$i<$urutan["jumlah"][0];$i++){
													$this->db->where('section_id',$id_section);
													$this->db->where('id_html',$urutan["urutan"][$i]);
													$temp=$this->db->get('kuesioner_kuesioner_field')->result();
													array_push($data['fields'][$k],$temp);
												}
											}
										}
									}
								}else if($page_cl_value==false){
									if($page_cl["show"][0]=="hide"){
										$page_sections = json_decode($pg->sections,true);
										$data['sections']=array();
										for($j=0;$j<$page_sections["jumlah"][0];$j++){
											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('id',$page_sections["urutan"][$j]);
											$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
											array_push($data['sections'],$tmp);
										}

										$data['fields']=array();
										for($k=0;$k<count($data['sections']);$k++){
										$data['fields'][$k]=array();
										foreach($data['sections'][$k] as $sect){
											$urutan = json_decode($sect->fields,true);
											$id_section = $sect->id;
										}

											for($i=0;$i<$urutan["jumlah"][0];$i++){
												$this->db->where('section_id',$id_section);
												$this->db->where('id_html',$urutan["urutan"][$i]);
												$temp=$this->db->get('kuesioner_kuesioner_field')->result();
												array_push($data['fields'][$k],$temp);
											}
										}
									}else if($page_cl["show"][0]=="show"){
										if($page_flag=="next"){
											$index+=1;
										}elseif($page_flag == "prev"){
											$index-=1;
										}
										if($index==$jumlah){
											$array_object = array();
											$object->id = 0;
											$object->kuesioner_id = 0;
											$object->title = "Finish!";
											$object->deskripsi = "Terima kasih atas kerjasamanya...";
											array_push($array_object,$object);
											$data['pages']=$array_object;
										}else{
											$this->db->where('id',$pages_order["urutan"][$index]);
											$this->db->where('kuesioner_id',$kuesioner_id);
											$data['pages']=$this->db->get('kuesioner_kuesioner_page')->result();

											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('user_id',$id_user);
											$this->db->select('answers');
											$data["answers"]=$this->db->get('kuesioner_kuesioner_answer')->result();

											$page_sections = json_decode($pg->sections,true);

											$data['sections']=array();
											for($j=0;$j<$page_sections["jumlah"][0];$j++){
												$this->db->where('kuesioner_id',$kuesioner_id);
												$this->db->where('id',$page_sections["urutan"][$j]);
												$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
												array_push($data['sections'],$tmp);
											}

											$data['fields']=array();
											for($k=0;$k<count($data['sections']);$k++){
												$data['fields'][$k]=array();
												foreach($data['sections'][$k] as $sect){
													$urutan = json_decode($sect->fields,true);
													$id_section = $sect->id;
												}

												for($i=0;$i<$urutan["jumlah"][0];$i++){
													$this->db->where('section_id',$id_section);
													$this->db->where('id_html',$urutan["urutan"][$i]);
													$temp=$this->db->get('kuesioner_kuesioner_field')->result();
													array_push($data['fields'][$k],$temp);
												}
											}
										}
									}
								}

							// no conditional logic rule
							}else{
								// get sections
								$page_sections = json_decode($pg->sections,true);
								$data['sections'] = array();
								for($j=0;$j<$page_sections["jumlah"][0];$j++){
									$this->db->where('kuesioner_id',$kuesioner_id);
									$this->db->where('id',$page_sections["urutan"][$j]);
									$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
									array_push($data['sections'],$tmp);
								}

								// get fields
								$data['fields']=array();
								for($k=0;$k<count($data['sections']);$k++){
									$data['fields'][$k] = array();

									foreach($data['sections'][$k] as $sect){
										$urutan = json_decode($sect->fields,true);
										$id_section = $sect->id;
									}

									for($i=0;$i<$urutan["jumlah"][0];$i++){
										$this->db->where('section_id',$id_section);
										$this->db->where('id_html',$urutan["urutan"][$i]);
										$temp=$this->db->get('kuesioner_kuesioner_field')->result();
										array_push($data['fields'][$k],$temp);
									}
								}
							}
						}
					}
					// end: foreach($data["records"] as $dt)
				}else{
					// Finished the kuesioner
					//dump($index);exit();
				}

				// set current index
				// dump($index);
				// die();
		        $data["index"] = $index;

				// set buttons & render page
		        if($index == 0){
		            $data["submit_flag"] = "next";
		        }else if($index >= $jumlah-1){
		            $data["submit_flag"] = "prev";
		        }else{
		            $data["submit_flag"] = "both";
		        }

		        if($this->input->post('submit_prev')){
		     		$this->session->unset_userdata('status');
		        	$status = 'prev';
		        }elseif($this->input->post('submit_next')){
		        	$status = 'next';
		        }else{
		        	$status = 'first';
		        }
		    }else{
		    	redirect(base_url(). 'kuesioner/kuesioner/finish_page_all');
		    }
		    if(isset($data['page']->title)){
		    	$this->session->set_userdata('page_title', $data['page']->title);
		    }
		    $data['style'] = $this->kuesioner_m->get_style($kuesioner_id);
			$this->template->title(lang('kuesioner:kuesioner:plural'))
				->set('status',$status)
				->set('page_title','test')
				->set_breadcrumb('Home', '/')
				->set_breadcrumb(lang('kuesioner:kuesioner:plural'))
				->build('kuesioner_index', $data);
		}

		}else{
			$this->template->title(lang('kuesioner:kuesioner:plural'))
				->set('page_title','test')
				->set_breadcrumb('Home', '/')
				->set_breadcrumb(lang('kuesioner:kuesioner:plural'))
				->build('kuesioner_index', $data);
		}
		

		// -------------------------------------
		// Build the page. 
		// -------------------------------------
		
   //      $this->template->title(lang('kuesioner:kuesioner:plural'))
			// ->set_breadcrumb('Home', '/')
			// ->set_breadcrumb(lang('kuesioner:kuesioner:plural'))
			// ->build('kuesioner_index', $data);
    }

    /**
	 * Mengecek jawaban kuesioner
     *
     * Fungsi ini akan mengecek ketentuan pengisian dari setiap field jawaban
     * @param  array $answers jawaban
     * @param  int $kuesioner_id id kuesioner
     * @param  int $page_id id halaman kuesioner
     * @return	array
     */
	private function _is_answer_valid($answers, $kuesioner_id, $page_id, $set_session = TRUE)
	{
		// dump($kuesioner_id);
		// dump($page_id);
		// dump($set_session);
		// init retval
		$retval = array(
			'status' => 'OK',
			'message' => array(),
		);
		
		// dump($answers);
		// foreach questionnaire
		foreach($answers as $q_id => $q_answers){
			//foreach page
			foreach($q_answers as $p_id => $p_answers){
				//foreach section
				if($p_answers != NULL AND is_array($p_answers)){
				
				foreach($p_answers as $s_id => $s_answers){
					//foreach field
					foreach($s_answers as $f_id => $answer_object){
						$section_id = explode("_", $s_id); $section_id = $section_id[1];
						$field_html_id = explode("_", $f_id); $field_html_id = $field_html_id[1];

						// get field row from database
						$this->db->from('kuesioner_kuesioner_field');
						$this->db->where(array(
							'id_html' => $field_html_id,
							'kuesioner_id' => $kuesioner_id,
							'page_id' => $page_id,
							'section_id' => $section_id,
						));
						$result = $this->db->get()->result();
						
						if($result != null){
							$field = $result[0];
						
							// get the question from answer object
							$question = $answer_object['question'][0];
							
							// check if the answer is filled
							$is_filled = $this->_is_answer_filled($field, $answer_object);
							
							// check required is valid
							$field_opt = json_decode($result[0]->options);
							if($field_opt->required[0] == "true"){
								if($is_filled == false){
									$retval['status'] = 'ERROR';
									if($set_session){
										$retval['message'][] = 'Pertanyaan "'. $question .'" wajib diisi.';
										$this->session->set_userdata('error', 'exist');
									}
								}
							}
							
							// check valid by field type
							if($field->type == 'number'){
								$answer = (int)$answer_object['answer'][0];
								if($is_filled AND !is_numeric($answer)){
									$retval['status'] = 'ERROR';
									if($set_session){
										$retval['message'][] = 'Jawaban pertanyaan "'. $question .'" harus berupa angka.';
										$this->session->set_userdata('error', 'exist');
									}
								}elseif($is_filled AND $answer == 0){
									$retval['status'] = 'ERROR';
									if($set_session){
										$retval['message'][] = 'Jawaban pertanyaan "'. $question .'" tidak boleh nol.';
										$this->session->set_userdata('error', 'exist');
									}
								}
							}
						}
					}
				}
				
				}
			}
		}
		
		return $retval;
	}

	/**
	 * Mengecek jawaban, apakah diisi atau tidak
     *
     * Fungsi ini akan mengecek jawaban responden, apakah diisi atau tidak, jika tidak diisi maka nilai yang dikembalikan adalah FALSE, jika diisi maka nilainya TRUE
     * @param  obj $field field
     * @param  array $answer jawaban
     * @return	boolean
     */
	private function _is_answer_filled($field, $answer)
	{
		$question_arr = $answer['question'];
		$answer_arr = $answer['answer'];
		
		if(count($answer_arr) == 0 || $answer_arr['0'] == ''){
			return FALSE;
		}

		if($field->type == 'grid' AND count($answer_arr) != (count($question_arr) - 1)){
			return FALSE;
		}

		foreach($answer_arr as $answer){
			if($answer == NULL OR $answer == ''){
				return FALSE;
			}
		}

		return TRUE;
	}

	/**
	 * Mengecek conditional logic
	 *
     * Fungsi ini akan mengecek conditional logic yang telah ditentukan dari kuesioner tertentu, jika sesuai maka nilainya TRUE jika tidak maka nilainya FALSE
     * @param  int $kuesioner_id id kuesioner
     * @param  int $page_id id halaman kuesioner
     * @return	boolean
     */
	private function _is_show_conditional_logic($kuesioner_id, $page_id)
	{
		// get current page
		$this->db->where('id', $page_id);
		$this->db->where('kuesioner_id', $kuesioner_id);
		$page_cl_json = $this->db->get('kuesioner_kuesioner_page')->row()->conditional_logic;
		$page_cl = json_decode($page_cl_json, true);

		// check if this page has conditional logic
		if($page_cl == NULL){
			return TRUE;
		}

		// get all answer for current user
		$id_user = $this->session->userdata('id');
		$this->db->where('kuesioner_id',$kuesioner_id);
		$this->db->where('user_id',$id_user);
		$this->db->select('answers');
		$user_answers_json = $this->db->get('kuesioner_kuesioner_answer')->row('answers');

		// check if user has answer
		if(is_array($user_answers_json) AND count($user_answers_json) == 0){
			return false;
		}else{
			$ans_obj = json_decode($user_answers_json, true);
		}
		
		// get "any" or "all"
		$page_cl_any = $page_cl["any"][0];

		// get "show" or "hide"
		$page_cl_show = $page_cl["show"][0];

		// iterate each rule
		$rules_retval = array();
		for($m = 0; $m < count($page_cl["options"]); $m++){

			// get page, section, and field id
			list($p_id, $s_id, $id_h) = explode("_", $page_cl["options"][$m]);

			// get "is" or "is not"
			$isnot = $page_cl["isnot"][$m];
			
			// iterate all the user answer for a question
			$rule_retval = false;
			for($n = 0; $n < count($ans_obj["q_".$kuesioner_id]["p_".$p_id]["s_".$s_id]["id_".$id_h]["answer"]); $n++){

				// get actual answer by user
				$act_answer = $ans_obj["q_".$kuesioner_id]["p_".$p_id]["s_".$s_id]["id_".$id_h]["answer"][$n];

				if($isnot == "is"){
					if($page_cl["value"][$m] == $act_answer){
						$rule_retval = true;
					}
				}else if($isnot == "not"){
					if($page_cl["value"][$m] != $act_answer){
						$rule_retval = true;
					}
				}
			}

			$rules_retval[] = $rule_retval;
		}

		// conclue final retval
		if($page_cl_any == 'any'){
			$retval = false;
			foreach($rules_retval as $rule_retval){
				if($rule_retval == true){
					$retval = true;
				}
			}
		}elseif($page_cl_any == 'all'){
			$retval = true;
			foreach($rules_retval as $rule_retval){
				if($rule_retval == false){
					$retval = false;
				}
			}
		}

		// show or hide?
		if($page_cl_show == 'show'){
			if($retval == true){
				return TRUE;
			}else{
				return FALSE;
			}
		}else{
			if($retval == true){
				return FALSE;
			}else{
				return TRUE;
			}
		}
	}
	
	/**
	 * Menampilkan halaman no kuesioner available page
	 *
     * @return	void
     */
	public function no_kuesioner_available_page(){
		// get current user
		$id_user = $this->session->userdata('id');

		$this->db->select('*');
		$this->db->from('users');
		$this->db->join('profiles','users.id = profiles.user_id');
		$this->db->where('users.id',$id_user);
		$user = $this->db->get()->row_array();
		// get role name

		$this->db->where('id',$user['group_id']);
		$role = $this->db->get('default_groups')->row('description');
		$data = array();
		$data['users'] = $user['display_name'];
		$data['role'] = $role;

		$this->template->title('Tidak tersedia kuesioner')
			->build('no_kuesioner_available_page', $data);
	}
   	
   	/**
	 * Menampilkan halaman finish page
	 *
     * @return	void
     */     
	public function finish_page(){
		//$this->auth->restrict();

		// get current user
		$id_user = $this->session->userdata('id');
		$this->db->where('id',$id_user);
		$user = $this->db->get('users')->row();

		// get current kuesioner
		$this->db->where('active_status', 1);
		$kuesioner = $this->db->get('kuesioner_kuesioner')->row();

		// if user hasn't finish input, redirect to kuesioner page
		// $this->db->where('kuesioner_id', $kuesioner->id);
		// $this->db->where('user_id', $user->id);
		// $status = $this->db->get('kuesioner_kuesioner_answer')->row('status');
		// if($status != 'finish'){
		// 	redirect(base_url(). 'kuesioner');
		// }

		$data = array();
		$data['users'] = $user;

		$this->template->title('Terima Kasih')
			->set('data',$data)
			->build('finish_page');
	}

	/**
	 * Menampilkan halaman finish all page
	 *
     * @return	void
     */ 
	public function finish_page_all(){
		// get current user
		$id_user = $this->session->userdata('id');
		$this->db->where('id',$id_user);
		$user = $this->db->get('users')->row();

		$data = array();
		$data['users'] = $user;
		$this->template->title('Terima Kasih')
			->set('data',$data)
			->build('finish_page');
	}

	/**
	 * Menampilkan menampilkan halaman list kuesioner (admin)
	 *
     * @return	void
     */ 
	public function admin_kuesioner_view(){
		$data['kuesioner'] = $this->kuesioner_m->get_kuesioner();

		$this->template->title(lang('kuesioner:kuesioner:plural'))
		->set_breadcrumb('Home', '/')
		->set_breadcrumb(lang('kuesioner:kuesioner:plural'))
		->build('list_kuesioner', $data);
	}

	/**
	 * Menampilkan menampilkan detail kuesioner (admin)
	 *
	 * @param int $id id kuesioner
     * @return	void
     */ 
	public function admin_view($id = 0)
    {
    	if($this->input->get()){
    		$index = $this->input->get('index_page');
    	}else{
    		$index = 0;
    	}

        // -------------------------------------
		// Check permission
		// -------------------------------------
		$data = array();
		if(! group_has_role('kuesioner', 'view_all_kuesioner') AND ! group_has_role('kuesioner', 'view_own_kuesioner')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		$data['page_select'] = array();
		$kuesioner = $this->kuesioner_m->get_kuesioner_by_id($id);

		// Cek Kuesioner
		$data['error'] = false;
		if($id != ""){
			if(count($kuesioner) == 0){
				$data['error'] = true;
				$data['info'] = "Tidak ada data kuesioner";
			}else{
				$this->db->where('kuesioner_id',$id);
				$query = $this->db->get('default_kuesioner_kuesioner_field');
				$field = $query->num_rows();

				$this->db->where('kuesioner_id', $id);
				$data_page = $this->db->get('default_kuesioner_kuesioner_page');
				$jml_page = $data_page->num_rows();

				$this->db->where('kuesioner_id', $id);
				$this->db->group_by('page_id');
				$data_section = $this->db->get('default_kuesioner_kuesioner_field');
				$jml_page_on_field = $data_section->num_rows();

				$this->db->where('kuesioner_id', $id);
				$data_page = $this->db->get('default_kuesioner_kuesioner_section');
				$jml_section = $data_page->num_rows();

				$this->db->where('kuesioner_id', $id);
				$this->db->group_by('section_id');
				$data_section = $this->db->get('default_kuesioner_kuesioner_field');
				$jml_section_on_field = $data_section->num_rows();


				if($field == 0 || $jml_page_on_field < $jml_page || $jml_section_on_field < $jml_section){
					$data['error'] = true;
					$data['info'] = "Kuesioner belum selesai dibuat";
				}
			}
		}

		if(!$data['error']){


		if($kuesioner['pages'] != ''){
			$page_obj = json_decode($kuesioner['pages']);
			if(isset($page_obj->urutan) && is_array($page_obj->urutan)){
				$urutan = $page_obj->urutan;
				foreach ($urutan as $key => $value) {
					array_push($data['page_select'], $this->kuesioner_page_m->get_kuesioner_page_by_id($value));
				}
			}
		}
		$pages_id = $page_obj->urutan;

		$data['kuesioner'] = $kuesioner;
	
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'view_all_kuesioner')){
			if($data['kuesioner']->created_by != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		$kuesioner_id = $id;
		if($kuesioner_id != 0){
			$jumlah = 0;
			$is_answer_valid = true;
			
			if($index != -1){
			//if(TRUE){
				$this->db->where('id', $pages_id[$index]);
				$this->db->where('kuesioner_id', $data["kuesioner"]['id']);
				$data['page'] = $this->db->get('kuesioner_kuesioner_page')->row();
				// get sections in ordered fashion
				$section_ids = json_decode($data['page']->sections)->urutan;
				$data['page_sections'] = array();
				foreach($section_ids as $section_id){
					// get from database by section id
					$this->db->where('id', $section_id);
					$data['page_sections'][$section_id] = $this->db->get('kuesioner_kuesioner_section')->row();
				}

				// status quo
				$this->db->where('id', $kuesioner_id);
				$data["records"]=$this->db->get('kuesioner_kuesioner')->result();

				foreach($data["records"] as $dt){
					$kuesioner_id = $dt->id;
					$pages_order = json_decode($dt->pages, true);
					$jumlah = $pages_order["jumlah"][0];

					// get current page
					$this->db->where('id', $pages_order["urutan"][$index]);
					$this->db->where('kuesioner_id', $kuesioner_id);
					$data['pages'] = $this->db->get('kuesioner_kuesioner_page')->result();

					// get answer
					$this->db->where('kuesioner_id',$kuesioner_id);
					$this->db->where('user_id',$this->session->userdata('id'));
					$this->db->select('answers');
					$data["answers"] = $this->db->get('kuesioner_kuesioner_answer')->result();

					//$data["answers"] = null;
					$page_cl_value = false;

					// get page, answer, section, and fields data
					foreach ($data['pages'] as $pg){
						// get conditional logic rules
						$page_cl = json_decode($pg->conditional_logic, true);

						// if conditional logic rule is set
						if($page_cl != null){
							// get "any" or "all"
							$page_cl_any=$page_cl["any"][0];

							// iterate each rule
							for($m = 0; $m < count($page_cl["options"]); $m++){
								// get page, section, and field id
								list($p_id,$s_id,$id_h) = explode("_",$page_cl["options"][$m]);

								// get "is" or "is not"
								$isnot = $page_cl["isnot"][$m];

								// get all answer for current user
								foreach($data["answers"] as $ans){
									$ans_obj = json_decode($ans->answers, true);
								}

								// check if user has answer
								if(!isset($ans_obj) || $ans_obj==null){
									$page_sections = json_decode($pg->sections,true);
									$data['sections']=array();
									for($j=0;$j<$page_sections["jumlah"][0];$j++){
										$this->db->where('kuesioner_id',$kuesioner_id);
										$this->db->where('id',$page_sections["urutan"][$j]);
										$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
										array_push($data['sections'],$tmp);
									}

									$data['fields']=array();
									for($k=0;$k<count($data['sections']);$k++){
									$data['fields'][$k]=array();
									foreach($data['sections'][$k] as $sect){
										$urutan = json_decode($sect->fields,true);
										$id_section = $sect->id;
									}

										for($i=0;$i<$urutan["jumlah"][0];$i++){
											$this->db->where('section_id',$id_section);
											$this->db->where('id_html',$urutan["urutan"][$i]);
											$temp=$this->db->get('kuesioner_kuesioner_field')->result();
											array_push($data['fields'][$k],$temp);
										}
									}
								}
							}
							if($page_cl_value==true){
								if($page_cl["show"][0]=="show"){
									$page_sections = json_decode($pg->sections,true);
									$data['sections']=array();
									for($j=0;$j<$page_sections["jumlah"][0];$j++){
										$this->db->where('kuesioner_id',$kuesioner_id);
										$this->db->where('id',$page_sections["urutan"][$j]);
										$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
										array_push($data['sections'],$tmp);
									}

									$data['fields']=array();
									for($k=0;$k<count($data['sections']);$k++){
										$data['fields'][$k]=array();
										foreach($data['sections'][$k] as $sect){
											$urutan = json_decode($sect->fields,true);
											$id_section = $sect->id;
										}

										for($i=0;$i<$urutan["jumlah"][0];$i++){
											$this->db->where('section_id',$id_section);
											$this->db->where('id_html',$urutan["urutan"][$i]);
											$temp=$this->db->get('kuesioner_kuesioner_field')->result();
											array_push($data['fields'][$k],$temp);
										}
									}
								}else if($page_cl["show"]=="hide"){
										$this->db->where('id',$pages_order["urutan"][$index]);
										$this->db->where('kuesioner_id',$kuesioner_id);
										$data['pages']=$this->db->get('kuesioner_kuesioner_page')->result();

										$this->db->where('kuesioner_id',$kuesioner_id);
										$this->db->where('user_id',$id_user);
										$this->db->select('answers');
										$data["answers"]=$this->db->get('kuesioner_kuesioner_answer')->result();

										$page_sections = json_decode($pg->sections,true);
									//var_dump($page_sections);
										$data['sections']=array();
										for($j=0;$j<$page_sections["jumlah"][0];$j++){
											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('id',$page_sections["urutan"][$j]);
											$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
											array_push($data['sections'],$tmp);
										}

										$data['fields']=array();
										for($k=0;$k<count($data['sections']);$k++){
											$data['fields'][$k]=array();
											foreach($data['sections'][$k] as $sect){
												$urutan = json_decode($sect->fields,true);
												$id_section = $sect->id;
											}

											for($i=0;$i<$urutan["jumlah"][0];$i++){
												$this->db->where('section_id',$id_section);
												$this->db->where('id_html',$urutan["urutan"][$i]);
												$temp=$this->db->get('kuesioner_kuesioner_field')->result();
												array_push($data['fields'][$k],$temp);
											}
										}
								// 	}
								}
							}else if($page_cl_value==false){
								if($page_cl["show"][0]=="hide"){
									$page_sections = json_decode($pg->sections,true);
									$data['sections']=array();
									for($j=0;$j<$page_sections["jumlah"][0];$j++){
										$this->db->where('kuesioner_id',$kuesioner_id);
										$this->db->where('id',$page_sections["urutan"][$j]);
										$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
										array_push($data['sections'],$tmp);
									}

									$data['fields']=array();
									for($k=0;$k<count($data['sections']);$k++){
									$data['fields'][$k]=array();
									foreach($data['sections'][$k] as $sect){
										$urutan = json_decode($sect->fields,true);
										$id_section = $sect->id;
									}

										for($i=0;$i<$urutan["jumlah"][0];$i++){
											$this->db->where('section_id',$id_section);
											$this->db->where('id_html',$urutan["urutan"][$i]);
											$temp=$this->db->get('kuesioner_kuesioner_field')->result();
											array_push($data['fields'][$k],$temp);
										}
									}
								}else if($page_cl["show"][0]=="show"){
										$this->db->where('id',$pages_order["urutan"][$index]);
										$this->db->where('kuesioner_id',$kuesioner_id);
										$data['pages']=$this->db->get('kuesioner_kuesioner_page')->result();

										$this->db->where('kuesioner_id',$kuesioner_id);
										$this->db->where('user_id',$this->session->userdata('id'));
										$this->db->select('answers');
										$data["answers"]=$this->db->get('kuesioner_kuesioner_answer')->result();

										$page_sections = json_decode($pg->sections,true);

										$data['sections']=array();
										for($j=0;$j<$page_sections["jumlah"][0];$j++){
											$this->db->where('kuesioner_id',$kuesioner_id);
											$this->db->where('id',$page_sections["urutan"][$j]);
											$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
											array_push($data['sections'],$tmp);
										}

										$data['fields']=array();
										for($k=0;$k<count($data['sections']);$k++){
											$data['fields'][$k]=array();
											foreach($data['sections'][$k] as $sect){
												$urutan = json_decode($sect->fields,true);
												$id_section = $sect->id;
											}

											for($i=0;$i<$urutan["jumlah"][0];$i++){
												$this->db->where('section_id',$id_section);
												$this->db->where('id_html',$urutan["urutan"][$i]);
												$temp=$this->db->get('kuesioner_kuesioner_field')->result();
												array_push($data['fields'][$k],$temp);
											}
										}
									}
								// }
							}

						// no conditional logic rule
						}else{
							// get sections
							$page_sections = json_decode($pg->sections,true);
							$data['sections'] = array();
							for($j=0;$j<$page_sections["jumlah"][0];$j++){
								$this->db->where('kuesioner_id',$kuesioner_id);
								$this->db->where('id',$page_sections["urutan"][$j]);
								$tmp = $this->db->get('kuesioner_kuesioner_section')->result();
								array_push($data['sections'],$tmp);
							}

							// get fields
							$data['fields']=array();
							for($k=0;$k<count($data['sections']);$k++){
								$data['fields'][$k] = array();

								foreach($data['sections'][$k] as $sect){
									$urutan = json_decode($sect->fields,true);
									$id_section = $sect->id;
								}

								for($i=0;$i<$urutan["jumlah"][0];$i++){
									$this->db->where('section_id',$id_section);
									$this->db->where('id_html',$urutan["urutan"][$i]);
									$temp=$this->db->get('kuesioner_kuesioner_field')->result();
									array_push($data['fields'][$k],$temp);
								}
							}
						}
					}
				}
				// end: foreach($data["records"] as $dt)
			}

			// set current index
	        $data["index"] = $index;
	    }

	    $data['style'] = $this->kuesioner_m->get_style($kuesioner_id);
		
		}


		// -------------------------------------
        // Build the page. See views/admin/index.php
        // for the view code.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner:view'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:plural'), '/admin/kuesioner/kuesioner/index')
			->set_breadcrumb(lang('kuesioner:kuesioner:view'))
			->build('kuesioner_entry', $data);
    }

	// --------------------------------------------------------------------------

}