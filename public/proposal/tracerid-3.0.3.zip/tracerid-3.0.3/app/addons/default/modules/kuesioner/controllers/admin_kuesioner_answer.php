<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Admin_kuesioner_answer
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Admin_kuesioner_answer extends Admin_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner_answer';

    public function __construct()
    {
        parent::__construct();

		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'access_kuesioner_answer_backend')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		$this->load->helper('MY_csv_helper');
        $this->lang->load('kuesioner');		
		$this->load->model('kuesioner_m');
		$this->load->model('kuesioner_page_m');
		$this->load->model('kuesioner_section_m');
		$this->load->model('kuesioner_field_m');
		$this->load->model('kuesioner_answer_m');
		$this->load->model('Organization/units_m');
    }

    /**
	 * Menampilkan jawaban kuesioner
     *
     * Fungsi ini akan menampilkan daftar isian kuesioner dari semua responden
     * @return	void
     */
    public function index()
    {	
    	$GLOBALS['page_status'] = 'empty';
    	ini_set('memory_limit', '2048M');
    	ini_set('maximum_execution_time', 3600);
		// -------------------------------------
		// Check permission
		// -------------------------------------
		$id_kuesioner = (int) $this->uri->segment(5);
		$kuesioner = $this->kuesioner_m->get_kuesioner_by_id($id_kuesioner);
		$title = $kuesioner['title'];

		$allow_status = $this->kuesioner_m->cek_allow();
		if($allow_status == false){
			if(! group_has_role('kuesioner', 'view_all_kuesioner_answer') AND ! group_has_role('kuesioner', 'view_own_kuesioner_answer')){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Pagination
		// -------------------------------------
		$pagination_config['id_kuesioner'] = $id_kuesioner;
		$pagination_config['base_url'] = base_url(). 'admin/kuesioner/kuesioner_answer/index/'.$id_kuesioner.'/';
		$pagination_config['suffix'] = '?' . $_SERVER["QUERY_STRING"];
		$pagination_config['uri_segment'] = 6;		


		// User Supervision Check
		$supervision = $this->kuesioner_m->cek_supervision();
		$add = '';
		if($supervision != ''){
			$pagination_config['additional'] = '';
			$sa = json_decode($supervision);
			$sa_options = $sa->options;
			$sa_isnot = $sa->isnot;
			$sa_value = $sa->value;
			$i = 0;
			if(is_array($sa_options) && is_array($sa_value)){
				foreach ($sa_options as $key => $value) {
					if($sa_options[$i] != '' && $sa_value[$i] != '' && array_key_exists($i, $sa_value) && array_key_exists($i, $sa_options)){
						if($i > 0){
							$pagination_config['additional'] .= " AND ";
						}
						if($sa_isnot[$i] == 'is'){
							$pagination_config['additional'] .= $sa_options[$i]." = '".$sa_value[$i]."'";
						}else{
							$pagination_config['additional'] .= $sa_options[$i]." != '".$sa_value[$i]."'";
						}
					}
					$i++;
				}
			}
			$add = $pagination_config['additional'];
		}

		// Kuesioner Rule Check
		if($kuesioner['conditional_logic'] != ''){
			$temp = json_decode($kuesioner['conditional_logic']);
			$pagination_config['rules'] = '';
			if(isset($temp->options) && isset($temp->options)){
				$temp_options = $temp->options;
				$temp_isnot = $temp->isnot;
				$temp_value = $temp->value;
				if(is_array($temp_options) && is_array($temp_value)){
					$i = 0;
					foreach ($temp_options as $key => $value) {
						if($temp_options[$i] != '' && $temp_options[$i] != '' && array_key_exists($i, $temp_value) && array_key_exists($i, $temp_value)){
							if($i > 0){
								$pagination_config['rules'] .= " AND ";
							}
							if($temp_isnot[$i] == 'is'){
								$pagination_config['rules'] .= $temp_options[$i]." = '".$temp_value[$i]."'";
							}else{
								$pagination_config['rules'] .= $temp_options[$i]." != '".$temp_value[$i]."'";
							}
						}
						$i++;	
					}
				}
			}
		}
		
		if($this->input->get('academic_nim') != ''){
			$pagination_config['academic_nim'] = $this->input->get('academic_nim');
		}

		if($this->input->get('name') != ''){
			$pagination_config['name'] = $this->input->get('name');
		}

		if($this->input->get('academic_faculty') != ''){
			$pagination_config['academic_faculty'] = $this->input->get('academic_faculty');
		}
		
		if($this->input->get('academic_program') != ''){
			$pagination_config['academic_program'] = $this->input->get('academic_program');
		}

		if($this->input->get('academic_year') != ''){
			$pagination_config['academic_year'] = $this->input->get('academic_year');
		}

		if($this->input->get('order_by') != ''){
			$pagination_config['order_by'] = $this->input->get('order_by');
		}

		if($this->input->get('status') != ''){
			$pagination_config['status'] = $this->input->get('status');
		}
		// else{
		// 	$pagination_config['status'] = 'all';
		// }

		if($this->input->get('download') == 'unduh'){
			$pagination_config['download'] = 'unduh';
		}

		$pagination_config['per_page'] = Settings::get('records_per_page');

		$pagination_config['total_rows'] = $this->kuesioner_answer_m->count_all_kuesioner_answer_by_kuesioner_id($pagination_config);
		
		$data['kuesioner_answer']['entries'] = $this->kuesioner_answer_m->get_kuesioner_answer($pagination_config);

		// $pagination_config['total_rows'] = $this->kuesioner_answer_m->count_all_kuesioner_answer_by_kuesioner_id($pagination_config);
		// if($pagination_config['total_rows'] == 0){
		// 	$pagination_config['status'] = 'not_fill';
			
			
		// }else{
		// 	$data['kuesioner_answer']['entries'] = $this->kuesioner_answer_m->get_kuesioner_answer($pagination_config);
		// }

		$pagination_config['status'] = 'all';
		
		$all_have_fill = $this->kuesioner_answer_m->get_kuesioner_answer($pagination_config);
		$all_have = array();
		foreach ($all_have_fill as $key => $value) {
			array_push($all_have, $value['nim']);
		}
		
		
		if($this->input->get('download') == 'unduh'){
			$filter_like_arr = array();
			$filter_arr = array();
			
			// ----------------------------------
			// get struktur pertanyaan kuesioner
			// ----------------------------------
			$kuesioner_structure = array();
			$all_fields = array();
			
			// 1 - get kuesioner pages
			$kuesioner_pages_json = $kuesioner['pages'];
			$kuesioner_pages_obj = json_decode($kuesioner_pages_json);
			$kuesioner_pages = $kuesioner_pages_obj->urutan;
			foreach($kuesioner_pages as $page_id){
				$kuesioner_structure["p_".$page_id] = array();
			}

			foreach($kuesioner_pages as $page_id){
				$temp_page_json = $this->kuesioner_page_m->get_kuesioner_page_by_id($page_id);
				$page_sections_json = $temp_page_json['sections'];
				$page_sections_obj = json_decode($page_sections_json);
				$page_sections = $page_sections_obj->urutan;
				foreach($page_sections as $section_id){
					$kuesioner_structure["p_".$page_id]["s_".$section_id] = array();
				}
				
				// 3 - get fields for each section
				foreach($page_sections as $section_id){
					$temp_section_json = $this->kuesioner_section_m->get_kuesioner_section_by_id($section_id);
					$section_fields_json = $temp_section_json['fields'];
					$section_fields_obj = json_decode($section_fields_json);
					$section_fields = $section_fields_obj->urutan;
					foreach($section_fields as $field_id){
						$kuesioner_structure["p_".$page_id]["s_".$section_id]["f_".$field_id] = array();
					}
					
					// 4 - get fields info for each field id
					foreach($section_fields as $field_id){
						$count =  $this->kuesioner_field_m->count_all_kuesioner_field($id_kuesioner,$page_id,$section_id,$field_id);

						if($count != 0){
							$temp_field_json = $this->kuesioner_field_m->get_kuesioner_field_by_condition($id_kuesioner,$page_id,$section_id,$field_id);

							$field_json = $temp_field_json['options'];
							$field_type = $temp_field_json['type'];

							$field_obj = json_decode($field_json);
							$field_arr = array();
							if($field_obj != null){
								$field_arr['title'] = $field_obj->title[0];
								$field_arr['type'] = $field_type;
								$field_arr['val'] = $field_obj->val;
								$field_arr['row_qst'] = $field_obj->row_qst;
							}
							
							$has_other_option = '';
							if(isset($field_obj->has_other_option) AND is_array($field_obj->has_other_option) AND isset($field_obj->has_other_option[0])){
								$has_other_option = $field_obj->has_other_option[0];
							}
							$field_arr['has_other_option'] = $has_other_option;
							
							// add to kuesioner structure
							$kuesioner_structure["p_".$page_id]["s_".$section_id]["f_".$field_id] = $field_arr;
							
							// add to all fields
							if($field_arr['type'] == 'single' 
								OR $field_arr['type'] == 'email' 
								OR $field_arr['type'] == 'date' 
								OR $field_arr['type'] == 'number'
								OR $field_arr['type'] == 'phone' 
								OR $field_arr['type'] == 'scale' 
								OR $field_arr['type'] == 'readonly'
								OR $field_arr['type'] == 'dropdown'
								OR $field_arr['type'] == 'radio'){

								$temp_field = $field_arr;
								
								$temp_field['kuesioner_id'] = $id_kuesioner;
								$temp_field['page_id'] = $page_id;
								$temp_field['section_id'] = $section_id;
								$temp_field['id_html'] = $field_id;
								
								unset($temp_field['val']);
								unset($temp_field['row_qst']);
								unset($temp_field['has_other_option']);
								
								$all_fields[] = $temp_field;
								
							}elseif($field_arr['type'] == 'checkbox'){
							
								foreach($field_arr['val'] as $val){
									$temp_field = $field_arr;
									$temp_field['title'] = $temp_field['title']."[".$val."]";
									$temp_field['val'] = $val;
									
									$temp_field['kuesioner_id'] = $id_kuesioner;
									$temp_field['page_id'] = $page_id;
									$temp_field['section_id'] = $section_id;
									$temp_field['id_html'] = $field_id;
									
									unset($temp_field['row_qst']);
									unset($temp_field['has_other_option']);
									
									$all_fields[] = $temp_field;
								}
								if($has_other_option == 'true'){
									$temp_field = $field_arr;
									$temp_field['title'] = $temp_field['title']."[other]";
									$temp_field['val'] = 'other';
									
									$temp_field['kuesioner_id'] = $id_kuesioner;
									$temp_field['page_id'] = $page_id;
									$temp_field['section_id'] = $section_id;
									$temp_field['id_html'] = $field_id;
									
									unset($temp_field['row_qst']);
									unset($temp_field['has_other_option']);
									
									$all_fields[] = $temp_field;
								}
							
							}elseif($field_arr['type'] == 'grid'){
							
								foreach($field_arr['row_qst'] as $row_qst){
									$temp_field = $field_arr;
									$temp_field['title'] = $temp_field['title']."[".$row_qst."]";
									$temp_field['row_qst'] = $row_qst;
									
									$temp_field['kuesioner_id'] = $id_kuesioner;
									$temp_field['page_id'] = $page_id;
									$temp_field['section_id'] = $section_id;
									$temp_field['id_html'] = $field_id;
									
									unset($temp_field['val']);
									unset($temp_field['has_other_option']);
									
									$all_fields[] = $temp_field;
								}
							
							}
						}
						
					}
				}
			}

			$all_data = $data['kuesioner_answer']['entries'];
			
			// csv init
			$data_full = array();
			
			//csv header
			$header = array();
			foreach($all_fields as $field){
				$header[] = $field['title'];
			}
			$data_full[] = $header;
			
			//object to array
			foreach($all_data as $data) {
				$answer_line = array();
				if($data['answers'] != '' || !is_null($data['answers'])){
					$answer_arr = json_decode($data['answers'], TRUE);
					foreach($all_fields as $field){
						if(isset($answer_arr['q_'.$field['kuesioner_id']]['p_'.$field['page_id']]['s_'.$field['section_id']]['id_'.$field['id_html']])){
							$single_ans = $answer_arr['q_'.$field['kuesioner_id']]['p_'.$field['page_id']]['s_'.$field['section_id']]['id_'.$field['id_html']];
							
							if($field['type'] == 'single' 
								OR $field['type'] == 'email' 
								OR $field['type'] == 'date' 
								OR $field['type'] == 'number'
								OR $field['type'] == 'phone' 
								OR $field['type'] == 'scale' 
								OR $field['type'] == 'dropdown'
								OR $field['type'] == 'radio'){
								
								if(isset($single_ans['answer'][0])){
									if($single_ans['answer'][0] != 'other'){
										$answer_line[] = $single_ans['answer'][0];
									}else{
										$answer_line[] = $single_ans['other_answer'][0];
									}
								}else{
									$answer_line[] = '';
								}
								
							}elseif($field['type'] == 'checkbox'){
								if(is_array($single_ans['answer']) AND in_array($field['val'], $single_ans['answer'])){
									if($field['val'] != 'other'){
										$answer_line[] = '1';
									}else{
										$answer_line[] = $single_ans['other_answer'][0];
									}
								}else{
									$answer_line[] = '0';
								}
								
							}elseif($field['type'] == 'grid'){
							
								if(is_array($single_ans['question']) 
									AND is_array($single_ans['answer']) 
									AND in_array($field['row_qst'], $single_ans['question'])){
									
									// get index of
									$idx_of = -1;
									foreach($single_ans['question'] as $idx => $question){
										if($field['row_qst'] == $question){
											$idx_of = $idx - 1;
											break;
										}
									}
									
									if(isset($single_ans['answer'][$idx_of])){
										$answer_line[] = $single_ans['answer'][$idx_of];
									}else{
										$answer_line[] = '';
									}
								}else{
									$answer_line[] = '';
								}
							
							}elseif ($field['type'] == 'readonly') {
								$selected_field_obj = $this->kuesioner_field_m->get_kuesioner_field_by_condition($field['kuesioner_id'],$field['page_id'],$field['section_id'],$field['id_html']);
								$select_field = json_decode($selected_field_obj['options']);
								$select_field_user_field = $select_field->user_field[0];

								$select_field_value = $this->kuesioner_answer_m->get_readonly_value($select_field_user_field, $data['user_id']);
								$answer_line[] = $select_field_value[$select_field_user_field];
							}
						}else{
							$answer_line[] = '';
						}
					}
				}else{
					$default_value = $this->kuesioner_answer_m->get_readonly_value("*",$data['user_id']);
					foreach($all_fields as $field){
						if ($field['type'] == 'readonly') {
							$selected_field_obj = $this->kuesioner_field_m->get_kuesioner_field_by_condition($field['kuesioner_id'],$field['page_id'],$field['section_id'],$field['id_html']);
							$select_field = json_decode($selected_field_obj['options']);
							$select_field_user_field = $select_field->user_field[0];
							$answer_line[] = $default_value[$select_field_user_field];
						}else{
							$answer_line[] = "";
						}
					}
				}
				$data_full[] = $answer_line;
			}
			//dump($data_full);exit;
			
			// write csv file
			array_to_csv($data_full, $id_kuesioner."_".$title."_entries.csv");
			
			exit();
		}

		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;

		$data['kuesioner_answer']['total'] = $pagination_config['total_rows'];
		$data['kuesioner_answer']['pagination'] = $this->pagination->create_links();
		$data['kuesioner_name'] = $title;
		$data['id_kuesioner'] = $id_kuesioner;

		$rules = $kuesioner['conditional_logic'];
		$data['finish'] = $this->kuesioner_answer_m->get_count_by_rules($rules, $add, $id_kuesioner,'finish');
		$data['ongoing'] = $this->kuesioner_answer_m->get_count_by_rules($rules, $add, $id_kuesioner,'ongoing');
		$data['not_fill'] = (int)$this->kuesioner_answer_m->get_count_by_rules($rules, $add, $id_kuesioner,'not_fill') - (int)$data['finish'] - (int)$data['ongoing'];
		
		$data['supervision'] = $supervision;
		

		$data['all_have_fill'] = $all_have_fill;
		$data['all_have'] = $all_have;

		$data['all_fakultas'] = $this->units_m->get_units_by_type('Fakultas');
		$data['all_prodi'] = $this->units_m->get_units_by_type('Program-Studi');
 
		$this->template->title(lang('kuesioner:kuesioner_answer:plural'))
		->set_breadcrumb(lang('kuesioner:kuesioner:plural'), '/admin/kuesioner')
		->set_breadcrumb($title, '/admin/kuesioner/kuesioner/edit/'.$id_kuesioner)
		->set_breadcrumb(lang('kuesioner:data_isian'), '/admin/kuesioner/kuesioner_answer/index/'.$id_kuesioner)
		->build('admin/kuesioner_answer_index', $data);
    }

	/**
     * Mengambil data prodi
     *
     * Fungsi ini akan mengambil data prodi berdasarkan id_unit user aktif
     * @param int $id id_unit
     * @return	json
     */
	public function get_prodi(){
		$id = $this->input->get('id');
		$prodi = $this->units_m->get_units_by_parent($id);
		echo json_encode($prodi);
	}

	// --------------------------------------------------------------------------

}