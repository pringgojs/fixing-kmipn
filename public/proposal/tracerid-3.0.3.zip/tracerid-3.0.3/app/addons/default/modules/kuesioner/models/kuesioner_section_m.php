<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model Kuesioner_section_m
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Models
 */
class Kuesioner_section_m extends MY_Model {
	
	/**
	 * Mengambil semua data section kuesioner
	 *
	 * Fungsi ini akan mengambil semua data section kuesioner berdasarkan limit data dan start page tertentu
	 * @param array $pagination_config
	 * @return array
	*/
	public function get_kuesioner_section($pagination_config = NULL)
	{
		$this->db->select('*');
		
		$start = ($this->uri->segment($pagination_config['uri_segment'])) ? $this->uri->segment($pagination_config['uri_segment']) : 0;
		$this->db->limit($pagination_config['per_page'], $start);
		
		$query = $this->db->get('default_kuesioner_kuesioner_section');
		$result = $query->result_array();
		
        return $result;
	}
	
	/**
	 * Mengambil data section kuesioner berdasarkan id
	 *
	 * @param int $id
	 * @return array
	*/
	public function get_kuesioner_section_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_section');
		$result = $query->row_array();
		
		return $result;
	}

	/**
	 * Mengambil data section kuesioner berdasarkan kuesioner_id
	 *
	 * @param int $id kuesioner_id
	 * @return array
	*/
	public function get_kuesioner_section_by_kuesioner_id($id)
	{
		$this->db->select('*');
		$this->db->where('kuesioner_id', $id);
		$this->db->order_by('id','asc');
		$query = $this->db->get('default_kuesioner_kuesioner_section');
		$result = $query->result_array();
		
		return $result;
	}

	/**
	 * Mengambil data section kuesioner berdasarkan id (return obj)
	 *
	 * @param int $id
	 * @return obj
	*/
	public function get_kuesioner_section_by_id_result($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_section');
		$result = $query->result();
		
		return $result;
	}
	
	/**
	 * Mengambil jumlah data section kuesioner
	 *
	 * @return int
	*/
	public function count_all_kuesioner_section()
	{
		return $this->db->count_all('kuesioner_kuesioner_section');
	}
	
	/**
	 * Menghapus data section kuesioner tertentu
	 *
	 * @param int $id
	 * @return void
	*/
	public function delete_kuesioner_section_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('default_kuesioner_kuesioner_section');
	}
	
	/**
	 * Menambah data section kuesioner
	 *
	 * @param array $values field=>value
	 * @return void
	*/
	public function insert_kuesioner_section($values)
	{
		$values['created_on'] = date("Y-m-d H:i:s");
		$values['created_by'] = $this->current_user->id;
		
		return $this->db->insert('default_kuesioner_kuesioner_section', $values);
	}
	
	/**
	 * Mengubah data section kuesioner berdasarkan id
	 *
	 * @param array $values field=>value
	 * @param int $row_id id
	 * @return void
	*/
	public function update_kuesioner_section($values, $row_id)
	{
		$values['updated_on'] = date("Y-m-d H:i:s");
		
		$this->db->where('id', $row_id);
		return $this->db->update('default_kuesioner_kuesioner_section', $values); 
	}

	/**
	 * Mengambil data section kuesioner berdasarkan page_id
	 *
	 * @param int $id page_id
	 * @return obj
	*/
	public function get_all_section_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('page_id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_section');
		
		return $query->result();
	}
	
	/**
	 * Mengambil data section kuesioner berdasarkan kuesioner_id
	 *
	 * @param int $order section_id
	 * @param int $kuesioner_id
	 * @return obj
	*/
	public function get_section_by_order($order, $kuesioner_id){
		$this->db->where('id',$order);
        $this->db->where('kuesioner_id',$kuesioner_id);
        $query = $this->db->get('default_kuesioner_kuesioner_section')->result();

        return $query;
	}

	/**
	 * Mengambil data field kuesioner berdasarkan kuesioner_id dan page_id
	 *
	 * @param int $id_kuesioner
	 * @param int $id_page
	 * @return obj
	*/
	public function get_all_field_by_condition($id_kuesioner,$id_page){
		$temp_where = "(type = 'dropdown' OR type = 'radio' OR type = 'checkbox')";
		$this->db->select('default_kuesioner_kuesioner_page.title AS page_title, default_kuesioner_kuesioner_section.title AS section_title, default_kuesioner_kuesioner_field.id, id_html, default_kuesioner_kuesioner_field.kuesioner_id, default_kuesioner_kuesioner_field.section_id, default_kuesioner_kuesioner_field.page_id, type, options');
		$this->db->from('default_kuesioner_kuesioner_field');
		$this->db->join('default_kuesioner_kuesioner_page', 'default_kuesioner_kuesioner_field.page_id = default_kuesioner_kuesioner_page.id');
		$this->db->join('default_kuesioner_kuesioner_section', 'default_kuesioner_kuesioner_field.section_id = default_kuesioner_kuesioner_section.id');
		$this->db->where('default_kuesioner_kuesioner_field.kuesioner_id',$id_kuesioner);
		$this->db->where('default_kuesioner_kuesioner_field.page_id',$id_page);
		$this->db->where($temp_where);
		$this->db->order_by("page_id", "section_id", "id_html"); 
		$query = $this->db->get();

		return $query->result();
	}

	/**
	 * Mengambil data field kuesioner berdasarkan kondisi
	 *
	 * @param int $id_kuesioner
	 * @param int $id_page
	 * @param int $id_section
	 * @return obj
	*/
	public function get_all_field_option_by_condition($id_kuesioner,$id_page,$id_section){
		$temp_where = "(type = 'dropdown' OR type = 'radio' OR type = 'checkbox')";
		$this->db->select('default_kuesioner_kuesioner_page.title AS page_title, default_kuesioner_kuesioner_section.title AS section_title, default_kuesioner_kuesioner_field.id, id_html, default_kuesioner_kuesioner_field.kuesioner_id, default_kuesioner_kuesioner_field.section_id, default_kuesioner_kuesioner_field.page_id, type, options');
		$this->db->from('default_kuesioner_kuesioner_field');
		$this->db->join('default_kuesioner_kuesioner_page', 'default_kuesioner_kuesioner_field.page_id = default_kuesioner_kuesioner_page.id');
		$this->db->join('default_kuesioner_kuesioner_section', 'default_kuesioner_kuesioner_field.section_id = default_kuesioner_kuesioner_section.id');
		$this->db->where('default_kuesioner_kuesioner_field.kuesioner_id',$id_kuesioner);
		$this->db->where('default_kuesioner_kuesioner_field.page_id',$id_page);
		$this->db->where('default_kuesioner_kuesioner_field.section_id !=',$id_section);
		$this->db->where($temp_where);
		$this->db->order_by("page_id", "section_id", "id_html"); 
		$query = $this->db->get();

		return $query->result();
	}
}