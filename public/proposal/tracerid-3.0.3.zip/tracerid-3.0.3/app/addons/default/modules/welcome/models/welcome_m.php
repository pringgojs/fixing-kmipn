<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model Welcome_m
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Welcome\Models
 */
class Welcome_m extends MY_Model {
	
	/**
	 * Mengambil data content welcom
	 *
	 * Fungsi ini akan mengambil data content welcome berdasarkan limit data dan start page tertentu
	 * @param array $pagination_config
	 * @return array
	*/
	public function get_welcome($pagination_config = NULL)
	{
		$this->db->select('*');
		
		$start = ($this->uri->segment($pagination_config['uri_segment'])) ? $this->uri->segment($pagination_config['uri_segment']) : 0;
		$this->db->limit($pagination_config['per_page'], $start);
		
		$query = $this->db->get('default_welcome_welcome');
		$result = $query->result_array();
		
        return $result;
	}
	
	/**
	 * Mengambil data content welcome berdasarkan id
	 *
	 * @param int $id
	 * @return array
	*/
	public function get_welcome_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_welcome_welcome');
		$result = $query->row_array();
		
		return $result;
	}
	
	/**
	 * Mengambil jumlah data content welcome
	 *
	 * @return int
	*/
	public function count_all_welcome()
	{
		return $this->db->count_all('welcome_welcome');
	}
	
	/**
	 * Menghapus data content welcome
	 *
	 * @param int $id
	 * @return void
	*/
	public function delete_welcome_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('default_welcome_welcome');
	}
	
	/**
	 * Menambah data content welcome
	 *
	 * @param array $values
	 * @return void
	*/
	public function insert_welcome($values)
	{	
		return $this->db->insert('default_welcome_welcome', $values);
	}
	
	/**
	 * Mengubah data content welcome berdasarkan id
	 *
	 * @param array $values
	 * @param int $row_id
	 * @return void
	*/
	public function update_welcome($values, $row_id)
	{
		$this->db->where('id', $row_id);
		return $this->db->update('default_welcome_welcome', $values); 
	}
	
}