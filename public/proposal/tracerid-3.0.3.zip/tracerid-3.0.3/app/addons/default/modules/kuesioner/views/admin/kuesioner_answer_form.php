<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner_answer:'.$mode); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="kuesioner_id"><?php echo lang('kuesioner:kuesioner_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('kuesioner_id') != NULL){
					$value = $this->input->post('kuesioner_id');
				}elseif($mode == 'edit'){
					$value = $fields['kuesioner_id'];
				}
			?>
			<input name="kuesioner_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="user_id"><?php echo lang('kuesioner:user_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('user_id') != NULL){
					$value = $this->input->post('user_id');
				}elseif($mode == 'edit'){
					$value = $fields['user_id'];
				}
			?>
			<input name="user_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="username"><?php echo lang('kuesioner:username'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('username') != NULL){
					$value = $this->input->post('username');
				}elseif($mode == 'edit'){
					$value = $fields['username'];
				}
			?>
			<input name="username" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="answers"><?php echo lang('kuesioner:answers'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('answers') != NULL){
					$value = $this->input->post('answers');
				}elseif($mode == 'edit'){
					$value = $fields['answers'];
				}
			?>
			<input name="answers" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="status"><?php echo lang('kuesioner:status'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('status') != NULL){
					$value = $this->input->post('status');
				}elseif($mode == 'edit'){
					$value = $fields['status'];
				}
			?>
			<input name="status" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

</div>

<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<button type="submit" class="btn btn-primary"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

<?php echo form_close();?>