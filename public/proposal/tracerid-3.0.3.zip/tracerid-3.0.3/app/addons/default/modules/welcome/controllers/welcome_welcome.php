<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Welcome Module
 *
 * Welcome Message
 *
 */
class Welcome_welcome extends Public_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'welcome';
	
    public function __construct()
    {
        parent::__construct();

        // -------------------------------------
		// Load everything we need
		// -------------------------------------

		$this->lang->load('buttons');
        $this->lang->load('welcome');
		
		$this->load->model('welcome_m');
    }

    /**
	 * List all welcome
     *
     * @return	void
     */
    public function index()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'view_all_welcome') AND ! group_has_role('welcome', 'view_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
        // -------------------------------------
		// Pagination
		// -------------------------------------

		$pagination_config['base_url'] = base_url(). 'welcome/welcome/index';
		$pagination_config['uri_segment'] = 4;
		$pagination_config['total_rows'] = $this->welcome_m->count_all_welcome();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;
		
        // -------------------------------------
		// Get entries
		// -------------------------------------
		
        $data['welcome']['entries'] = $this->welcome_m->get_welcome($pagination_config);
		$data['welcome']['total'] = count($data['welcome']['entries']);
		$data['welcome']['pagination'] = $this->pagination->create_links();

		// -------------------------------------
		// Build the page. 
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:plural'))
			->set_breadcrumb('Home', '/')
			->set_breadcrumb(lang('welcome:welcome:plural'))
			->build('welcome_index', $data);
    }
	
	/**
     * Display one welcome
     *
     * @return  void
     */
    public function view($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'view_all_welcome') AND ! group_has_role('welcome', 'view_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Get our entry.
		// -------------------------------------
		
        $data['welcome'] = $this->welcome_m->get_welcome_by_id($id);
		
		// Check view all/own permission
		if(! group_has_role('welcome', 'view_all_welcome')){
			if($data['welcome']->created_by != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}

		// -------------------------------------
		// Build the page.
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:view'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:view'))
			->build('welcome_entry', $data);
    }
	
	/**
     * Create a new welcome entry
     *
     * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'create_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_welcome('new')){	
				$this->session->set_flashdata('success', lang('welcome:welcome:submit_success'));				
				redirect('welcome/welcome/index');
			}else{
				$data['messages']['error'] = lang('welcome:welcome:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'welcome/welcome/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:new'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:new'))
			->build('welcome_form', $data);
    }
	
	/**
     * Edit a welcome entry
     *
     * We're passing the
     * id of the entry, which will allow entry_form to
     * repopulate the data from the database.
	 * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @param   int [$id] The id of the welcome to the be deleted.
     * @return	void
     */
    public function edit($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'edit_all_welcome') AND ! group_has_role('welcome', 'edit_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('welcome', 'edit_all_welcome')){
			$entry = $this->welcome_m->get_welcome_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_welcome('edit', $id)){	
				$this->session->set_flashdata('success', lang('welcome:welcome:submit_success'));				
				redirect('welcome/welcome/index');
			}else{
				$data['messages']['error'] = lang('welcome:welcome:submit_failure');
			}
		}
		
		$data['fields'] = $this->welcome_m->get_welcome_by_id($id);
		$data['mode'] = 'edit';
		$data['return'] = 'welcome/welcome/view/'.$id;
		$data['entry_id'] = $id;
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
        $this->template->title(lang('welcome:welcome:edit'))
			->set_breadcrumb('Home', '/home')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:view'), '/welcome/welcome/view/'.$id)
			->set_breadcrumb(lang('welcome:welcome:edit'))
			->build('welcome_form', $data);
    }
	
	/**
     * Delete a welcome entry
     * 
     * @param   int [$id] The id of welcome to be deleted
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'delete_all_welcome') AND ! group_has_role('welcome', 'delete_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('login');
		}
		// Check view all/own permission
		if(! group_has_role('welcome', 'delete_all_welcome')){
			$entry = $this->welcome_m->get_welcome_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('login');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->welcome_m->delete_welcome_by_id($id);
		$this->session->set_flashdata('error', lang('welcome:welcome:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('welcome/welcome/index');
    }
	
	/**
     * Insert or update welcome entry in database
     *
     * @param   string [$method] The method of database update ('new' or 'edit').
	 * @param   int [$row_id] The entry id (if in edit mode).
     * @return	boolean
     */
	private function _update_welcome($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('field_name', lang('welcome:welcome:field_name'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->welcome_m->insert_welcome($values);
			}
			else
			{
				$result = $this->welcome_m->update_welcome($values, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}