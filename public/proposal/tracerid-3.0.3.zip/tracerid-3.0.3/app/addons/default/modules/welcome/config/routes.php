<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$route['welcome/admin/welcome(:any)'] = 'admin_welcome$1';
$route['welcome/welcome(:any)'] = 'welcome_welcome$1';
