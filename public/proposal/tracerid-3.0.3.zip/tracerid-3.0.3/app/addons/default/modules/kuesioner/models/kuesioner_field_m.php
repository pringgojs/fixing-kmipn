<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Model Kuesioner_field_m
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Models
 */
class Kuesioner_field_m extends MY_Model {
	
	/**
	 * Mengambil data field kuesioner
	 *
	 * Fungsi ini akan mengambil data field kuesioner berdasarkan limit data dan start page tertentu
	 * @param array $pagination_config
	 * @return array
	*/
	public function get_kuesioner_field($pagination_config = NULL)
	{
		$this->db->select('*');
		
		$start = ($this->uri->segment($pagination_config['uri_segment'])) ? $this->uri->segment($pagination_config['uri_segment']) : 0;
		$this->db->limit($pagination_config['per_page'], $start);
		
		$query = $this->db->get('default_kuesioner_kuesioner_field');
		$result = $query->result_array();
		
        return $result;
	}
	
	/**
	 * Mengambil data field kuesioner berdasarkan id
	 *
	 * @param int $id
	 * @return array
	*/
	public function get_kuesioner_field_by_id($id)
	{
		$this->db->select('*');
		$this->db->where('id', $id);
		$query = $this->db->get('default_kuesioner_kuesioner_field');
		$result = $query->row_array();
		
		return $result;
	}

	/**
	 * Mengambil data field kuesioner berdasarkan id kuesioner
	 *
	 * @param int $id id kuesioner
	 * @return array
	*/
	public function get_kuesioner_field_by_kuesioner_id($id)
	{
		$this->db->select('*');
		$this->db->where('kuesioner_id', $id);
		$this->db->order_by('id','asc');
		$query = $this->db->get('default_kuesioner_kuesioner_field');
		$result = $query->result_array();
		
		return $result;
	}

	/**
	 * Mengambil data field kuesioner berdasarkan kondisi
	 *
	 * @param int $id_kuesioner
	 * @param int $page_id
	 * @param int $section_id
	 * @param int $field_id
	 * @return array
	*/
	public function get_kuesioner_field_by_condition($id_kuesioner,$page_id,$section_id,$field_id)
	{
		$this->db->select('*');
		if($id_kuesioner != ''){
			$this->db->where('kuesioner_id', $id_kuesioner);
		}

		if($page_id != ''){
			$this->db->where('page_id', $page_id);
		}
		
		if($section_id != ''){
			$this->db->where('section_id', $section_id);
		}
		
		if($section_id != ''){
			$this->db->where('id_html', $field_id);
		}
		
		$query = $this->db->get('kuesioner_kuesioner_field');
		$result = $query->row_array();

		return $result;
	}
	
	/**
	 * Mengambil jumlah data field kuesioner
	 *
	 * @param int $id_kuesioner
	 * @param int $page_id
	 * @param int $section_id
	 * @param int $field_id
	 * @return array
	*/
	public function count_all_kuesioner_field($id_kuesioner,$page_id,$section_id,$field_id)
	{
		$this->db->where('kuesioner_id', $id_kuesioner);
		$this->db->where('page_id', $page_id);
		$this->db->where('section_id', $section_id);
		$this->db->where('id_html', $field_id);
		$this->db->from('kuesioner_kuesioner_field');
		return $this->db->count_all_results();
	}
	
	/**
	 * Menghapus data field kuesioner
	 *
	 * @param int $id id field kuesioner
	 * @return void
	*/
	public function delete_kuesioner_field_by_id($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('default_kuesioner_kuesioner_field');
	}

	/**
	 * Menghapus data field kuesioner berdasarkan kondisi tertentu
	 *
	 * @param int $id_html
	 * @param int $id_section
	 * @param int $id_kuesioner
	 * @return void
	*/
	public function delete_kuesioner_field_by_condition($id_html, $id_section, $id_kuesioner)
	{
		$this->db->where('id_html', $id_html);
		$this->db->where('section_id', $id_section);
		$this->db->where('kuesioner_id', $id_kuesioner);
		$this->db->delete('default_kuesioner_kuesioner_field');
	}

	public function delete_kuesioner_field_by_section($id_section){
		$this->db->where('section_id', $id_section);
		$this->db->delete('default_kuesioner_kuesioner_field');
	}

	
	/**
	 * Menambah data field kuesioner
	 *
	 * @param array $values
	 * @return void
	*/
	public function insert_kuesioner_field($values)
	{
		$values['created_on'] = date("Y-m-d H:i:s");
		$values['created_by'] = $this->current_user->id;
		
		return $this->db->insert('default_kuesioner_kuesioner_field', $values);
	}
	
	/**
	 * Mengubah data field kuesioner berdasarkan field_id
	 *
	 * @param array $values
	 * @param int $row_id field_id
	 * @return void
	*/
	public function update_kuesioner_field($values, $row_id)
	{
		$values['updated_on'] = date("Y-m-d H:i:s");
		
		$this->db->where('id', $row_id);
		return $this->db->update('default_kuesioner_kuesioner_field', $values); 
	}

	/**
	 * Mengubah data field kuesioner berdasarkan section_id
	 *
	 * @param array $values
	 * @param int $section_id
	 * @param int $row_id field_id
	 * @return void
	*/
	public function update_kuesioner_field_by_section_id($values, $section_id, $row_id)
	{
		$values['updated_on'] = date("Y-m-d H:i:s");

		$this->db->where('section_id', $section_id);
		$this->db->where('id_html', $row_id);
		return $this->db->update('default_kuesioner_kuesioner_field', $values); 
	}

	/**
	 * Mengambil data user
	 *
	 * @return array
	*/
	public function get_user_field(){
		return $this->db->list_fields('default_profiles');
	}
	
	/**
	 * Mengambil data field berdasarkan section_id dan id_html
	 *
	 * @param int $id_section
	 * @param int $order id_html
	 * @return obj
	*/
	public function get_field_by_order($id_section,$order){
		$this->db->where('section_id',$id_section);
        $this->db->where('id_html',$order);
        return $this->db->get('default_kuesioner_kuesioner_field')->result();
	}

	/**
	 * Mengambil data field berdasarkan id_kuesionerr dan section_id
	 *
	 * @param int $id_kuesioner
	 * @param int $id_section section_id
	 * @return obj
	*/
	public function get_kuesioner_field_by_condition_for_section($id_kuesioner,$id_section)
	{
		$this->db->where('kuesioner_id',$id_kuesioner);
        $this->db->where('section_id',$id_section);
        $result = $this->db->get('default_kuesioner_kuesioner_field')->result();
		return $result;
	}
}