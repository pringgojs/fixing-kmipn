<div class="page-header">
	<h1>
		<span><?php echo lang('kuesioner:kuesioner_section:'.$mode); ?></span>
	</h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="title"><?php echo lang('kuesioner:title'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('title') != NULL){
					$value = $this->input->post('title');
				}elseif($mode == 'edit'){
					$value = $fields['title'];
				}
			?>
			<input name="title" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:deskripsi'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('deskripsi') != NULL){
					$value = $this->input->post('deskripsi');
				}elseif($mode == 'edit'){
					$value = $fields['deskripsi'];
				}
			?>
			<input name="deskripsi" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="kuesioner_id"><?php echo lang('kuesioner:kuesioner_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('kuesioner_id') != NULL){
					$value = $this->input->post('kuesioner_id');
				}elseif($mode == 'edit'){
					$value = $fields['kuesioner_id'];
				}
			?>
			<input name="kuesioner_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id=""/>
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="page_id"><?php echo lang('kuesioner:page_id'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('page_id') != NULL){
					$value = $this->input->post('page_id');
				}elseif($mode == 'edit'){
					$value = $fields['page_id'];
				}
			?>
			<input name="page_id" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="section_options"><?php echo lang('kuesioner:section_options'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('section_options') != NULL){
					$value = $this->input->post('section_options');
				}elseif($mode == 'edit'){
					$value = $fields['section_options'];
				}
			?>
			<input name="section_options" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="fields"><?php echo lang('kuesioner:fields'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('fields') != NULL){
					$value = $this->input->post('fields');
				}elseif($mode == 'edit'){
					$value = $fields['fields'];
				}
			?>
			<input name="fields" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="conditional_logic"><?php echo lang('kuesioner:conditional_logic'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('conditional_logic') != NULL){
					$value = $this->input->post('conditional_logic');
				}elseif($mode == 'edit'){
					$value = $fields['conditional_logic'];
				}
			?>
			<input name="conditional_logic" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
			<span class="help-inline col-xs-12 col-sm-7">
				<span class="middle">Inline help text</span>
			</span>
		</div>
	</div>

</div>

<div class="clearfix form-actions">
	<div class="col-md-offset-2 col-md-10">
		<button type="submit" class="btn btn-primary"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

<?php echo form_close();?>