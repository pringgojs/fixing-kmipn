<script src="<?php echo base_url();?>system/cms/themes/ace/js/jscolor/jscolor.js"></script>
<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner:style'); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="title"><?php echo lang('kuesioner:title'); ?></label>

		<div class="col-sm-10">
			<input class="col-xs-10 col-sm-5" type="text" name="id_kuesioner" value='<?php echo $kuesioner["title"]; ?>' readonly>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:kuesioner:font-header'); ?></label>

		<div class="col-sm-10">
			<select id='font-header' required>
				<option value=""></option>
				<option value="Arial">Arial</option>
				<option value="Arial Black">Arial Black</option>
				<option value="Calibri">Calibri</option>
				<option value="Candara">Candara</option>
				<option value="Comic Sans Ms">Comic Sans Ms</option>
				<option value="Consolas">Consolas</option>
				<option value="Courier New">Courier New</option>
				<option value="Franklin Gothic Medium">Franklin Gothic Medium</option>
				<option value="Georgia">Georgia</option>
				<option value="Helvetica">Helvetica</option>
				<option value="Impact">Impact</option>
				<option value="Lucida Console">Lucida Console</option>
				<option value="Segoe UI">Segoe UI</option>
				<option value="Tahoma">Tahoma</option>
				<option value="Times New Roman">Times New Roman</option>
				<option value="Trebuchet MS">Trebuchet MS</option>
				<option value="Verdana">Verdana</option>
			</select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:kuesioner:font-question'); ?></label>

		<div class="col-sm-10">
			<select id='font-question' required>
				<option value=""></option>
				<option value="Andale Mono">Andale Mono</option>
				<option value="Arial">Arial</option>
				<option value="Arial Black">Arial Black</option>
				<option value="Arial Narrow">Arial Narrow</option>
				<option value="Arial Rounded MT Bold">Arial Rounded MT Bold</option>
				<option value="Avant Garde">Avant Garde</option>
				<option value="Baskerville">Baskerville</option>
				<option value="Big Caslon">Big Caslon</option>
				<option value="Bodoni MT">Bodoni MT</option>
				<option value="Calibri">Calibri</option>
				<option value="Calisto MT">Calisto MT</option>
				<option value="Cambrio">Cambrio</option>
				<option value="Candara">Candara</option>
				<option value="Century Gothic">Century Gothic</option>
				<option value="Comic Sans Ms">Comic Sans Ms</option>
				<option value="Consolas">Consolas</option>
				<option value="Copperplate">Copperplate</option>
				<option value="Courier New">Courier New</option>
				<option value="Didot">Didot</option>
				<option value="Franklin Gothic Medium">Franklin Gothic Medium</option>
				<option value="Futura">Futura</option>
				<option value="Garamond">Garamond</option>
				<option value="Geneva">Geneva</option>
				<option value="Georgia">Georgia</option>
				<option value="Gill Sans">Gill Sans</option>
				<option value="Goudy Old Style">Goudy Old Style</option>
				<option value="Helvetica">Helvetica</option>
				<option value="Hoefler Text">Hoefler Text</option>
				<option value="Impact">Impact</option>
				<option value="Lucida Bright">Lucida Bright</option>
				<option value="Lucida Console">Lucida Console</option>
				<option value="Lucida Sans Typewriter">Lucida Sans Typewriter</option>
				<option value="Lucida Grande">Lucida Grande</option>
				<option value="Monaco">Monaco</option>
				<option value="Optima">Optima</option>
				<option value="Palatino">Palatino</option>
				<option value="Papyrus">Papyrus</option>
				<option value="Perpetua">Perpetua</option>
				<option value="Rockwell">Rockwell</option>
				<option value="Rockwell Extra Bold">Rockwell Extra Bold</option>
				<option value="Segoe UI">Segoe UI</option>
				<option value="Tahoma">Tahoma</option>
				<option value="Times New Roman">Times New Roman</option>
				<option value="Trebuchet MS">Trebuchet MS</option>
				<option value="Verdana">Verdana</option>
			</select>
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:kuesioner:header-back-color'); ?></label>

		<div class="col-sm-10">
			<input class="color {required:false, hash:true}" id="header-back-color" required>
		</div>
	</div>
	<input type="hidden" id="hasil" name="hasil">
</div>


<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<button type="submit" id="simpan" onclick="save_value()" class="btn btn-primary"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

<?php echo form_close();?>

<script>
	function save_value(){
        var custom_view = {};
        custom_view["options"] = [];
        custom_view["value"] = [];

        var data = "";
       	custom_view["options"].push('font-header');
       	custom_view["options"].push('font-style');
       	custom_view["options"].push('background-color');

        custom_view["value"].push(document.getElementById('font-header').value); 	
       	custom_view["value"].push(document.getElementById('font-question').value); 
		custom_view["value"].push(document.getElementById('header-back-color').value); 
        
        data = JSON.stringify(custom_view);
        jQuery("#hasil").val(data);
		return false;
    }

    jQuery(document).ready(function(){

    	<?php 
			if($style != ''){ 
		        $style_obj = json_decode($style['style']);
		        if(isset($style_obj->options) && isset($style_obj->value)){
		            if(is_array($style_obj->options) && is_array($style_obj->value)){ ?>
		            	jQuery("#font-header").val('<?php echo $style_obj->value[0]; ?>');
    					jQuery("#font-question").val('<?php echo $style_obj->value[1]; ?>');
    					jQuery("#header-back-color").val('<?php echo $style_obj->value[2]; ?>');
		            	
		<?php    }
		        }
		    }
		?>
    	
    	jQuery("#simpan").on('click','#simpan',function(){
    		save_value();
    	});
    });
</script>