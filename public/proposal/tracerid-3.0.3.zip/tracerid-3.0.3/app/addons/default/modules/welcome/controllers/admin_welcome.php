<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Admin_welcome
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Welcome\Controllers
 */
class Admin_welcome extends Admin_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'welcome';

    public function __construct()
    {
        parent::__construct();

		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'access_welcome_backend')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Load everything we need
		// -------------------------------------

        $this->lang->load('welcome');		
		$this->load->model('welcome_m');
    }

    /**
	 * Menampilkan semua content welcome
     *
     * @return	void
     */
    public function index()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		$id = 0;
		$this->db->select_max('id');
		$query = $this->db->get('default_welcome_welcome');
		$ids = $query->row_array();
		$id = $ids['id'];

		if(! group_has_role('welcome', 'view_all_welcome') AND ! group_has_role('welcome', 'view_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		if(! group_has_role('welcome', 'edit_all_welcome') AND ! group_has_role('welcome', 'edit_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// Check view all/own permission
		if(! group_has_role('welcome', 'edit_all_welcome')){
			$entry = $this->welcome_m->get_welcome_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}

		if($_POST){
			if($this->_update_welcome('edit', $id)){	
				$this->session->set_flashdata('success', lang('welcome:welcome:submit_success'));				
				redirect('admin/welcome/welcome/index');
			}else{
				$data['messages']['error'] = lang('welcome:welcome:submit_failure');
			}
		}
		
		$data['fields'] = $this->welcome_m->get_welcome_by_id($id);
		$data['mode'] = 'edit';
		$data['return'] = 'admin/welcome/welcome/view/'.$id;
		$data['entry_id'] = $id;

		// -------------------------------------
		// Pagination
		// -------------------------------------

		/*$pagination_config['base_url'] = base_url(). 'admin/welcome/welcome/index';
		$pagination_config['uri_segment'] = 5;
		$pagination_config['total_rows'] = $this->welcome_m->count_all_welcome();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;
		
        // -------------------------------------
		// Get entries
		// -------------------------------------
		
        $data['welcome']['entries'] = $this->welcome_m->get_welcome($pagination_config);
		$data['welcome']['total'] = count($data['welcome']['entries']);
		$data['welcome']['pagination'] = $this->pagination->create_links();

		// -------------------------------------
        // Build the page. See views/admin/index.php
        // for the view code.
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:plural'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('welcome:welcome:plural'))
			->build('admin/welcome_index', $data);*/

		$this->template->title(lang('welcome:welcome:edit'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/admin/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:view'), '/admin/welcome/welcome/view/'.$id)
			->set_breadcrumb(lang('welcome:welcome:edit'))
			->build('admin/welcome_form', $data);	
    }
	
	/**
	 * Menampilkan content welcome tertentu
     *
     * @param	int $id
     * @return	void
     */
    public function view($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------

		if(! group_has_role('welcome', 'view_all_welcome') AND ! group_has_role('welcome', 'view_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Get our entry.
		// -------------------------------------
		
        $data['welcome'] = $this->welcome_m->get_welcome_by_id($id);
		
		// -------------------------------------
		// Check view all/own permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'view_all_welcome')){
			if($data['welcome']->created_by != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}

		// -------------------------------------
        // Build the page. See views/admin/index.php
        // for the view code.
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:view'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/admin/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:view'))
			->build('admin/welcome_entry', $data);
    }
	
	/**
     * Menambah data content welcome
     *
     * Fungsi ini akan menampilkan form tambah content welcome dan mengeksekusi fungsi _update_welcome untuk menambahkan data baru ke database.
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
    	
		if(! group_has_role('welcome', 'create_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_welcome('new')){	
				$this->session->set_flashdata('success', lang('welcome:welcome:submit_success'));				
				redirect('admin/welcome/welcome/index');
			}else{
				$data['messages']['error'] = lang('welcome:welcome:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'admin/welcome/welcome/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:new'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/admin/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:new'))
			->build('admin/welcome_form', $data);
    }
	
	/**
     * Mengedit content welcome
     *
     * Fungsi ini akan menampilkan form edit content welcome dan mengeksekusi fungsi _update_welcome untuk memperbaharui data di database..
     * @return	void
     */
    public function edit()
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		$id = 0;
		$this->db->select_max('id');
		$query = $this->db->get('default_welcome_welcome');
		$ids = $query->row_array();
		$id = $ids['id'];
		if(! group_has_role('welcome', 'edit_all_welcome') AND ! group_has_role('welcome', 'edit_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// Check view all/own permission
		if(! group_has_role('welcome', 'edit_all_welcome')){
			$entry = $this->welcome_m->get_welcome_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_welcome('edit', $id)){	
				$this->session->set_flashdata('success', lang('welcome:welcome:submit_success'));				
				redirect('admin/welcome/welcome/edit');
			}else{
				$data['messages']['error'] = lang('welcome:welcome:submit_failure');
			}
		}
		
		$data['fields'] = $this->welcome_m->get_welcome_by_id($id);
		$data['mode'] = 'edit';
		$data['return'] = 'admin/welcome/welcome/view/'.$id;
		$data['entry_id'] = $id;
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('welcome:welcome:edit'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('welcome:welcome:plural'), '/admin/welcome/welcome/index')
			->set_breadcrumb(lang('welcome:welcome:view'), '/admin/welcome/welcome/view/'.$id)
			->set_breadcrumb(lang('welcome:welcome:edit'))
			->build('admin/welcome_form', $data);
    }
	
	/**
     * Menghapus content welcome
     * 
     * Fungsi ini akan menghapus data content berdasarkan $id yang diterima
     * @param int $id
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('welcome', 'delete_all_welcome') AND ! group_has_role('welcome', 'delete_own_welcome')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		// Check view all/own permission
		if(! group_has_role('welcome', 'delete_all_welcome')){
			$entry = $this->welcome_m->get_welcome_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->welcome_m->delete_welcome_by_id($id);
        $this->session->set_flashdata('error', lang('welcome:welcome:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('admin/welcome/welcome/index');
    }
	
	/**
     * Insert atau update data content welcome di database
     *
     * Fungsi ini meneruskan proses perubahan data ke database
     * @param   string $method method untuk update data didatabase ('new' or 'edit'). Method ini dikirim dari fungsi create dan edit.
	 * @param   int $row_id id content welcome (jika method = edit).
     * @return	boolean
     */
	private function _update_welcome($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('welcome_message', lang('welcome:welcome:welcome_message'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->welcome_m->insert_welcome($values);
				
			}
			else
			{
				$result = $this->welcome_m->update_welcome($values, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}