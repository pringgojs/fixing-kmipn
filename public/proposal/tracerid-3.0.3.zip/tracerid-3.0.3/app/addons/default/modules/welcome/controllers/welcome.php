<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Welcome Module
 *
 * Welcome Message
 *
 */
class Welcome extends Public_Controller
{
    // This controller simply redirect to main section controller
	public function __construct()
    {
        parent::__construct();

        redirect('welcome/welcome/index');
    }

}