<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Admin_kuesioner_section
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Admin_kuesioner_section extends Admin_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner_section';

    public function __construct()
    {
        parent::__construct();

		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'access_kuesioner_section_backend')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Load everything we need
		// -------------------------------------

        $this->lang->load('kuesioner');		
        $this->load->model('kuesioner_m');
        $this->load->model('kuesioner_page_m');
		$this->load->model('kuesioner_section_m');
		$this->load->model('kuesioner_field_m');
    }

    /**
     * Create a new kuesioner_section entry
     *
     * We are building entry form manually using the fields API
     * and displaying the output in a custom view file.
     *
     * @return	void
     */
    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'create_kuesioner_section')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_section('new')){	
				$id = $this->input->post('page_id');
				$kuesioner_id = $this->input->post('kuesioner_id');
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_section:submit_success'));				
				redirect('admin/kuesioner/kuesioner_page/edit/'.$kuesioner_id.'/'.$id);
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_section:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'admin/kuesioner/kuesioner_section/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_section:new'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner_section:plural'), '/admin/kuesioner/kuesioner_section/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_section:new'))
			->build('admin/kuesioner_section_form', $data);
    }
	
	/**
     * Mengedit section kuesioner
     *
     * Fungsi ini akan menampilkan form edit section kuesioner yang akan terisi oleh data section kuesioner berdasarkan $id yang diterima dan menampilkan daftar field kuesioner dari section kuesioner tersebut.
     * @param  int $id id kuesioner page
     * @param  int $id_kuesioner id kuesioner
     * @param  int $id_page id kuesioner page
     * @param  int $id_page id section page
     * @return	void
     */
    public function edit($id = 0)
    {
    	$id_kuesioner = (int) $this->uri->segment(5);
        $id_page = (int) $this->uri->segment(6);
        $id_section = (int) $this->uri->segment(7);
        // -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_section') AND ! group_has_role('kuesioner', 'edit_own_kuesioner_section')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_section')){
			$entry = $this->kuesioner_section_m->get_kuesioner_section_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			$id_kuesioner = $this->input->post('kuesioner_id');
		    $id_page = $this->input->post('page_id');
		    $id_section = $this->input->post('id');
		    

			$title = $this->input->post('title');
			$description = $this->input->post('deskripsi');
			$options = $this->input->post('options');
            $sections = $this->input->post('section_attr');
            $order = $this->input->post('order_field');
			$order_old = $this->input->post('order_field_old');
            
            $cl_section = $this->input->post('hidden_cl_section');
            $cl_field = $this->input->post('hidden_cl_field');

            $opt = json_decode($options,true);
            $ord = json_decode($order,true);
            if($ord['urutan'] == null){
            	$this->kuesioner_field_m->delete_kuesioner_field_by_section($id_section);
            	$order = '';
            }
            $ord_old = json_decode($order_old, true);
            
            $cl_s = json_decode($cl_section,true);
            $cl_f = json_decode($cl_field, true);
            
            for($i=0;$i<$ord["jumlah"][0];$i++){
                $ind = $ord["urutan"][$i];
                $typ = $ord["type"][$i];
                
                $attrib = json_encode($opt["id".$ind]);
                $cl_attrib = json_encode($cl_f["id".$ind]);
                if($cl_attrib=="[]"){
                    $cl_attrib='';
                }

				// get already stored field
				$stored_fields = $this->kuesioner_field_m->get_kuesioner_field_by_condition_for_section($id_kuesioner,$id_section);
				
				// delete unused field
				foreach($stored_fields as $stored_field){
					if(! in_array($stored_field->id_html, $ord["urutan"]) ){
						$this->kuesioner_field_m->delete_kuesioner_field_by_condition($stored_field->id_html, $id_section, $id_kuesioner);


						// update json fields
						$this->db->where('id', $id_section);
				    	$data_section = $this->db->get('default_kuesioner_kuesioner_section');
				    	$kuesioner = $data_section->row_array();
				    	$fields = json_decode($kuesioner['fields'], true);
				    	$keys = NULL;
				    	foreach ($fields['urutan'] as $key => $field) {
				    		if($field == $stored_field->id_html){
				    			unset($fields['urutan'][$key]);
				    			$keys = $key;
				    		}
				    	}
				    	$fields['urutan'] = array_values($fields['urutan']);
				    	unset($fields['type'][$keys]);
				    	$fields['type'] = array_values($fields['type']);
				    	$jml = $fields['jumlah'][0];
				    	$fields['jumlah'][0] = $jml-1;
				    	$ins['fields'] = json_encode($fields);
						$res_update = $this->kuesioner_section_m->update_kuesioner_section($ins, $id_section);
					}
				}

				// check if field already stored
				$temp = $this->kuesioner_field_m->get_kuesioner_field_by_condition($id_kuesioner,$id_page,$id_section,$ind);
                
                if($temp != null){
                	$fields_val = array(
                		'options' => $attrib,
                		'type' => $ord["type"][$i],
                		'required' => (int)$opt["id".$ind]["required"][0],
                		'conditional_logic' => $cl_attrib,
                	);
                	$this->kuesioner_field_m->update_kuesioner_field_by_section_id($fields_val, $id_section, $ind);
                }else{
                	$fields_val = array(
                		'kuesioner_id' => $id_kuesioner,
                		'page_id' => $id_page,
                		'section_id' => $id_section,
                		'id_html' => $ind,
                		'type' => $ord["type"][$i],
                		'options' => $attrib,
                		'required' => (int)$opt["id".$ind]["required"][0],
                		'conditional_logic' => $cl_attrib,
                	);
                	$this->kuesioner_field_m->insert_kuesioner_field($fields_val);
                }
            }
            
            $values = array(
            	'title' => $title,
            	'deskripsi' => $description,
            	'fields' => $order,
            	'section_options' => $sections,
            	'conditional_logic' => $cl_section,
            );
            $this->kuesioner_section_m->update_kuesioner_section($values,$id_section);

            redirect('admin/kuesioner/kuesioner_page/edit/'.$id_kuesioner.'/'.$id_page);
			
		}

		$data = array();
        $data['records']= $this->kuesioner_section_m->get_kuesioner_section_by_id_result($id_section);
        $orwhere = array(
            'type'=>'dropdown',
            'type'=>'radio',
            'type'=>'checkbox'
        );

		$data['allfields'] = $this->kuesioner_section_m->get_all_field_by_condition($id_kuesioner,$id_page);

		$data['allfields_cl_section'] = $this->kuesioner_section_m->get_all_field_option_by_condition($id_kuesioner,$id_page,$id_section);
		
        $urutan = "";
        foreach($data['records'] as $dt){
            $urutan = json_decode($dt->fields,true);
        }
        $data["questions_fields"]= array();
        for($j=0;$j<$urutan["jumlah"][0];$j++){
        	$temp = $this->kuesioner_field_m->get_field_by_order($id_section,$urutan["urutan"][$j]);

            array_push($data["questions_fields"],$temp);
        }
        
        $kuesioner_name = $this->kuesioner_m->get_kuesioner_by_id($id_kuesioner);
        $data['kuesioner_name']=$kuesioner_name['title'];
        
        $page_name = $this->kuesioner_page_m->get_kuesioner_page_by_id($id_page);
        $data['page_name'] = $page_name['title'];
       
        $data["id_kuesioner"]=$id_kuesioner;
        $data["id_page"]=$id_page;
        $data["id_section"]=$id_section;

		$data['fields'] = $this->kuesioner_section_m->get_kuesioner_section_by_id($id_section);
		$data['mode'] = 'edit';
		$data['return'] = 'admin/kuesioner/kuesioner_page/edit/'.$data['fields']['kuesioner_id'].'/'.$data['fields']['page_id'];
		$data['entry_id'] = $id;

		$db_fields = $this->kuesioner_field_m->get_user_field();
		$data['db_fields'] = $db_fields;
		
		//print_r($data['db_fields']);
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_section:edit'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:list'), '/admin/kuesioner/kuesioner/index')
			->set_breadcrumb($data['kuesioner_name'], 'admin/kuesioner/kuesioner/edit/'.$id_kuesioner)
			->set_breadcrumb($data['page_name'], 'admin/kuesioner/kuesioner_page/edit/'.$id_kuesioner.'/'.$id_page)
			->set_breadcrumb($data['fields']['title'], 'admin/kuesioner/kuesioner_section/edit/'.$id_kuesioner.'/'.$id_page.'/'.$id_section)
			->build('admin/kuesioner_section_form_edit', $data);
    }
	/*if($this->_update_kuesioner_section('edit', $id)){	
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_section:submit_success'));				
				redirect('admin/kuesioner/kuesioner_section/index');
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_section:submit_failure');
			}*/

	/**
     * Menghapus section kuesioner
     * 
     * Fungsi ini akan menghapus data pada tabel kuesioner_section berdasrakan $id yang diterima
     * @param int $id id section kuesioner
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_section') AND ! group_has_role('kuesioner', 'delete_own_kuesioner_section')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_section')){
			$entry = $this->kuesioner_section_m->get_kuesioner_section_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Delete entry
		// -------------------------------------
		$query = $this->kuesioner_section_m->get_kuesioner_section_by_id($id);

		//print_r($query);
        $this->kuesioner_section_m->delete_kuesioner_section_by_id($id);

        $this->db->where('id', $query['page_id']);
    	$data_section = $this->db->get('default_kuesioner_kuesioner_page');
    	$kuesioner = $data_section->row_array();
    	$sections = json_decode($kuesioner['sections'], true);
    	foreach ($sections['urutan'] as $key => $section) {
    		if($section == $id){
    			unset($sections['urutan'][$key]);
    		}
    	}
    	$sections['urutan'] = array_values($sections['urutan']);
    	$jml = $sections['jumlah'][0];
    	$sections['jumlah'][0] = $jml-1;
    	$ins['sections'] = json_encode($sections);

		$res_update = $this->kuesioner_page_m->update_kuesioner_page($ins, $query['page_id']);

        $this->session->set_flashdata('error', lang('kuesioner:kuesioner_section:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('admin/kuesioner/kuesioner_page/edit/'.$query['kuesioner_id'].'/'.$query['page_id']);
    }
	
	/**
     * Insert atau update data section kuesioner di database
     *
     * Fungsi ini meneruskan proses perubahan data ke database
     * @param   string $method method untuk update data didatabase ('new' or 'edit'). Method ini dikirim dari fungsi create dan edit.
	 * @param   int $row_id id section kuesioner (jika method = edit).
     * @return	boolean
     */
	private function _update_kuesioner_section($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('title', lang('kuesioner:kuesioner_section:title'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->kuesioner_section_m->insert_kuesioner_section($values);
				$last_id = $this->db->insert_id();
				$kuesioner = $this->kuesioner_page_m->get_kuesioner_page_by_id($values['page_id']);
				$sections = json_decode($kuesioner['sections'], true);
				if(!$sections){
					$sections = array();
				}
				$sections['urutan'][] = $last_id;
				$sections['jumlah'][0] = count($sections['urutan']);
				$ins['sections'] = json_encode($sections);
				$result = $this->kuesioner_page_m->update_kuesioner_page($ins, $values['page_id']);
				
			}
			else
			{
				$result = $this->kuesioner_section_m->update_kuesioner_section($values, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}