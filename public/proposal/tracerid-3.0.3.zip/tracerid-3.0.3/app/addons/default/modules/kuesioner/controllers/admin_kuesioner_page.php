<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Controller Admin_kuesioner_page
 *
 * @version     1.0.0
 * @copyright   Copyright (c) 2010 Nuesto Technology
 * @package   TracerStudy\Kuesioner\Controllers
 */
class Admin_kuesioner_page extends Admin_Controller
{
	// -------------------------------------
    // This will set the active section tab
	// -------------------------------------
	
    protected $section = 'kuesioner_page';

    public function __construct()
    {
        parent::__construct();

		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'access_kuesioner_page_backend')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Load everything we need
		// -------------------------------------

        $this->lang->load('kuesioner');		
        $this->load->model('kuesioner_m');
		$this->load->model('kuesioner_page_m');
		$this->load->model('kuesioner_section_m');
    }

    /**
     * Menambah halaman kuesioner
     *
     * Fungsi ini akan memproses penambahan halaman baru.
     * @return	void
     */

    public function create()
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'create_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			if($this->_update_kuesioner_page('new')){	
				$id = $this->input->post('kuesioner_id');
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_page:submit_success'));				
				//redirect('admin/kuesioner/kuesioner_page/index');
				redirect('admin/kuesioner/kuesioner/edit/'.$id);
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_page:submit_failure');
			}
		}
		
		$data['mode'] = 'new';
		$data['return'] = 'admin/kuesioner/kuesioner_page/index';
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_page:new'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:plural'), '/admin/kuesioner/kuesioner_page/index')
			->set_breadcrumb(lang('kuesioner:kuesioner_page:new'))
			->build('admin/kuesioner_page_form', $data);
    }
	
	/**
     * Mengedit halaman kuesioner
     *
     * Fungsi ini akan menampilkan form edit halaman kuesioner yang akan terisi oleh data halaman kuesioner berdasarkan $id yang diterima dan menampilkan daftar section kuesioner dari halaman kuesioner tersebut.
     * @param  int $id id kuesioner page
     * @param  int $id_kuesioner id kuesioner
     * @param  int $id_page id kuesioner page
     * @return	void
     */
    public function edit($id = 0)
    {
        // -------------------------------------
		// Check permission
		// -------------------------------------
		$id_kuesioner = (int) $this->uri->segment(5);
        $id_page = (int) $this->uri->segment(6);

		$pagination_config['base_url'] = base_url(). 'admin/kuesioner/kuesioner/index';
		$pagination_config['uri_segment'] = 5;
		$pagination_config['total_rows'] = $this->kuesioner_page_m->count_all_kuesioner_page();
		$pagination_config['per_page'] = Settings::get('records_per_page');
		$this->pagination->initialize($pagination_config);
		$data['pagination_config'] = $pagination_config;

		if(! group_has_role('kuesioner', 'edit_all_kuesioner_page') AND ! group_has_role('kuesioner', 'edit_own_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'edit_all_kuesioner_page')){
			$entry = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
		// -------------------------------------
		// Process POST input
		// -------------------------------------
		
		if($_POST){
			//echo $this->input->post('hidden_cl_page');
			if($this->_update_kuesioner_page('edit', $id_page)){
				$query = $this->kuesioner_page_m->get_kuesioner_page_by_id($id_page);
				$result = $query['kuesioner_id'];
				//print_r($result['kuesioner_id']);
				$this->session->set_flashdata('success', lang('kuesioner:kuesioner_page:submit_success'));				
				redirect('admin/kuesioner/kuesioner/edit/'.$result);
			}else{
				$data['messages']['error'] = lang('kuesioner:kuesioner_page:submit_failure');
			}
		}

        $data['records'] = $this->kuesioner_page_m->get_records($id_page);

        $kuesioner_name = $this->kuesioner_m->get_kuesioner_by_id($id_kuesioner);
        
        $data['kuesioner_name'] = $kuesioner_name['title'];
    
        
        $orwhere = array(
            'type'=>'dropdown',
            'type'=>'radio',
            'type'=>'checkbox'
        );

        // get order of page for current kuesioner
        $temp_page_json = $this->kuesioner_m->get_pages($id_kuesioner);
		$pages_json = $temp_page_json['pages'];
		if($pages_json != 0){
			$pages = json_decode($pages_json);
			$pages_order = $pages->urutan;

			// get previous pages
			$prev_pages = array();
			foreach($pages_order as $prev_page_id){
				if($prev_page_id == $id_page){
					break;
				}
				$prev_pages[] = $prev_page_id;
			}

			$page_restrict_query = '';
			if(count($prev_pages) > 0){
				$page_restrict_query_arr = array();
				foreach($prev_pages as $prev_page){
					$page_restrict_query_arr[] = 'default_kuesioner_kuesioner_page.id = '.$prev_page;
				}
				$page_restrict_query = 'AND ('.implode(' OR ', $page_restrict_query_arr).')';
			}
		}else{
			$page_restrict_query = '';
		}
		
		$data['allfields'] = $this->kuesioner_page_m->get_all_section_by_condition($id_kuesioner, $page_restrict_query);

		$temp = array();

        foreach ($data['records'] as $dt){
            $temp = json_decode($dt->sections, true);
        }
        
        $temp_section = array();

        if($temp == null || $temp == ""){
        	$query = $this->kuesioner_section_m->get_all_section_by_id($id_page);
	        foreach ($query as $q){
                if(!(in_array($q, $temp_section))){
                	array_push($temp_section,$q);
                }
            }
        }else{
        	for($i=0;$i<$temp["jumlah"][0];$i++){
	            $temp_urutan = $temp["urutan"][$i];

	            $query = $this->kuesioner_section_m->get_section_by_order($temp_urutan, $id_kuesioner);
	            foreach ($query as $q){
	                array_push($temp_section,$q);
	            }
	        }
	        $query = $this->kuesioner_section_m->get_all_section_by_id($id_page);
	        foreach ($query as $q){
                if(!(in_array($q, $temp_section))){
                	array_push($temp_section,$q);
                }
            }
        }
        $data['sections'] = $temp_section;

		$data['total'] = count($data['sections']);
		$data['fields'] = $this->kuesioner_page_m->get_kuesioner_page_by_id($id_page);

		$data['mode'] = 'edit';
		$data['return'] = 'admin/kuesioner/kuesioner/edit/'.$data['fields']['kuesioner_id'];
		$data['entry_id'] = $id;
		$data['pagination'] = $this->pagination->create_links();
		$data['id_page'] = $id_page;

		$data['id_kuesioner'] = $id_kuesioner;
        $data['id_page'] = $id_page;
        
		
		// -------------------------------------
		// Build the form page.
		// -------------------------------------
		
        $this->template->title(lang('kuesioner:kuesioner_page:edit'))
			->set_breadcrumb('Home', '/admin')
			->set_breadcrumb(lang('kuesioner:kuesioner:list'), '/admin/kuesioner/kuesioner/index')
			->set_breadcrumb($kuesioner_name['title'], 'admin/kuesioner/kuesioner/edit/'.$id_kuesioner)
			->set_breadcrumb($data['fields']['title'], 'admin/kuesioner/kuesioner_page/edit/'.$id_kuesioner.'/'.$id_page)
			->build('admin/kuesioner_page_form_edit', $data);
    }
	
	/**
     * Menghapus halaman kuesioner
     * 
     * Fungsi ini akan menghapus data pada tabel kuesioner_page berdasrakan $id yang diterima
     * @param int $id id halaman kuesioner
     * @return  void
     */
    public function delete($id = 0)
    {
		// -------------------------------------
		// Check permission
		// -------------------------------------
		
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_page') AND ! group_has_role('kuesioner', 'delete_own_kuesioner_page')){
			$this->session->set_flashdata('error', lang('cp:access_denied'));
			redirect('admin');
		}
		// Check view all/own permission
		if(! group_has_role('kuesioner', 'delete_all_kuesioner_page')){
			$entry = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);
			$created_by_user_id = $entry['created_by'];
			if($created_by_user_id != $this->current_user->id){
				$this->session->set_flashdata('error', lang('cp:access_denied'));
				redirect('admin');
			}
		}
		
        $result = $this->kuesioner_page_m->get_kuesioner_page_by_id($id);

		// -------------------------------------
		// Delete entry
		// -------------------------------------
		
        $this->kuesioner_page_m->delete_kuesioner_page_by_id($id);
        
    	$this->db->where('id', $result['kuesioner_id']);
    	$query = $this->db->get('default_kuesioner_kuesioner');
    	$kuesioner = $query->row_array();
    	$pages = json_decode($kuesioner['pages'], true);
    	foreach ($pages['urutan'] as $key => $page) {
    		if($page == $id){
    			unset($pages['urutan'][$key]);
    		}
    	}
    	$pages['urutan'] = array_values($pages['urutan']);
    	$jml = $pages['jumlah'][0];
    	$pages['jumlah'][0] = $jml-1;
    	$ins['pages'] = json_encode($pages);

		$res_update = $this->kuesioner_m->update_kuesioner($ins, $kuesioner['id']);
        $this->session->set_flashdata('error', lang('kuesioner:kuesioner_page:deleted'));
 
		// -------------------------------------
		// Redirect
		// -------------------------------------
		
        redirect('admin/kuesioner/kuesioner/edit/'.$result['kuesioner_id']);
    }
	
	/**
     * Insert atau update data halaman kuesioner di database
     *
     * Fungsi ini meneruskan proses perubahan data ke database
     * @param   string $method method untuk update data didatabase ('new' or 'edit'). Method ini dikirim dari fungsi create dan edit.
	 * @param   int $row_id id halaman kuesioner (jika method = edit).
     * @return	boolean
     */
	private function _update_kuesioner_page($method, $row_id = null)
 	{
 		// -------------------------------------
		// Load everything we need
		// -------------------------------------
		
		$this->load->helper(array('form', 'url'));
		
 		// -------------------------------------
		// Set Values
		// -------------------------------------
		
		$values = $this->input->post();

		// -------------------------------------
		// Validation
		// -------------------------------------
		
		// Set validation rules
		$this->form_validation->set_rules('title', lang('kuesioner:kuesioner_page:title'), 'required');
		$this->form_validation->set_rules('deskripsi', lang('kuesioner:kuesioner_page:deskripsi'), 'required');
		
		// Set Error Delimns
		$this->form_validation->set_error_delimiters('<div>', '</div>');
		
		$result = false;

		if ($this->form_validation->run() === true)
		{
			if ($method == 'new')
			{
				$result = $this->kuesioner_page_m->insert_kuesioner_page($values);
				$last_id = $this->db->insert_id();
				$kuesioner = $this->kuesioner_m->get_kuesioner_by_id($values['kuesioner_id']);
				$pages = json_decode($kuesioner['pages'], true);
				if(!$pages){
					$pages = array();
				}
				$pages['urutan'][] = $last_id;
				$pages['jumlah'][0] = count($pages['urutan']);
				$ins['pages'] = json_encode($pages);
				$result = $this->kuesioner_m->update_kuesioner($ins, $values['kuesioner_id']);
			}
			else
			{	
				$title = $this->input->post('title');
	            $description = $this->input->post('deskripsi');
	            $section = $this->input->post('sections');
	            $cl_page = $this->input->post('hidden_cl_page');
	            
	            $input= array(
	                'title' => $title,
	                'deskripsi' => $description,
	                'sections' => $section,
	                'conditional_logic'=>$cl_page
	            );
				if($this->input->post('sections') == ""){
					$sections = $this->kuesioner_page_m->get_sections($row_id);
					$input['sections'] = $sections['sections'];
				}
				$result = $this->kuesioner_page_m->update_kuesioner_page($input, $row_id);
			}
		}
		
		return $result;
	}

	// --------------------------------------------------------------------------

}