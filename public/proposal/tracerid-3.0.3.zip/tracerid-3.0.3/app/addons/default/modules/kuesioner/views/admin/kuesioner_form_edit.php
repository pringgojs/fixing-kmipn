<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/reveal.css" />
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery-ui.css" />
<link rel="stylesheet" href="<?php echo base_url();?>system/cms/themes/ace/css/jquery/jquery.ui.theme.css" />

<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-1.9.0.min.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery-ui-1.10.1.custom.js"></script>
<script src="<?php echo base_url();?>system/cms/themes/ace/js/jquery.reveal.js"></script>	

<script>
	jq = jQuery.noConflict(true);
	var fields_sum = 1;
</script>

<div class="page-header">
	<h1><?php echo lang('kuesioner:kuesioner:'.$mode); ?></h1>
</div>

<?php echo form_open_multipart(uri_string()); ?>

<div class="form-horizontal">

	<?php 
		$value = NULL;
		if($this->input->post('id') != NULL){
			$value = $this->input->post('id');
		}elseif($mode == 'edit'){
			$value = $fields['id'];
		}
	?>
	<input name="id" type="hidden" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="title"><?php echo lang('kuesioner:title'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('title') != NULL){
					$value = $this->input->post('title');
				}elseif($mode == 'edit'){
					$value = $fields['title'];
				}
			?>
			<input name="title" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />
			
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:deskripsi'); ?></label>

		<div class="col-sm-10">
			<?php 
				$value = NULL;
				if($this->input->post('deskripsi') != NULL){
					$value = $this->input->post('deskripsi');
				}elseif($mode == 'edit'){
					$value = $fields['deskripsi'];
				}
			?>
			<textarea name="deskripsi" class="col-xs-10 col-sm-5" id="" ><?php echo $value; ?></textarea>
			<!--<input name="deskripsi" type="text" value="<?php echo $value; ?>" class="col-xs-10 col-sm-5" id="" />-->
			
			
		</div>
	</div>

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="conditional_logic"><?php echo lang('kuesioner:conditional_logic'); ?></label>

		<div class="col-sm-10">
			<div class="input">
		        <input type="checkbox" name="kuesioner_CL_page" id="CL_page" <?php if($fields['conditional_logic'] != ''){echo "checked";}?>>
		    </div>
		</div>
	</div>

	<div class="clearfix">
	    <div class="CLpanel">
	    	<ul id = 'field'>
		    		<?php if($fields['conditional_logic'] != ''){
		    			$con_log = json_decode($fields['conditional_logic']);
		    			$opt = $con_log->options;
		    			$i = 0;
		    			foreach ($opt as $key => $opt_value) {
		    		?>
		    		<li style="list-style-type:none">
		    			<select class="page_conditional" name="page_conditional" style="padding-right=5px;">
		    				<?php foreach ($allfields as $key => $value) { ?>
		    					<option value='<?php echo $value; ?>' <?php if($value == $opt_value){echo 'selected';}?>><?php echo $value; ?></option>
		    				<?php } ?>
		    			</select>	
		    			<select class="is_not" name="is_not" style="min-width: 0em">
		    				<option value="is" <?php if($con_log->isnot[$i]=="is"){echo "selected";}?>>Is</option>
		                	<option value="is_not" <?php if($con_log->isnot[$i]=="is_not"){echo "selected";}?>>Is Not</option>
		            	</select>	
		            	<div class="val_change">
			    			<?php if($opt_value == 'email' || $opt_value == 'username' || $opt_value == 'display_name' || $opt_value == 'academic_nim' || $opt_value == 'street_1' || $opt_value == 'street_2' ||$opt_value == 'city'  || $opt_value == 'state_code' || $opt_value == 'zipcode' || $opt_value == 'academic_ipk'){ ?>
			    				<input type='text' class='option_value' value='<?php echo $con_log->value[$i]; ?>'>
			    			<?php }elseif ($opt_value == "academic_faculty") { ?>
				    			<select class='option_value'>
									<?php foreach ($all_fakultas as $fakultas) { ?>
										<option value='<?php echo $fakultas['unit_abbrevation']; ?>'  <?php if($con_log->value[$i] == $fakultas['unit_abbrevation']){echo "selected";} ?> ><?php echo $fakultas['unit_name']; ?></option>
									<?php }?>
				        		</select>
			    			<?php }elseif($opt_value == "academic_year"){ ?>
			    				<select class='option_value'>
			    					<?php for($j=2000;$j<=2015;$j++){?>
			    						<option value="<?php echo $j; ?>" <?php if($j == $con_log->value[$i]){echo "selected"; }?>><?php echo $j; ?></option>
			    					<?php } ?>
			    				</select>
			    			<?php }elseif($opt_value == "group_id") {?>
				    			<select class='option_value'>
				    				<?php foreach ($groups as $value) {?>
										<option value="<?php echo $value["id"]; ?>" <?php if($value['id'] == $con_log->value[$i]){echo "selected"; }?>><?php echo $value["description"]; ?></option>'
									<?php } ?>
								</select>
			    			<?php }elseif ($opt_value == 'academic_program') { ?>
			    				<select class="option_value">
									<?php foreach ($all_prodi as $prodi) { ?>
										<option value='<?php echo $prodi['unit_name']; ?>'  <?php if($con_log->value[$i] == $prodi['unit_name']){echo "selected";} ?> ><?php echo $prodi['unit_name']; ?></option>
									<?php }?>	
								</select>
			    			<?php } ?>
		    			</div>
		    		
		    		<a href="#" class="addCL">Add</a>
			    	<?php 
			    		if($i > 0){ ?>
			    			<a href="#" class="removeCL">Remove</a>
			    	</li>
			    	<?php	} $i++; 
			    	}
			    	}else{ 
			    		if(is_array($allfields) AND count($allfields) > 0){ ?> 
					    	<li id='1' class='1' style="list-style-type:none">
					    		<select class="page_conditional" style="min-width:0em; max-width: 25em;">
					    			<?php foreach ($allfields as $key => $value) { ?>
					    				<option value='<?php echo $value; ?>'><?php echo $value; ?></option>
					    			<?php } ?>
						    		</select>

						    	<select class="is_not">
						    		<option value="is">Is</option>
						    		<option value="is_not">Is Not</option>
						    	</select>
						    	<div class="val_change">
								</div>
								<a href="#" class="addCL">Add</a>
						    </li>
				    <?php }} ?>
			</ul>
	    </div>
	</div>

	<input type="hidden" name="conditional_logic" id="conditional_logic">
	<input type="hidden" name="pages_attr" id="pages_attr">
	<?php 
		$value = NULL;
		if($this->input->post('pages') != NULL){
			$value = $this->input->post('pages');
		}elseif($mode == 'edit'){
			$value = $fields['pages'];
		}
	?>
	<input type="hidden" name="pages" id="pages" style="width:500px;" >
</div>

<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">

		<button type="submit" class="btn btn-primary" id="submit_edit"><span><?php echo lang('buttons:save'); ?></span></button>
		<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>
	</div>
</div>

<?php echo form_close();?>
<a href="#" id="btn_add_halaman">Tambah Halaman</a>

<form action="<?php echo base_url().'admin/kuesioner/kuesioner_page/create'; ?>" method="post" id="add_halaman" onsubmit="popup(this); return false;" >
<div class="form-horizontal">
<center><h1>Add Page</h1></center>
<hr>
	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="title"><?php echo lang('kuesioner:title'); ?></label>

		<div class="col-sm-10"> 
			<input name="title" id="title" type="text" class="col-xs-10 col-sm-5" required/>
			
		</div>
	</div>

	
	<input name="kuesioner_id" type="text" value="<?php echo $fields['id']; ?>" class="col-xs-10 col-sm-5" id="" hidden=true/>
		

	<div class="form-group">
		<label class="col-sm-2 control-label no-padding-right" for="deskripsi"><?php echo lang('kuesioner:deskripsi'); ?></label>
		<div class="col-sm-10">
			<input name="deskripsi" id="deskripsi" type="text" class="col-xs-10 col-sm-5" required/>
		</div>
	</div>
</div>
<div class="clearfix form-actions">
	<div class="col-md-offset-3 col-md-9">
		<center>
			<button class="btn btn-primary" id="entry_halaman" onclick="validateForm()"><span><?php echo lang('buttons:save'); ?></span></button>
			<!--<a href="<?php echo site_url($return); ?>" class="btn btn-danger"><?php echo lang('buttons:cancel'); ?></a>-->
		</center>
	</div>
</div>
</form>
<script>
	$("#add_halaman").dialog({
	    autoOpen: false,
	    show: 'slide',
	    resizable: false,
	    position: 'center',
	    stack: true,
	    height: 'auto',
	    width: 'auto',
	    modal: true
	});
	$("#btn_add_halaman").click(function(e){
		$("#add_halaman").dialog({
			autoOpen: true,
			width: '450px',
			height: 'auto',
		});
	});
</script>

<?php if ($pages != null): ?>
	
<p class="pull-right"><?php echo lang('kuesioner:showing').' '.count($pages).' '.lang('kuesioner:of').' '.$total ?></p>
	
<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>
				<th>Page ID</th>
				<th><?php echo lang('kuesioner_page:title'); ?></th>
				<!--<th><?php echo lang('kuesioner:kuesioner_id'); ?></th>-->
				<th><?php echo lang('kuesioner_page:deskripsi'); ?></th>
				<!--<th><?php echo lang('kuesioner:sections'); ?></th>-->
				<th><?php echo lang('kuesioner_page:conditional_logic'); ?></th>
				<th><?php echo "Num of Section";?></th>
				<th><?php echo "Action"; ?></th>
				<!--<th><?php echo lang('kuesioner:created'); ?></th>
				<th><?php echo lang('kuesioner:updated'); ?></th>
				<th><?php echo lang('kuesioner:created_by'); ?></th>-->
			</tr>
		</thead>
		<tbody>
			<?php 
			$cur_page = (int) $this->uri->segment($pagination_config['uri_segment']);
			if($cur_page != 0){
				$item_per_page = $pagination_config['per_page'];
				$no = (($cur_page -1) * $item_per_page) + 1;
			}else{
				$no = 1;
			}
			?>
			
			<?php foreach ($pages as $kuesioner_page_entry => $val): ?>
			<tr>
				<td class="id_page"><?php echo $val->id; ?></td>
				<td><?php echo $val->title; ?></td>
				<td><?php echo $val->deskripsi; ?></td>
				<!--<td><?php echo $val->sections; ?></td>-->
				<td><?php
            $cl = json_decode($val->conditional_logic,true);
            if ($cl['options'][0] != null) {
                $td = $cl["show"][0]." if ".$cl["any"][0]."\n";
                for($i=0;$i<count($cl["options"]);$i++){
                    list($p_id,$s_id,$id_h)=explode("_",$cl["options"][$i]);
                    $td = $td."Page ".$p_id." Section ".$s_id." Question ".$id_h.": ".$cl["op_labels"][$i]." ".$cl["isnot"][$i]." ".$cl["val_labels"][$i]."\n";
                }
                echo nl2br($td);
            } else {
                echo "none";
            }
                ?></td>
				<td>
					<?php
						$this->db->where('page_id', $val->id);
						$this->db->from('default_kuesioner_kuesioner_section');
						echo $this->db->count_all_results();
					?>
				</td>
				<td class="actions">
				<button href="<?php echo current_url() . '#'; ?>" class="btn btn-xs btn-grey" id="up" type="submit">Up</button>
	            <button href="<?php echo current_url() . '#'; ?>" class="btn btn-xs btn-grey" id="down" type="submit">Down</button>
				<!--<?php 
				if(group_has_role('kuesioner', 'view_all_kuesioner_page')){
					echo anchor('admin/kuesioner/kuesioner_page/view/' . $val->id, lang('global:view'), 'class="btn btn-xs btn-info view"');
				}elseif(group_has_role('kuesioner', 'view_own_kuesioner_page')){
					if($kuesioner_page_entry['created_by']['user_id'] == $this->current_user->id){
						echo anchor('admin/kuesioner/kuesioner_page/view/' . $val->id, lang('global:view'), 'class="btn btn-xs btn-info view"');
					}
				}
				?>-->
				<?php 
				if(group_has_role('kuesioner', 'edit_all_kuesioner_page')){
					echo anchor('admin/kuesioner/kuesioner_page/edit/' .$fields['id'].'/'. $val->id, lang('global:edit'), 'class="btn btn-xs btn-info edit"');
				}elseif(group_has_role('kuesioner', 'edit_own_kuesioner_page')){
					if($kuesioner_page_entry['created_by']['user_id'] == $this->current_user->id){
						echo anchor('admin/kuesioner/kuesioner_page/edit/' . $fields['id'].'/'. $val->id, lang('global:edit'), 'class="btn btn-xs btn-info edit"');
					}
				}
				?>
				<?php 
				if(group_has_role('kuesioner', 'delete_all_kuesioner_page')){
					echo anchor('admin/kuesioner/kuesioner_page/delete/' . $val->id, lang('global:delete'), array('class' => 'confirm btn btn-xs btn-danger delete'));
				}elseif(group_has_role('kuesioner', 'delete_own_kuesioner_page')){
					if($kuesioner_page_entry['created_by']['user_id'] == $this->current_user->id){
						echo anchor('admin/kuesioner/kuesioner_page/delete/' . $val->id, lang('global:delete'), array('class' => 'confirm btn btn-xs btn-danger delete'));
					}
				}
				?>
				</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<!-- <?php echo $pagination; ?> -->
	<?php else: ?>
	<div class="well"><?php echo lang('kuesioner:kuesioner_page:no_entry'); ?></div>
<?php endif;?>

<script type="text/javascript">
	
    function addpage(anu){
        var row = anu.parents("tr:first");
        if (anu.is("#up")) {
            row.insertBefore(row.prev());
        } else {
            row.insertAfter(row.next());
        }
    }
    function deletepage(anu){
        // var row = anu.parents("tr:first");
        // if(anu.is(".delete")){
        //     row.remove();
        // }
    }
    
    function save_row_list(){
        var pages_attr = {};
        pages_attr['urutan'] = [];
        pages_attr['jumlah'] = [];
        jq(".id_page").each(function(){
            var id = jq(this).text();
            pages_attr['urutan'].push(id);
        });
        pages_attr['jumlah'].push(pages_attr['urutan'].length);
        
        var data = JSON.stringify(pages_attr);
        jq("#pages").val(data);
        //jq("#page_attr").val(data);
    }

    function save_CL_page(){
        var CL_page = {};
        CL_page["options"] = [];
        CL_page["isnot"] = [];
        CL_page["value"] = [];
        var data = "";
        if(jq("#CL_page").is(":checked")){
            jq(".page_conditional").each(function(){
               CL_page["options"].push(jq(this).find(":selected").val());
            });
            jq(".is_not").each(function(){
               CL_page["isnot"].push(jq(this).val()); 
            });
            
            jq(".option_value").each(function(){
               CL_page["value"].push(jq(this).val()); 
            });
            
            data = JSON.stringify(CL_page);
            jq("#conditional_logic").val(data);
        }
		return false;
    }

    function addCL(){
    	var id = ++fields_sum;
        var shows = '<li id='+id+' style="list-style-type:none"><select class="CL2 page_conditional" style="min-width:0em; max-width: 25em;">'
        	+ '<?php foreach ($allfields as $af): ?><option value=<?php echo $af?>><?php echo $af?></option>'
        	+ '<?php endforeach; ?>'
        	+ '</select>&nbsp;<select class="is_not"><option value="is">Is</option><option value="is_not">Is Not</option></select>&nbsp;<div class="val_change"></div></li>';
        var add_remove = ' <a href=# class="addCL">Add</a> <a href="#" class="removeCL">Remove</a>';
        //var newCLpanel = jq('<div class="input">'+shows+add_remove+'</div>');
        var newCLpanel = jq('<div class="input">'+shows+add_remove+'</div>');
        //jq('.CLpanel').append(newCLpanel);
        jq(".CLpanel ul").append(newCLpanel);
        newCLpanel.find(".addCL,.removeCL").click(function(event){
            if(jq(this).is(".addCL")){
            	event.preventDefault();
                addCL();
            }
            else{
                event.preventDefault();
                jq(this).parent().remove();  
            } 
        });
    }

    function removeCL(anu){
        anu.parent().remove();  
    }
       
    jq(document).ready(function(){
    	jq(".CLpanel").hide();
	    jq("#CL_page").click(function(){
	        if(jq(this).is(':checked')){
	            jq(".CLpanel").show();
	        }else{
	            jq(".CLpanel").hide();
	        }
	    });
	    jq("#CL_page").each(function(){
	        if(jq(this).is(':checked')){
	            jq(".CLpanel").show();
	        }else{
	            jq(".CLpanel").hide();
	        }
	    });
	    jq("#submit_edit").click(function(){
            save_CL_page();
        });
	    jq(".addCL").click(function(event){
	    	event.preventDefault();
            addCL();
        });
        jq(".removeCL").click(function(event){
            event.preventDefault();
			jq(this).parent().remove();
        });
        jq("#up,#down").click(function(){
            addpage(jq(this));
            save_row_list();
        });
        jq(".delete").click(function(){
            deletepage(jq(this)); 
        });
        jq('.tambah').click(function(e) {
            e.preventDefault();
            jq('#myModal').reveal();
        });

        jq('#field').on('change','.page_conditional',function(){
        	//alert($(this).closest('li').children().length);
        	if($(this).closest('li').children().length > 2){
        		$(this).closest('li').find('.option_value').remove();
        	}

        	if($(this).val() == 'email' || $(this).val() == 'username' || $(this).val() == 'display_name' || $(this).val() == 'academic_nim' || $(this).val() == 'street_1' || $(this).val() == 'street_2' || $(this).val() == 'city'  || $(this).val() == 'state_code' || $(this).val() == 'zipcode'  || $(this).val() == 'academic_ipk'){
        		var value = '<input type="text" class="option_value">';
        	}else if($(this).val() == 'academic_faculty'){
        		var value = '<select class="option_value">'
        			<?php foreach ($all_fakultas as $fakultas) { ?>
						+'<option value="<?php echo $fakultas["unit_abbrevation"]; ?>"><?php echo $fakultas["unit_name"]; ?></option>'
					<?php }?>
        			+ '</select>';
			}else if($(this).val() == 'group_id'){
				var value = '<select class="option_value">'
					<?php foreach ($groups as $value) {?>
						+ '<option value="<?php echo $value["id"]; ?>"><?php echo $value["description"]; ?></option>'
					<?php } ?>
					+ '</select>';
			}else if($(this).val() == 'academic_year'){
				var value = '<select class="option_value">'
					<?php for($i=2000;$i<=2015;$i++) {?>
						+ '<option value="'+<?php echo $i; ?>+'">'+<?php echo $i; ?>+'</option>'
					<?php } ?>
					+'</select>';
			}else if($(this).val() == 'academic_program'){
				var value = '<select class="option_value">'
					<?php foreach ($all_prodi as $prodi) { ?>
						+'<option value="<?php echo $prodi["unit_name"]; ?>"><?php echo $prodi["unit_name"]; ?></option>'
					<?php }?>
					+'</select>';
			}

			$(this).closest('li').find(".val_change").append(value);	
        	
        });

        jq(".simpan, .submit_new").click(function(){
        	addpage(jq(this));
            save_row_list();
        });
    });

   	setInterval ( save_row_list, 1000 );
</script>