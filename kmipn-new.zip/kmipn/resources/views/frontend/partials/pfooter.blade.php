<footer class="footer">
    <div class="container-fluid">
        <p class="copyright pull-right">
            &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.kmipn.pens.ac.id">KMIPN 2018</a>, Teknik Informatika Politeknik Elektronika Negeri Surabaya
        </p>
    </div>
</footer>