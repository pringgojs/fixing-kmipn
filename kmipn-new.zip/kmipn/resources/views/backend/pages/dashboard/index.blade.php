@extends('backend.master')

@section('content')
<div class="page-header">
    <h2>Dashboard</h2>
</div>

            <div class="row">
            </div>
@endsection
