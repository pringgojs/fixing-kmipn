<footer class="footer text-center">
    <span>Copyright &copy; 2018 PENS</span>
</footer>
