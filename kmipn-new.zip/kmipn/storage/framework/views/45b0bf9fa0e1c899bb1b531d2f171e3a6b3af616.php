<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2>Detail Pendaftar</h2>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-block">
                <form id="example-form" action="<?php echo e(url('/ecodeeepis/pendaftaran/'.$data->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="PUT">
                    <input type="hidden" name="users_id" value="<?php echo e($data->users_id); ?>">
                    <h3>Data Ketua</h3>
                    <table class="table table-bordered">
                        <tr>
                            <td>No Mahasiswa</td>
                            <td><?php echo e($data->users->no_mahasiswa); ?></td>
                        </tr>
                        <tr>
                            <td>Nama</td>
                            <td><?php echo e($data->users->fullname); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td><?php echo e($data->users->email); ?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td><?php echo e($data->users->jenis_kelamin); ?></td>
                        </tr>
                        <tr>
                            <td>Jurusan</td>
                            <td><?php echo e($data->users->jurusan); ?></td>
                        </tr>
                        <tr>
                            <td>Tempat/Tgl Lahir</td>
                            <td><?php echo e($data->users->tempat_lahir); ?>/ <?php echo e(date('d-m-Y',strtotime($data->users->tgl_lahir))); ?></td>
                        </tr>
                        <tr>
                            <td>Nama Tim</td>
                            <td><?php echo e($data->nama_tim); ?></td>
                        </tr>
                        <tr>
                            <td>Asal Poltek</td>
                            <td>
                                <?php $__currentLoopData = $politeknik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if($item2->id == $data->politeknik_id): ?>
                                        <?php echo e($item2->politeknik); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Foto KTM Ketua</td>
                            <td>
                            <?php if(empty($data->users->photo)): ?>
                                Belum Upload Foto KTM
                            <?php else: ?> 
                                <?php if(file_exists(public_path('ktm/'.$data->users->photo))): ?>
                                    <img src="<?php echo e(url('ktm/'.$data->users->photo)); ?>" id="preview-image" width="500">
                                <?php endif; ?> 
                            <?php endif; ?>
                            </td>
                        </tr>
                    </table>

                    <?php if($user_count > 1): ?>
                            <h3>Data Anggota</h3>
                            <table class="table table-bordered">
                                <?php $index = 2; ?>
                                <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td>No Mahasiswa</td>
                                        <td><?php echo e($item->no_mahasiswa); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nama</td>
                                        <td><?php echo e($item->fullname); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td><?php echo e($item->email); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jenis Kelamin</td>
                                        <td><?php echo e($item->jenis_kelamin); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jurusan</td>
                                        <td><?php echo e($item->jurusan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Tempat/Tgl Lahir</td>
                                        <td><?php echo e($item->tempat_lahir); ?>/ <?php echo e(date('d-m-Y',strtotime($item->tgl_lahir))); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Foto KTM</td>
                                        <td>
                                        <?php if(empty($item->photo)): ?>
                                            Belum Upload Foto KTM
                                        <?php else: ?> 
                                            <?php if(file_exists(public_path('ktm/'.$item->photo))): ?>
                                                <img src="<?php echo e(url('ktm/'.$item->photo)); ?>" id="preview-image" width="500">
                                            <?php endif; ?> 
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Anggota Ke</td>
                                        <td><?php echo e($index); ?></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php $index++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </table>
                    <?php endif; ?>
                    <h3>Lain-lain</h3>
                            <table class="table table-bordered">
                                <tr>
                                    <td>File Proposal</td>
                                    <td><a href="<?php echo e(url('proposal/'.$data->file_proposal)); ?>"><?php echo e($data->file_proposal); ?></a></td>
                                </tr>
                                <tr>
                                    <td>Status</td>
                                    <td>
                                        <select class="form-control" name="status" id="" required>
                                                <?php if($data->status == 'Tahap Seleksi'): ?>
                                                    <option value="Tahap Seleksi" selected>Tahap Seleksi</option>
                                                <?php else: ?>
                                                    <option value="Tahap Seleksi">Tahap Seleksi</option>
                                                <?php endif; ?>
                                                <?php if($data->status == 'Lolos'): ?>
                                                    <option value="Lolos" selected>Lolos</option>
                                                <?php else: ?>
                                                    <option value="Lolos">Lolos</option>
                                                <?php endif; ?>
                                                <?php if($data->status == 'Tidak Lolos'): ?>
                                                    <option value="Tidak Lolos" selected>Tidak Lolos</option>
                                                <?php else: ?>
                                                    <option value="Tidak Lolos">Tidak Lolos</option>
                                                <?php endif; ?>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                            <button type="submit" name="submit" class="btn btn-success col-md-12">Save</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>