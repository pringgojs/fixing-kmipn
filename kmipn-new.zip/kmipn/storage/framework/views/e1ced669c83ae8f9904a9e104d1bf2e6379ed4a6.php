<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2>Dashboard</h2>
</div>

            <div class="row">
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>