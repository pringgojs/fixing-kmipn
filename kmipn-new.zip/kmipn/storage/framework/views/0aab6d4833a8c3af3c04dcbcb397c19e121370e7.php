<section class="hero is-transparent is-fullwidth awalan">
    <?php echo $__env->make('frontend.partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="hero-body"></div>
</section>

<?php $__env->startSection('title'); ?>
    Info - KMIPN
<?php $__env->stopSection(); ?>

<section class="hero tengah is-transparent is-fullwidth">
    <div class="hero-head">
        <div class="container has-text-centered">
            <p class="has-text-centered is-centered">
                <h3 class="title is-3 has-text-white">INFORMASI</h3>
            </p>
        </div>
    </div>
    <div class="hero-body">
        <div class="container">
            <div class="columns">
                <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="column is-4 is-white">
                    <div class="box"></div>
                    <p class="has-text-danger"><?php echo e($item->created_at); ?></p>
                    <p><?php echo e($item->title); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
        </div>
    </div>
    <div class="hero-foot">
        <div class="container is-centered">
            <nav class="pagination is-centered" role="navigation" aria-label="pagination">
                <ul class="pagination-list">
                    
                    
                    
                    
                    
                    
                    
                </ul>
            </nav>
        </div>
    </div>
</section>
<?php echo $__env->make('frontend.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('frontend.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>