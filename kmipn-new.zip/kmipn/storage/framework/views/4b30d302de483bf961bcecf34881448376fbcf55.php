<?php $__env->startSection('title', 'Anggota Tim | KMIPN 2018'); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Welcome, <?php echo e($anggota[0]->fullname); ?></a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <p class="hidden-lg hidden-md">Welcome, <?php echo e($anggota[0]->fullname); ?></p>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="<?php echo e(url('auth/logout')); ?>">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <h4 class="title">Data Anggota</h4><br/>
                            <?php if($tim->total_anggota == '0'): ?>
                            <?php else: ?>
                                <a href="<?php echo e(url('profile/tambah-anggota')); ?>"><button type="submit" class="btn btn-info btn-fill">Tambah Anggota</button></a>
                            <?php endif; ?>
                        </div>

                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped">
                                <thead>
                                <th>NIM</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>No. Telepon</th>
                                <th>Foto KTM</th>
                                <th>Sebagai</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->no_mahasiswa); ?></td>
                                            <td><?php echo e($item->fullname); ?></td>
                                            <td><?php echo e($item->email); ?></td>
                                            <td><?php echo e($item->no_telp); ?></td>
                                            <td>
                                                <?php if($item->photo == null): ?>
                                                    Belum Upload
                                                <?php else: ?>
                                                    Terupload
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->role); ?></td>
                                            <td>
                                                <input type="hidden" name="_method" value="DELETE" />
                                                <a href="<?php echo e(url('/profile/edit_anggota/'.$item->id)); ?>" class="btn btn-info">
                                                    <i class="fa fa-pencil"></i>
                                                </a>
                                                <?php if($item->role == 'Anggota'): ?>
                                                    <a href="<?php echo e(url('/profile/submit_delete_anggota/'.$item->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.playouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>