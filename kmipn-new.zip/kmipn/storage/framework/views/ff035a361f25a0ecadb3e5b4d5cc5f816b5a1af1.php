<!--================ start footer Area  =================-->
<footer class="footer-area p_120">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-6 col-sm-6">
                <div class="single-footer-widget news_widgets">
                    <h6 class="footer_title">HUBUNGI KAMI</h6>
                    <p><strong>Ruang Kemahasiswaan Gedung D3 Lantai 1<br />Politeknik Elektronika Negeri Surabaya (PENS)<br />Jalan Raya ITS Sukolilo, Surabaya 60111</strong></p>
                    <br />
                    <p>Aflah : +6281555628485</p>
                    <p>Fadli : +6282232666431</p>
                </div>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-6">
                <div class="single-footer-widget news_widgets">
                    <h6 class="footer_title">SPONSOR</h6>
                    <img src="<?php echo e(url('img/im3.png')); ?>" alt="" width="149">
                </div>
            </div>
        </div>
        <div class="row footer-bottom d-flex justify-content-between align-items-center">
            <p class="col-lg-8 col-md-8 footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;<script>document.write(new Date().getFullYear());</script> KMIPN 2018 - Teknik Informatika Politeknik Elektronika Negeri Surabaya</a>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
            <div class="col-lg-4 col-md-4 footer-social">
                <a href="https://www.facebook.com/kmipn2018" target="_blank"><i class="fa fa-facebook"></i></a>
                <a href="https://twitter.com/kmipn2018" target="_blank"><i class="fa fa-twitter"></i></a>
                <a href="https://www.instagram.com/kmipn2018/" target="_blank"><i class="fa fa-instagram"></i></a>
                <a href="" target="_blank"><i class="fa fa-linkedin"></i></a>
            </div>
        </div>
    </div>
</footer>
<!--================ End footer Area  =================-->