<?php $__env->startSection('title', 'Masuk | KMIPN 2018'); ?>

<?php $__env->startSection('content'); ?>
  <!--================Home Banner Area =================-->
  <section class="home_banner_area" id="home">
    <form role="form" action="<?php echo e(url('auth/login')); ?>" method="POST">

      <?php echo e(csrf_field()); ?>


      <div class="banner_inner">
        <div class="container">
          <div class="col-sm-12">
            <div class="col-sm-6">
              <div class="form">
                <h1 class="text-white">MASUK</h1>
                <br>
                <div class="form-group">
                  <!--
                                              <label for="login_email" class="text-white"></label>
                  -->
                  <input name="email" type="email" id="login_email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Your email">
                  <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback">
                      <strong class="text-white"><?php echo e($errors->first('email')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <!--
                                              <label for="login_pass" class="text-white">Your password</label>
                  -->
                  <input name="password" type="password" id="login_pass" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Your password">
                  <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                      <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
                <div class="row">
                  <div class="col col-sm-auto">
                    <p class="text-white">Belum punya akun? <a href="<?php echo e(url('register')); ?>">Daftar sekarang</a><br>
                    Atau <a href="<?php echo e(url('forgot')); ?>">lupa password</a></p>
                  </div>
                  <div class="col text-right">
                    <button type="submit" class="genric-btn primary circle">MASUK</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  </section>
  <!--================End Home Banner Area =================-->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>