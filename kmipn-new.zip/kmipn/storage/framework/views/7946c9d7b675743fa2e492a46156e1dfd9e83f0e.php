

<!doctype html>
<html lang="en">
<head>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0" border="0">
    <tbody>
    <tr>
        <td style="padding:0 0 30px;font-size:0pt;line-height:0pt;text-align:center"> <img src="<?php echo e(url('img/kmipn.png')); ?>" width="200"> </td>
    </tr>


    <tr>
        <td style="padding-bottom:30px" class="m_-2031883786922804868pb-25">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                <tr>
                    <td style="padding-bottom:42px;border-bottom:2px solid #e5e5e5" class="m_-2031883786922804868pb-20">
                        <div class="m_-2031883786922804868h1-c" style="color:#003368;font-family:'Montserrat',Arial,sans-serif;font-size:44px;line-height:48px;text-align:center;font-weight:bold">
                            <span style="color:#003368;text-decoration:none">Verifikasi Email Anda</span>
                        </div> </td>
                </tr>
                </tbody>
            </table> </td>
    </tr>


    <tr>
        <td style="padding:0 30px" class="m_-2031883786922804868p0-10">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                <tr>
                    <td style="padding-bottom:30px">
                        <div class="m_-2031883786922804868text-c" style="color:#4c4c4c;font-family:'Montserrat',Arial,sans-serif;font-size:14px;line-height:20px;text-align:center">
                            Mohon untuk verifikasi email anda dengan klik tombol dibawah ini
                        </div> </td>
                </tr>
                </tbody>
            </table> </td>
    </tr>


    <tr>
        <td style="padding:0 0 30px" class="m_-2031883786922804868pb-50" align="center">
            <table cellspacing="0" cellpadding="0" border="0">
                <tbody>
                <tr>
                    <td class="m_-2031883786922804868text-button" style="border-radius:30px;padding:15px 30px;color:#ffffff;font-family:'Montserrat',Arial,sans-serif;font-size:14px;line-height:18px;text-align:center;letter-spacing:2px;text-transform:uppercase" bgcolor="#003368">
                        <a href="<?php echo e($link); ?>" rel="noopener noreferrer" style="color:#ffffff;text-decoration:none" target="_blank" data-saferedirecturl="">
                            <span class="m_-2031883786922804868link-white" style="color:#ffffff;text-decoration:none">VERIFIKASI</span>
                        </a>
                    </td>
                </tr>
                </tbody>
            </table> </td>
    </tr>
    <tr>
        <td>
            <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#f2f2f2">
                <tbody>
                <tr>
                    <td class="m_7461697420632342160content-spacing" style="font-size:0pt;line-height:0pt;text-align:left" width="15"></td>
                    <td style="padding:15px 0">
                        <table width="100%" cellspacing="0" cellpadding="0" border="0">
                            <tbody>
                            <tr>
                                <th class="m_7461697420632342160column" style="font-size:0pt;line-height:0pt;padding:0;margin:0;font-weight:normal" width="135">
                                    <div class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left">
                                        <div class="m_7461697420632342160img-m-center" style="font-size:0pt;line-height:0pt">
                                            <a href="http://192.168.1.15:8000" target="_blank" data-saferedirecturl="http://192.168.1.15:8000"><img src="img/kmipn.png" width="96"></a>
                                        </div>
                                    </div> </th>
                                <th class="m_7461697420632342160column" style="font-size:0pt;line-height:0pt;padding:0;margin:0;font-weight:normal">
                                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody>
                                        <tr>
                                            <td align="right">
                                                <div style="font-size:0pt;line-height:0pt" class="m_7461697420632342160mobile-br-15"></div>
                                                <table class="m_7461697420632342160center" cellspacing="0" cellpadding="0" border="0">
                                                    <tbody>
                                                    <tr>
                                                        <td class="m_7461697420632342160text-footer" style="color:#7c7c7c;font-family:'Montserrat',Arial,sans-serif;font-size:16px;line-height:17px;text-align:right">Ikuti kami di</td>
                                                        <td class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left" width="20"></td>
                                                        <td>

                                                            <table cellspacing="0" cellpadding="0" border="0">
                                                                <tbody>
                                                                <tr>
                                                                    <td class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left" width="20"><a href="http://www.instagram.com/kmipn2018" target="_blank" data-saferedirecturl="http://www.instagram.com/kmipn2018"><img src="https://ci5.googleusercontent.com/proxy/nRV9PNs8-hWQlRi6G-TS7IgMYgqhdNxV7VcOi60GZV5r9e92KicZSfRCEqNghmnPEcqGW1tt5lU-tEx8ABBshDqlyIxK21SCmWZbN9X64Xqd7FUZvhp3DHFP1oxEJSBiyuk=s0-d-e1-ft#https://marketing-images.gotinder.com/06537a2d608c459699cc8a63a188e167/2.png" alt="Instagram" class="CToWUd" width="20" height="19" border="0"></a></td>
                                                                    <td class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left" width="15"></td>
                                                                    <td class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left" width="23"><a href="http://www.twitter.com/kmipn2018" target="_blank" data-saferedirecturl="http://www.twitter.com/kmipn2018"><img src="https://ci6.googleusercontent.com/proxy/jtbyzMHzASKfZOEggnnR-RBHEox_voylJqbju88cwhveh-OS1K6TPKorKF2YB8VaOs0jRSJPkZgRckm_mDALXZ1F-Q-vPyokG3Oq7JfTBKGU-WTDw3zPUftu3BA0N2CdgJo=s0-d-e1-ft#https://marketing-images.gotinder.com/06537a2d608c459699cc8a63a188e167/3.png" alt="Twitter" class="CToWUd" width="23" height="19" border="0"></a></td>
                                                                    <td class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left" width="15"></td>
                                                                    <td class="m_7461697420632342160img" style="font-size:0pt;line-height:0pt;text-align:left" width="19"><a href="http://www.facebook.com/kmipn2018" target="_blank" data-saferedirecturl="http://www.facebook.com/kmipn2018"><img src="https://ci6.googleusercontent.com/proxy/VY9Do28x75mnL1M0eKT5rTuuNQ1yD5F2LaW4xiDZwbPtd3Ye62PmoIbPOYJzWIK2BzqvogCAfi4dPzqeSVWCzAOtD6h2ptrDw9FJVTEXootBNXioZumGnBJ4nXhoPExW6gs=s0-d-e1-ft#https://marketing-images.gotinder.com/dfbeff40885e4192bea8da73c5c8e550/0.png" alt="Facebook" class="CToWUd" width="19" height="18" border="0"></a></td>
                                                                </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table> </td>
                                        </tr>
                                        </tbody>
                                    </table> </th>
                            </tr>
                            </tbody>
                        </table> </td>
                    <td class="m_7461697420632342160content-spacing" style="font-size:0pt;line-height:0pt;text-align:left" width="15"></td>
                </tr>
                </tbody>
            </table>


            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody>
                <tr>
                    <td class="m_7461697420632342160content-spacing" style="font-size:0pt;line-height:0pt;text-align:left" width="15"></td>
                    <td class="m_7461697420632342160text-footer-2 notranslate" style="padding:30px 0;color:#7c7c7c;font-family:'Montserrat',Arial,sans-serif;font-size:11px;line-height:20px;text-align:center"> Email ini dikirim oleh KMIPN 2018<br> Politeknik Elektronika Negeri Surabaya<br> Surabaya, 8 - 10 November 2018 <br> </td>
                    <td class="m_7461697420632342160content-spacing" style="font-size:0pt;line-height:0pt;text-align:left" width="15"></td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>
</body>
</html>