<?php $__env->startSection('title'); ?>
  Forgot Password | KMIPN 2018
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section class="home_banner_area">
        <div class="banner_inner">
            <div class="container">
                <div class="col-sm-12">
                    <div class="col-sm-6">
                        <div class="form">
                            <h1 class="text-white">LUPA PASSWORD</h1>
                            <br/>

                            <form role="form" action="<?php echo e(url('auth/forgot')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group">
                                    <input name="email" type="email" id="login_email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Your email">
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback">
                                          <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="row">
                                    <div class="col text-right">
                                        <button type="submit" class="genric-btn primary circle">Submit</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    
  
    
        
            
                
                
                
            
            
              
                
                
                  
                  
                  
                    
                      
                    
                  
                
                
                
              
            
        
    
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>