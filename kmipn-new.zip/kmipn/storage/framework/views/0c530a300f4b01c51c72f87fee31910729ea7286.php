<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2>Lomba</h2>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-block">
                <form action="<?php echo e(url('/ecodeeepis/lomba')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="kategori">Kategori Lomba</label>
                                    <select class="form-control select2" name="kategori_id" id="" required>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->kategori); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                            </div><br>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="pengumuman">Pengumuman</label>
                                    <textarea class="form-control summernote" name="pengumuman" id="pengumuman" rows="3" placeholder="pengumuman"></textarea>
                                </div>
                            </div><br>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="deskripsi">Deskripsi Lomba</label>
                                    <textarea class="form-control summernote" name="deskripsi" id="deskripsi" rows="3" placeholder="deskripsi"></textarea>
                                </div>
                            </div><br>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="peraturan">Peraturan Lomba</label>
                                    <textarea class="form-control summernote" name="peraturan" id="peraturan" rows="3" placeholder="peraturan"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer text-center">
                        <a href="<?php echo e(url('/ecodeeepis/lomba')); ?>" class="btn btn-warning">Cancel</a>
                        <button type="submit" name="submit" class="btn btn-success">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>