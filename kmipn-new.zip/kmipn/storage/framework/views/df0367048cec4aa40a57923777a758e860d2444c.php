<?php $__env->startSection('title'); ?>
<?php echo e($artikel->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--================Home Banner Area =================-->
    <section class="banner_area">
        <div class="banner_inner d-flex align-items-center">
            <div class="container">
                <div class="banner_content text-center">
                    <h2><?php echo e($artikel->title); ?></h2>
                    
                </div>
            </div>
        </div>
    </section>
    <!--================End Home Banner Area =================-->

    <!--================Blog Area =================-->
    <section class="blog_area single-post-area p_120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 posts-list">
                    <div class="single-post row">
                        <div class="col-lg-12">
                            <div class="feature-img">
                                <?php if($artikel->photo != null): ?>
                                    <div align="center">
                                        <img src="<?php echo e(url('artikel/'.$artikel->photo)); ?>" class="img-fluid" />
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-9 mt-25 blog_details">
                            <h2><?php echo e($artikel->title); ?></h2>
                            Pada <?php echo e($artikel->created_at); ?>

                        </div>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-12 mt-25">
                                    <br>
                                    <p><?= $artikel->content ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--================Blog Area =================-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>